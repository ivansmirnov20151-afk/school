package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.AppUpdateRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Расписание и Звонки", appName)
  }

  @Test
  fun `test app current version constant`() {
    assertEquals("2.0.0", AppUpdateRepository.CURRENT_APP_VERSION)
  }

  @Test
  fun `test parse default update payload`() {
    val repo = AppUpdateRepository()
    val rawText = """
      version-1.2.0
      updata-not
      ancoment-not
    """.trimIndent()

    val parsed = repo.parseUpdatePayload(rawText)
    assertEquals("1.2.0", parsed.remoteVersion)
    assertNull(parsed.updateUrl)
    assertNull(parsed.announcement)
  }

  @Test
  fun `test parse new update payload with changelog and url`() {
    val repo = AppUpdateRepository()
    val rawText = """
      version-1.2.1
      updata-https://github.com/ivansmirnov20151-afk/chiat/releases/download/v1.2.1/app.apk
      ancoment-Улучшена безопасность и обновлено расписание
    """.trimIndent()

    val parsed = repo.parseUpdatePayload(rawText)
    assertEquals("1.2.1", parsed.remoteVersion)
    assertEquals("https://github.com/ivansmirnov20151-afk/chiat/releases/download/v1.2.1/app.apk", parsed.updateUrl)
    assertEquals("Улучшена безопасность и обновлено расписание", parsed.announcement)
  }

  @Test
  fun `test schedule preferences voting and child verification storage`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = com.example.data.preferences.SchedulePreferences(context)

    prefs.isVotedOrUnlocked = false
    prefs.childVerificationStatus = "none"
    org.junit.Assert.assertFalse(prefs.isVotedOrUnlocked)
    assertEquals("none", prefs.childVerificationStatus)

    val testTime = System.currentTimeMillis()
    prefs.childStudentFio = "Иванов Иван Иванович"
    prefs.childStudentBirthDate = "15.05.2014"
    prefs.childVerificationSubmitTime = testTime
    prefs.childVerificationStatus = "pending"

    assertEquals("Иванов Иван Иванович", prefs.childStudentFio)
    assertEquals("15.05.2014", prefs.childStudentBirthDate)
    assertEquals("pending", prefs.childVerificationStatus)
    assertEquals(testTime, prefs.childVerificationSubmitTime)

    // Simulate 5 minutes elapsed
    val fiveMinElapsed = (testTime + 5 * 60 * 1000L) - prefs.childVerificationSubmitTime >= 5 * 60 * 1000L
    org.junit.Assert.assertTrue(fiveMinElapsed)
  }
}
