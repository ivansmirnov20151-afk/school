package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.LessonEntity
import com.example.data.repository.ScheduleRepository
import com.example.ui.components.AddLessonDialog
import com.example.ui.components.AiLoadingTransitionScreen
import com.example.ui.components.AiTutorDialog
import com.example.ui.components.AppSplashScreen
import com.example.ui.components.AuthWelcomeScreen
import com.example.ui.components.BellsScheduleDialog
import com.example.ui.components.BottomTab
import com.example.ui.components.ChangePinDialog
import com.example.ui.components.CurrentLessonHeroCard
import com.example.ui.components.DayScheduleView
import com.example.ui.components.EditLessonDialog
import com.example.ui.components.ElectionsDialog
import com.example.ui.components.GitHubInstructionDialog
import com.example.ui.components.GradesDialog
import com.example.ui.components.GradesSummaryCard
import com.example.ui.components.GreetingBanner
import com.example.ui.components.LessonHomeworkDetailsDialog
import com.example.ui.components.LiquidGlassBottomBar
import com.example.ui.components.LockedHeroCard
import com.example.ui.components.LockedLunchStatusCard
import com.example.ui.components.LockedScheduleCard
import com.example.ui.components.LunchStatusCard
import com.example.ui.components.MandatoryUpdateScreen
import com.example.ui.components.MiddleAiTutorCard
import com.example.ui.components.ModernSettingsSheet
import com.example.ui.components.PinLockScreen
import com.example.ui.components.PublishHomeworkDialog
import com.example.ui.components.RestrictedModeBanner
import com.example.ui.components.SettingsDialog
import com.example.ui.components.SupportDialog
import com.example.ui.components.WelcomeUpdateDialog
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoBorder
import com.example.ui.theme.GeoBorderLight
import com.example.ui.theme.GeoDarkCard
import com.example.ui.theme.GeoGreenAccent
import com.example.ui.theme.GeoOnPrimary
import com.example.ui.theme.GeoOnPrimaryContainer
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryContainer
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceVariant
import com.example.ui.theme.GeoTextPrimary
import com.example.ui.theme.GeoTextSecondary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ScheduleViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ScheduleViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                ScheduleApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleApp(viewModel: ScheduleViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val allLessons by viewModel.allLessons.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var isAppSplashVisible by remember { mutableStateOf(true) }
    var isAiTransitionVisible by remember { mutableStateOf(false) }
    var activeBottomTab by remember { mutableStateOf(BottomTab.SCHEDULE) }

    // Runtime permission for notifications on Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionCheck = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    if (isAppSplashVisible) {
        AppSplashScreen(
            onFinished = { isAppSplashVisible = false }
        )
    } else if (!uiState.isUserRegistered) {
        AuthWelcomeScreen(
            isCheckingCredentials = uiState.isCheckingAuthCredentials,
            errorMessage = uiState.authErrorMessage,
            onVerifyLogin = { login, pass, onSuccess ->
                viewModel.verifyLogin(login, pass, onSuccess)
            },
            onCompleteAuth = { login, name, pin, isGuest ->
                viewModel.completeRegistration(login, name, pin, isGuest)
            }
        )
    } else if (!uiState.isUnlocked) {
        PinLockScreen(
            enteredPin = uiState.enteredPin,
            pinError = uiState.pinError,
            isChecking = uiState.isCheckingPinUpdate,
            welcomeMode = uiState.isWelcomeUnlockAnim,
            onDigitClick = { viewModel.enterPinDigit(it) },
            onDeleteClick = { viewModel.deletePinDigit() },
            onClearClick = { viewModel.clearPin() },
            onFingerprintSuccess = { viewModel.unlockWithFingerprint() }
        )
    } else if (isAiTransitionVisible) {
        AiLoadingTransitionScreen(
            onReady = {
                isAiTransitionVisible = false
                viewModel.openAiDialog()
            }
        )
    } else if (uiState.isUpdateRequired) {
        MandatoryUpdateScreen(
            currentVersion = uiState.currentVersion,
            remoteVersion = uiState.remoteVersion,
            announcement = uiState.updateAnnouncement,
            updateUrl = uiState.updateUrl,
            isCheckingAgain = uiState.isCheckingUpdateManual,
            onCheckAgainClick = { viewModel.checkUpdatesFromMandatoryScreen() }
        )
    } else {
        var showRestrictedNoticeDialog by remember { mutableStateOf(false) }
        val scheduleListState = rememberLazyListState()

        // Check if user is scrolling down (first visible item > 0 or scrolled down into list)
        val isScrolledDown by remember {
            derivedStateOf {
                scheduleListState.firstVisibleItemIndex > 0 || scheduleListState.firstVisibleItemScrollOffset > 20
            }
        }

        // Detect active scrolling for the bottom translucent overlay
        val isScrolling by remember {
            derivedStateOf { scheduleListState.isScrollInProgress }
        }
        val bottomScrollFadeAlpha by animateFloatAsState(
            targetValue = if (isScrolling) 1f else 0f,
            animationSpec = tween(durationMillis = 300),
            label = "bottomScrollFadeAlpha"
        )

        // Animate blur and alpha dynamically: when scrolling down -> blurred frosted glass header
        val headerElevation by animateDpAsState(
            targetValue = if (isScrolledDown) 8.dp else 0.dp,
            animationSpec = tween(durationMillis = 250),
            label = "headerElevation"
        )
        val blurRadius by animateDpAsState(
            targetValue = if (isScrolledDown) 16.dp else 0.dp,
            animationSpec = tween(durationMillis = 250),
            label = "blurRadius"
        )
        val topBarAlpha by animateFloatAsState(
            targetValue = if (isScrolledDown) 0.85f else 1f,
            animationSpec = tween(durationMillis = 250),
            label = "topBarAlpha"
        )

        val todayStr = ScheduleRepository.getTodayDateString()
        val dayLessons = allLessons.filter {
            it.dayOfWeek == uiState.selectedDay.dayNumber &&
                    (it.overrideDate == null || it.overrideDate == todayStr)
        }.sortedBy { it.lessonNumber }

        Scaffold(
            containerColor = GeoBackground,
            topBar = {
                Box(modifier = Modifier.fillMaxWidth()) {
                    CenterAlignedTopAppBar(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (blurRadius > 0.dp) Modifier.blur(blurRadius)
                                else Modifier
                            ),
                        title = {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "5Б КЛАСС",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = GeoPrimary
                                )
                                Text(
                                    text = "Расписание",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = GeoTextPrimary
                                )
                            }
                        },
                        navigationIcon = {
                            Surface(
                                shape = CircleShape,
                                color = GeoPrimaryContainer,
                                modifier = Modifier
                                    .padding(start = 12.dp)
                                    .size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "5Б",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GeoOnPrimaryContainer
                                    )
                                }
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { viewModel.setSupportDialogOpen(true) },
                                modifier = Modifier.testTag("top_support_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SupportAgent,
                                    contentDescription = "Поддержка",
                                    tint = if (uiState.isRestricted) Color(0xFFDC2626) else GeoPrimary
                                )
                            }
                            IconButton(
                                onClick = { viewModel.openElectionsDialog() },
                                modifier = Modifier.testTag("top_elections_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.HowToVote,
                                    contentDescription = "Выборы 2026",
                                    tint = Color(0xFF1E40AF)
                                )
                            }
                            IconButton(
                                onClick = {
                                    if (uiState.isRestricted) {
                                        showRestrictedNoticeDialog = true
                                    } else {
                                        viewModel.openAiDialog()
                                    }
                                },
                                modifier = Modifier.testTag("top_ai_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "ИИ-Репетитор",
                                    tint = if (uiState.isRestricted) Color(0xFF94A3B8) else Color(0xFFA855F7)
                                )
                            }
                            IconButton(
                                onClick = {
                                    if (uiState.isRestricted) {
                                        showRestrictedNoticeDialog = true
                                    } else {
                                        viewModel.openGradesDialog()
                                    }
                                },
                                modifier = Modifier.testTag("top_grades_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BarChart,
                                    contentDescription = "Оценки",
                                    tint = if (uiState.isRestricted) Color(0xFF94A3B8) else Color(0xFF10B981)
                                )
                            }
                            IconButton(
                                onClick = {
                                    if (uiState.isRestricted) {
                                        showRestrictedNoticeDialog = true
                                    } else {
                                        viewModel.setBellsDialogOpen(true)
                                    }
                                },
                                modifier = Modifier.testTag("top_bells_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Звонки",
                                    tint = if (uiState.isRestricted) Color(0xFF94A3B8) else GeoPrimary
                                )
                            }
                            IconButton(
                                onClick = {
                                    if (uiState.isRestricted) {
                                        showRestrictedNoticeDialog = true
                                    } else {
                                        viewModel.setSettingsDialogOpen(true)
                                    }
                                },
                                modifier = Modifier.testTag("top_settings_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Настройки",
                                    tint = if (uiState.isRestricted) Color(0xFF94A3B8) else GeoTextSecondary
                                )
                            }
                            IconButton(
                                onClick = { viewModel.lockApp() },
                                modifier = Modifier.testTag("top_lock_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Заблокировать",
                                    tint = GeoTextSecondary
                                )
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = if (isScrolledDown) GeoSurface.copy(alpha = topBarAlpha) else GeoSurface
                        )
                    )

                    // Soft blur & shadow gradient at the bottom edge of topBar when scrolled down
                    if (isScrolledDown) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(headerElevation * 1.5f)
                                .align(Alignment.BottomCenter)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Black.copy(alpha = 0.08f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }
                }
            },
            floatingActionButton = {
                if (!uiState.isRestricted) {
                    ExtendedFloatingActionButton(
                        onClick = { viewModel.setAddLessonDialogOpen(true) },
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        text = { Text("Добавить урок", fontWeight = FontWeight.Bold) },
                        containerColor = GeoPrimary,
                        contentColor = GeoOnPrimary,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .testTag("fab_add_lesson")
                            .padding(bottom = 96.dp)
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(GeoBackground)
            ) {
                LazyColumn(
                    state = scheduleListState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = innerPadding.calculateTopPadding()),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 124.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                // Greeting and Quick Status Banner
                item {
                    GreetingBanner(
                        greetingText = uiState.greetingText,
                        greetingEmoji = uiState.greetingEmoji,
                        className = uiState.selectedClassName,
                        appVersion = uiState.currentVersion,
                        onOpenAiClick = {
                            if (uiState.isRestricted) showRestrictedNoticeDialog = true
                            else viewModel.openAiDialog()
                        },
                        onOpenGradesClick = {
                            if (uiState.isRestricted) showRestrictedNoticeDialog = true
                            else viewModel.openGradesDialog()
                        }
                    )
                }

                if (uiState.isRestricted) {
                    item {
                        RestrictedModeBanner(
                            verificationStatus = uiState.childVerificationStatus,
                            onOpenSupportClick = { viewModel.setSupportDialogOpen(true) },
                            onOpenElectionsClick = { viewModel.openElectionsDialog() }
                        )
                    }
                    item {
                        LockedHeroCard(
                            onOpenSupportClick = { viewModel.setSupportDialogOpen(true) }
                        )
                    }
                    item {
                        LockedLunchStatusCard()
                    }
                    item {
                        LockedScheduleCard(
                            onOpenSupportClick = { viewModel.setSupportDialogOpen(true) }
                        )
                    }
                } else {
                    // 1. Hero Card: Current lesson / break / countdown in Geometric Balance
                    item {
                        CurrentLessonHeroCard(
                            statusInfo = uiState.currentStatus,
                            isAutoTracking = uiState.isAutoTracking,
                            onLessonFinishedClick = { viewModel.advanceManualLesson() },
                            onResetToAutoClick = { viewModel.resetToAutoTracking() },
                            onOpenBellsClick = { viewModel.setBellsDialogOpen(true) }
                        )
                    }

                    // 2. Dual Geometric Metric Cards (Until Lunch & Next Lesson)
                    item {
                        LunchStatusCard(statusInfo = uiState.currentStatus)
                    }

                    // 3. Middle AI Tutor Card (Vibe card in the middle of screen)
                    item {
                        MiddleAiTutorCard(
                            onOpenAiClick = { viewModel.openAiDialog() }
                        )
                    }

                    // 4. Grades and Points Summary Card
                    item {
                        GradesSummaryCard(
                            subjects = uiState.subjectsGrades,
                            onOpenGradesClick = { viewModel.openGradesDialog() }
                        )
                    }

                    // 5. Lock Screen Widget Active Info Card (Geometric Dark Card)
                    item {
                        LockScreenWidgetBanner(
                            isNotificationsActive = uiState.isNotificationsEnabled,
                            onConfigureClick = { viewModel.setSettingsDialogOpen(true) }
                        )
                    }

                    // 6. Day Schedule selector and list of lessons
                    item {
                        DayScheduleView(
                            selectedDay = uiState.selectedDay,
                            todayDay = uiState.todayDay,
                            lessons = dayLessons,
                            bells = viewModel.bellSlots,
                            activeLessonNumber = if (uiState.isAutoTracking) uiState.currentStatus.activeLessonNumber
                            else uiState.manualActiveLessonIndex.takeIf { it > 0 },
                            homeworkList = uiState.allHomework,
                            onSelectDay = { viewModel.selectDay(it) },
                            onSelectToday = { viewModel.selectToday() },
                            onLessonClick = { viewModel.openLessonDetails(it) },
                            onAddLessonClick = { viewModel.setAddLessonDialogOpen(true) }
                        )
                    }
                }
            }

            // Dynamic translucent frosted overlay above and around the bottom panel when scrolling
                // "когда листаешь прозрачно становится снизу рядом с панелькой но чутка повыше но когда не листаешь она пропадает"
                if (bottomScrollFadeAlpha > 0.005f) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(156.dp)
                            .align(Alignment.BottomCenter)
                            .graphicsLayer { alpha = bottomScrollFadeAlpha }
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        GeoBackground.copy(alpha = 0f),
                                        GeoBackground.copy(alpha = 0.60f),
                                        GeoBackground.copy(alpha = 0.88f),
                                        GeoBackground.copy(alpha = 0.98f)
                                    )
                                )
                            )
                    )
                }

                // Liquid glass bottom bar (normal GeoBackground behind it, fixed centered)
                LiquidGlassBottomBar(
                    currentTab = activeBottomTab,
                    onTabSelected = { tab ->
                        activeBottomTab = tab
                        when (tab) {
                            BottomTab.SCHEDULE -> {
                                // Default main schedule view
                            }
                            BottomTab.AI_TUTOR -> {
                                if (uiState.isRestricted) {
                                    showRestrictedNoticeDialog = true
                                } else {
                                    isAiTransitionVisible = true
                                }
                            }
                            BottomTab.GRADES -> {
                                if (uiState.isRestricted) {
                                    showRestrictedNoticeDialog = true
                                } else {
                                    viewModel.openGradesDialog()
                                }
                            }
                            BottomTab.BELLS -> {
                                if (uiState.isRestricted) {
                                    showRestrictedNoticeDialog = true
                                } else {
                                    viewModel.setBellsDialogOpen(true)
                                }
                            }
                            BottomTab.SETTINGS -> {
                                viewModel.setSettingsDialogOpen(true)
                            }
                        }
                    },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                )
            }
        }

        // Dialogs
        if (uiState.isLessonDetailsOpen && uiState.selectedLessonForDetails != null) {
            val lesson = uiState.selectedLessonForDetails!!
            val bell = viewModel.bellSlots.firstOrNull { it.lessonNumber == lesson.lessonNumber }
            val hw = uiState.allHomework.firstOrNull {
                it.subjectRu.equals(lesson.subject, ignoreCase = true) ||
                it.subjectEn.equals(lesson.subject, ignoreCase = true)
            }

            LessonHomeworkDetailsDialog(
                lesson = lesson,
                bellSlot = bell,
                homework = hw,
                isRegisteredUser = !uiState.isGuestUser,
                canPublish = uiState.canPublishHomework,
                onPublishClick = { viewModel.openPublishHomework() },
                onEditLessonClick = {
                    viewModel.closeLessonDetails()
                    viewModel.openEditLesson(lesson)
                },
                onDismiss = { viewModel.closeLessonDetails() }
            )
        }

        if (uiState.isPublishHomeworkOpen && uiState.selectedLessonForDetails != null) {
            val lesson = uiState.selectedLessonForDetails!!
            PublishHomeworkDialog(
                subjectRu = lesson.subject,
                username = uiState.userLogin,
                userRawUrl = uiState.userRawHomeworkUrl,
                onHomeworkVerified = { hwItem ->
                    viewModel.publishHomework(hwItem)
                    Toast.makeText(context, "Домашнее задание успешно опубликовано!", Toast.LENGTH_LONG).show()
                },
                onDismiss = { viewModel.closePublishHomework() }
            )
        }

        if (uiState.isGitHubInstructionOpen) {
            GitHubInstructionDialog(
                username = uiState.userLogin,
                isCheckingRaw = uiState.isCheckingRawBinding,
                onCheckRawClick = {
                    viewModel.checkUserRawBinding()
                },
                onDismiss = { viewModel.closeGitHubInstruction() }
            )
        }

        if (uiState.isEditingLessonOpen && uiState.editingLesson != null) {
            EditLessonDialog(
                lesson = uiState.editingLesson!!,
                onDismiss = { viewModel.closeEditLesson() },
                onSave = { subj, cab, teach, onlyToday ->
                    viewModel.saveEditedLesson(subj, cab, teach, onlyToday)
                },
                onDelete = { viewModel.deleteLesson(it) }
            )
        }

        if (uiState.isBellsDialogOpen) {
            BellsScheduleDialog(
                bells = viewModel.bellSlots,
                onDismiss = { viewModel.setBellsDialogOpen(false) }
            )
        }

        ModernSettingsSheet(
            isOpen = uiState.isSettingsDialogOpen,
            isNotificationsEnabled = uiState.isNotificationsEnabled,
            isAutoTracking = uiState.isAutoTracking,
            isCheckingUpdates = uiState.isCheckingUpdateManual,
            currentPin = uiState.currentPinCode,
            onToggleNotifications = { viewModel.toggleNotifications(it) },
            onToggleAutoTracking = { viewModel.toggleAutoTracking(it) },
            onSendTestNotification = { viewModel.sendTestNotification() },
            onCheckUpdatesClick = {
                viewModel.checkUpdatesManual { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                }
            },
            onShowElectionsClick = {
                viewModel.setSettingsDialogOpen(false)
                viewModel.openElectionsDialog()
            },
            onChangePinClick = {
                viewModel.setSettingsDialogOpen(false)
                viewModel.setChangePinDialogOpen(true)
            },
            onLockAppClick = {
                viewModel.setSettingsDialogOpen(false)
                viewModel.lockApp()
            },
            onResetScheduleClick = {
                viewModel.resetScheduleToDefault()
                viewModel.setSettingsDialogOpen(false)
            },
            onDismiss = { viewModel.setSettingsDialogOpen(false) }
        )

        if (uiState.isSupportDialogOpen) {
            SupportDialog(
                isRestricted = uiState.isRestricted,
                verificationStatus = uiState.childVerificationStatus,
                submitTimestamp = uiState.childVerificationSubmitTime,
                savedFio = uiState.childStudentFio,
                savedBirthDate = uiState.childStudentBirthDate,
                onSubmitChildVerification = { fio, bDate ->
                    viewModel.submitChildVerification(fio, bDate)
                },
                onAdultVoteClick = {
                    viewModel.confirmAdultVote()
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://vybory.gov.ru/"))
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://gosuslugi.ru/"))
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    }
                },
                onVerificationApproved = {
                    viewModel.approveChildVerification()
                },
                onDismiss = { viewModel.setSupportDialogOpen(false) }
            )
        }

        if (uiState.isElectionsDialogOpen) {
            ElectionsDialog(
                onDismiss = { viewModel.dismissElectionsDialog() },
                onVoteConfirmed = { viewModel.confirmAdultVote() },
                onOpenSupport = { viewModel.setSupportDialogOpen(true) }
            )
        }

        if (showRestrictedNoticeDialog) {
            AlertDialog(
                onDismissRequest = { showRestrictedNoticeDialog = false },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = "Доступ заблокирован",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Text(
                        text = "Функции звонков, настроек и расписания заблокированы, так как не подтверждено участие в выборах или статус учащегося.\n\nНапишите в поддержку, выберите пункт «Я ребёнок» и отправьте анкету (ФИО и дату рождения). Через 5 минут ограничения снимутся!",
                        fontSize = 13.sp,
                        color = GeoTextSecondary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showRestrictedNoticeDialog = false
                            viewModel.setSupportDialogOpen(true)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                    ) {
                        Text("Написать в поддержку")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showRestrictedNoticeDialog = false }) {
                        Text("Позже")
                    }
                }
            )
        }

        if (uiState.isWelcomeUpdateDialogOpen) {
            WelcomeUpdateDialog(
                version = uiState.currentVersion,
                onDismiss = { viewModel.dismissWelcomeUpdateDialog() }
            )
        }

        if (uiState.isChangePinDialogOpen) {
            ChangePinDialog(
                onDismiss = { viewModel.setChangePinDialogOpen(false) },
                onSaveNewPin = { newPin ->
                    viewModel.updatePinCode(newPin)
                }
            )
        }

        if (uiState.isAddLessonDialogOpen) {
            AddLessonDialog(
                selectedDay = uiState.selectedDay,
                existingLessonCount = dayLessons.size,
                onDismiss = { viewModel.setAddLessonDialogOpen(false) },
                onAddLesson = { dayOfWeek, lessonNum, subj, cab, teacher ->
                    viewModel.addLesson(dayOfWeek, lessonNum, subj, cab, teacher)
                }
            )
        }

        AiTutorDialog(
            isOpen = uiState.isAiDialogOpen,
            isLoading = uiState.isAiLoading,
            errorText = uiState.aiError,
            messages = uiState.aiMessages,
            onSendMessage = { viewModel.sendAiMessage(it) },
            onRetry = { viewModel.retryLastAiMessage() },
            onClearChat = { viewModel.clearAiChat() },
            onDismiss = { viewModel.dismissAiDialog() }
        )

        GradesDialog(
            isOpen = uiState.isGradesDialogOpen,
            subjects = uiState.subjectsGrades,
            onAddGrade = { subj, grade -> viewModel.addGrade(subj, grade) },
            onRemoveGrade = { subj, idx -> viewModel.removeGrade(subj, idx) },
            onResetToDefault = { viewModel.resetGradesToDefault() },
            onDismiss = { viewModel.dismissGradesDialog() }
        )
    }
}

@Composable
fun LockScreenWidgetBanner(
    isNotificationsActive: Boolean,
    onConfigureClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = GeoDarkCard
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isNotificationsActive) GeoGreenAccent else Color.Gray)
                )

                Column {
                    Text(
                        text = "Уведомления и виджет активны",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Оповещение за 5 мин до начала урока",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color.White.copy(alpha = 0.15f),
                onClick = onConfigureClick
            ) {
                Text(
                    text = "Настроить",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}
