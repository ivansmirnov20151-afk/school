package com.example.receiver

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.service.ScheduleNotificationManager

class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_LESSON_ALERT) {
            val subject = intent.getStringExtra(EXTRA_SUBJECT) ?: "Урок"
            val cabinet = intent.getStringExtra(EXTRA_CABINET) ?: ""
            val lessonNum = intent.getIntExtra(EXTRA_LESSON_NUM, 1)
            val minutesBefore = intent.getIntExtra(EXTRA_MINUTES_BEFORE, 5)

            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                lessonNum,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val cabinetText = if (cabinet.isNotBlank()) " • Каб. $cabinet" else ""
            val builder = NotificationCompat.Builder(context, ScheduleNotificationManager.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("🔔 $lessonNum-й урок через $minutesBefore мин: $subject")
                .setContentText("Начало урока через $minutesBefore мин$cabinetText")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            notificationManager.notify(lessonNum, builder.build())
        }
    }

    companion object {
        const val ACTION_LESSON_ALERT = "com.example.ACTION_LESSON_ALERT"
        const val EXTRA_SUBJECT = "extra_subject"
        const val EXTRA_CABINET = "extra_cabinet"
        const val EXTRA_LESSON_NUM = "extra_lesson_num"
        const val EXTRA_MINUTES_BEFORE = "extra_minutes_before"
    }
}
