package com.example.receiver

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.model.BellSlot
import com.example.data.model.DayOfWeekRussian
import com.example.data.model.DefaultSchedule
import com.example.data.repository.ScheduleRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class ScheduleWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllWidgets(context, appWidgetManager, appWidgetIds)
    }

    companion object {
        fun updateAllWidgets(
            context: Context,
            appWidgetManager: AppWidgetManager? = null,
            widgetIds: IntArray? = null
        ) {
            val manager = appWidgetManager ?: AppWidgetManager.getInstance(context)
            val ids = widgetIds ?: manager.getAppWidgetIds(
                ComponentName(context, ScheduleWidgetProvider::class.java)
            )
            if (ids.isEmpty()) return

            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                val repo = ScheduleRepository(db.lessonDao())
                repo.ensureDefaultSchedulePopulated()

                val calendar = Calendar.getInstance()
                val dayOfWeekNumber = when (calendar.get(Calendar.DAY_OF_WEEK)) {
                    Calendar.MONDAY -> 1
                    Calendar.TUESDAY -> 2
                    Calendar.WEDNESDAY -> 3
                    Calendar.THURSDAY -> 4
                    Calendar.FRIDAY -> 5
                    Calendar.SATURDAY -> 6
                    Calendar.SUNDAY -> 7
                    else -> 1
                }

                val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
                val currentMinute = calendar.get(Calendar.MINUTE)
                val currentSecond = calendar.get(Calendar.SECOND)
                val currentSecondsOfDay = currentHour * 3600 + currentMinute * 60 + currentSecond

                val dayEnum = DayOfWeekRussian.fromDayNumber(dayOfWeekNumber)
                val todayStr = ScheduleRepository.getTodayDateString()

                val bells = DefaultSchedule.bellsGrade5Shift1

                // Fetch lessons
                val lessons = db.lessonDao().getPermanentLessonsCount()
                val todayLessons = DefaultSchedule.grade5BSchedule.filter { it.dayOfWeek == dayOfWeekNumber }

                // Find active slot
                var headline = "Уроков нет"
                var subjectText = "Выходной / Свободное время"
                var cabinetText = "Класс 5Б"
                var timerText = "--:--"
                var footerText = "Обед в 11:05 (после 4 урока)"
                var statusPill = "Отдых"

                if (dayOfWeekNumber in 1..5) {
                    val firstBell = bells.first()
                    val lastBell = bells.last()
                    val schoolStartSec = firstBell.startHour * 3600 + firstBell.startMinute * 60
                    val schoolEndSec = lastBell.endHour * 3600 + lastBell.endMinute * 60

                    if (currentSecondsOfDay < schoolStartSec) {
                        val firstLesson = todayLessons.firstOrNull { it.lessonNumber == 1 }
                        val diffMins = (schoolStartSec - currentSecondsOfDay) / 60
                        headline = "До начала уроков"
                        subjectText = "1-й урок: ${firstLesson?.subject ?: "Урок"}"
                        cabinetText = "Каб. ${firstLesson?.cabinet ?: "—"}"
                        timerText = "$diffMins мин"
                        statusPill = "Скоро урок"
                        footerText = "Обед в 11:05 (после 4-го урока)"
                    } else if (currentSecondsOfDay > schoolEndSec) {
                        headline = "Уроки окончены"
                        subjectText = "Все уроки на сегодня прошли"
                        cabinetText = "Класс 5Б"
                        timerText = "0 мин"
                        statusPill = "Завершено"
                        footerText = "Завтра по расписанию"
                    } else {
                        // Check inside lesson or break
                        var found = false
                        for (i in bells.indices) {
                            val bell = bells[i]
                            val lStartSec = bell.startHour * 3600 + bell.startMinute * 60
                            val lEndSec = bell.endHour * 3600 + bell.endMinute * 60

                            val curLesson = todayLessons.firstOrNull { it.lessonNumber == bell.lessonNumber }
                            val nextLesson = todayLessons.firstOrNull { it.lessonNumber == bell.lessonNumber + 1 }

                            if (currentSecondsOfDay in lStartSec until lEndSec) {
                                val remainingMin = (lEndSec - currentSecondsOfDay) / 60
                                headline = "${dayEnum.fullName} • ${bell.lessonNumber}-й урок"
                                subjectText = curLesson?.subject ?: "Урок ${bell.lessonNumber}"
                                cabinetText = "Каб. ${curLesson?.cabinet ?: "—"} (${bell.timeRangeFormatted})"
                                timerText = "$remainingMin мин"
                                statusPill = "Идёт урок"
                                val nextTxt = if (nextLesson != null) "След: ${nextLesson.subject} (Каб. ${nextLesson.cabinet})" else "Последний урок"
                                footerText = "$nextTxt • Обед в 11:05"
                                found = true
                                break
                            }

                            val breakEndSec = lEndSec + bell.breakAfterMinutes * 60
                            if (currentSecondsOfDay in lEndSec until breakEndSec) {
                                val remainingMin = (breakEndSec - currentSecondsOfDay) / 60
                                if (bell.isLunchAfter) {
                                    headline = "Перемена • Время обеда!"
                                    subjectText = "Питание / Обед (11:05 - 11:25)"
                                    statusPill = "Обед 🍽️"
                                } else {
                                    headline = "Перемена (${bell.breakAfterMinutes} мин)"
                                    subjectText = "Перемена между уроками"
                                    statusPill = "Перемена"
                                }
                                cabinetText = if (nextLesson != null) "Идите в каб. ${nextLesson.cabinet}" else "Класс 5Б"
                                timerText = "$remainingMin мин"
                                val nextTxt = if (nextLesson != null) "След: ${nextLesson.subject}" else "Уроки окончены"
                                footerText = "$nextTxt (начнется через $remainingMin мин)"
                                found = true
                                break
                            }
                        }

                        if (!found) {
                            headline = "${dayEnum.fullName} • 5Б"
                            subjectText = "Школьный день"
                            cabinetText = "Класс 5Б"
                        }
                    }
                }

                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                val pendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                for (widgetId in ids) {
                    val views = RemoteViews(context.packageName, R.layout.widget_school_schedule).apply {
                        setTextViewText(R.id.widget_day_text, "${dayEnum.fullName} • 5Б")
                        setTextViewText(R.id.widget_time_status, statusPill)
                        setTextViewText(R.id.widget_subject_title, subjectText)
                        setTextViewText(R.id.widget_cabinet_text, cabinetText)
                        setTextViewText(R.id.widget_countdown_text, timerText)
                        setTextViewText(R.id.widget_footer_text, footerText)
                        setOnClickPendingIntent(R.id.widget_root, pendingIntent)
                    }
                    manager.updateAppWidget(widgetId, views)
                }
            }
        }
    }
}
