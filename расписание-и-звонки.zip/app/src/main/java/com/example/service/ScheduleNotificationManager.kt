package com.example.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.LessonEntity
import com.example.data.model.BellSlot
import com.example.data.model.DefaultSchedule
import com.example.receiver.NotificationReceiver
import java.util.Calendar

class ScheduleNotificationManager(private val context: Context) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private val alarmManager =
        context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Уведомления о начале уроков",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Напоминания за 5 минут до начала урока и звонков"
                enableVibration(true)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showImmediateTestNotification(subject: String, cabinet: String, minutesLeft: Int = 5) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🔔 Скоро урок: $subject")
            .setContentText("Через $minutesLeft мин начнется $subject. Кабинет: $cabinet")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        notificationManager.notify(TEST_NOTIFICATION_ID, builder.build())
    }

    fun scheduleAlarmsForToday(lessons: List<LessonEntity>, bells: List<BellSlot>, minutesBefore: Int = 5) {
        if (alarmManager == null) return

        val calendar = Calendar.getInstance()
        val nowMillis = System.currentTimeMillis()

        lessons.forEach { lesson ->
            val bell = bells.firstOrNull { it.lessonNumber == lesson.lessonNumber }
            if (bell != null) {
                val lessonCal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, bell.startHour)
                    set(Calendar.MINUTE, bell.startMinute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    add(Calendar.MINUTE, -minutesBefore)
                }

                if (lessonCal.timeInMillis > nowMillis) {
                    val intent = Intent(context, NotificationReceiver::class.java).apply {
                        action = NotificationReceiver.ACTION_LESSON_ALERT
                        putExtra(NotificationReceiver.EXTRA_SUBJECT, lesson.subject)
                        putExtra(NotificationReceiver.EXTRA_CABINET, lesson.cabinet)
                        putExtra(NotificationReceiver.EXTRA_LESSON_NUM, lesson.lessonNumber)
                        putExtra(NotificationReceiver.EXTRA_MINUTES_BEFORE, minutesBefore)
                    }

                    val pendingIntent = PendingIntent.getBroadcast(
                        context,
                        lesson.lessonNumber * 100 + lesson.dayOfWeek,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )

                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            alarmManager.setExactAndAllowWhileIdle(
                                AlarmManager.RTC_WAKEUP,
                                lessonCal.timeInMillis,
                                pendingIntent
                            )
                        } else {
                            alarmManager.setExact(
                                AlarmManager.RTC_WAKEUP,
                                lessonCal.timeInMillis,
                                pendingIntent
                            )
                        }
                    } catch (e: SecurityException) {
                        alarmManager.set(
                            AlarmManager.RTC_WAKEUP,
                            lessonCal.timeInMillis,
                            pendingIntent
                        )
                    }
                }
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "school_schedule_alerts"
        const val TEST_NOTIFICATION_ID = 9999
    }
}
