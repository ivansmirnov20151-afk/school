package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val dayOfWeek: Int, // 1 (Mon) .. 7 (Sun)
    val lessonNumber: Int, // 1..8
    val subject: String,
    val cabinet: String,
    val teacher: String = "",
    val note: String = "",
    val isOverrideForToday: Boolean = false,
    val overrideDate: String? = null // e.g. "2026-09-01" for single-day substitution
)
