package com.example.data.model

object DefaultSchedule {

    val bellsGrade5Shift1: List<BellSlot> = listOf(
        BellSlot(
            lessonNumber = 1,
            startHour = 8,
            startMinute = 0,
            endHour = 8,
            endMinute = 40,
            durationMinutes = 40,
            breakAfterMinutes = 10,
            isLunchAfter = false
        ),
        BellSlot(
            lessonNumber = 2,
            startHour = 8,
            startMinute = 50,
            endHour = 9,
            endMinute = 30,
            durationMinutes = 40,
            breakAfterMinutes = 10,
            isLunchAfter = false
        ),
        BellSlot(
            lessonNumber = 3,
            startHour = 9,
            startMinute = 40,
            endHour = 10,
            endMinute = 20,
            durationMinutes = 40,
            breakAfterMinutes = 10,
            isLunchAfter = false
        ),
        BellSlot(
            lessonNumber = 4,
            startHour = 10,
            startMinute = 30,
            endHour = 11,
            endMinute = 5,
            durationMinutes = 35,
            breakAfterMinutes = 20, // Обед / Питание: 11:05 – 11:25
            isLunchAfter = true
        ),
        BellSlot(
            lessonNumber = 5,
            startHour = 11,
            startMinute = 25,
            endHour = 12,
            endMinute = 0,
            durationMinutes = 35,
            breakAfterMinutes = 10,
            isLunchAfter = false
        ),
        BellSlot(
            lessonNumber = 6,
            startHour = 12,
            startMinute = 10,
            endHour = 12,
            endMinute = 50,
            durationMinutes = 40,
            breakAfterMinutes = 30,
            isLunchAfter = false
        )
    )

    data class DefaultLessonItem(
        val dayOfWeek: Int,
        val lessonNumber: Int,
        val subject: String,
        val cabinet: String,
        val teacher: String = ""
    )

    val grade5BSchedule: List<DefaultLessonItem> = listOf(
        // Понедельник (1)
        DefaultLessonItem(1, 1, "Разговор о важном", "309А"),
        DefaultLessonItem(1, 2, "Физ-ра", "Спортзал"),
        DefaultLessonItem(1, 3, "Музыка", "311В"),
        DefaultLessonItem(1, 4, "Математика", "209Г"),
        DefaultLessonItem(1, 5, "Русский язык", "107Г"),
        DefaultLessonItem(1, 6, "История", "309Г"),

        // Вторник (2)
        DefaultLessonItem(2, 1, "Литература", "107Г"),
        DefaultLessonItem(2, 2, "География", "216А"),
        DefaultLessonItem(2, 3, "Математика", "209Г"),
        DefaultLessonItem(2, 4, "Русский язык", "107Г"),
        DefaultLessonItem(2, 5, "Английский язык", "132В"),

        // Среда (3)
        DefaultLessonItem(3, 1, "Математика", "209Г"),
        DefaultLessonItem(3, 2, "Русский язык", "107Г"),
        DefaultLessonItem(3, 3, "Литература", "107Г"),
        DefaultLessonItem(3, 4, "Труд", "115Б / 119Б"),
        DefaultLessonItem(3, 5, "Труд", "115Б / 119Б"),
        DefaultLessonItem(3, 6, "Физ-ра", "Спортзал"),

        // Четверг (4)
        DefaultLessonItem(4, 1, "Математика", "209Г"),
        DefaultLessonItem(4, 2, "Русский язык", "107Г"),
        DefaultLessonItem(4, 3, "ИЗО", "129Б"),
        DefaultLessonItem(4, 4, "Биология", "213А"),
        DefaultLessonItem(4, 5, "Английский язык", "202Г"),
        DefaultLessonItem(4, 6, "История", "309Г"),

        // Пятница (5)
        DefaultLessonItem(5, 1, "Русский язык", "107Г"),
        DefaultLessonItem(5, 2, "История", "309Г"),
        DefaultLessonItem(5, 3, "Литература", "107Г"),
        DefaultLessonItem(5, 4, "Математика", "209Г"),
        DefaultLessonItem(5, 5, "Физ-ра", "Спортзал"),
        DefaultLessonItem(5, 6, "Семьеведение", "241Б")
    )

    val popularSubjects: List<String> = listOf(
        "Математика",
        "Русский язык",
        "Литература",
        "История",
        "Английский язык",
        "Биология",
        "География",
        "ИЗО",
        "Труд",
        "Физ-ра",
        "Музыка",
        "Семьеведение",
        "Разговор о важном",
        "Обществознание",
        "Информатика"
    )
}
