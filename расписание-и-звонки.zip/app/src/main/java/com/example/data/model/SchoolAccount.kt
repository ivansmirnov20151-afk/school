package com.example.data.model

data class SchoolAccount(
    val username: String,
    val password: String,
    val rawUrl: String? = null
)

data class HomeworkItem(
    val id: String,
    val subjectRu: String,
    val subjectEn: String,
    val date: String, // e.g. "16.09.2026" or "16.09"
    val task: String,
    val author: String,
    val timestamp: Long = System.currentTimeMillis()
)

sealed class AccountVerifyResult {
    data class Success(val account: SchoolAccount) : AccountVerifyResult()
    data class Error(val message: String) : AccountVerifyResult()
}

object SubjectHelper {
    private val subjectMap = mapOf(
        "русский язык" to "Russian",
        "русский" to "Russian",
        "литература" to "Literature",
        "математика" to "Math",
        "алгебра" to "Algebra",
        "геометрия" to "Geometry",
        "история" to "History",
        "обществознание" to "SocialStudies",
        "география" to "Geography",
        "биология" to "Biology",
        "информатика" to "Informatics",
        "английский язык" to "English",
        "английский" to "English",
        "иностранный язык" to "ForeignLanguage",
        "немецкий язык" to "German",
        "музыка" to "Music",
        "изо" to "Art",
        "технология" to "Technology",
        "физкультура" to "PE",
        "однкнр" to "ODNKNR",
        "разговоры о важном" to "ImportantConversations",
        "физика" to "Physics",
        "химия" to "Chemistry",
        "обж" to "OBZH"
    )

    fun getEnglishName(ruName: String): String {
        val trimmed = ruName.trim().lowercase()
        return subjectMap[trimmed] ?: transliterate(ruName)
    }

    private fun transliterate(text: String): String {
        val cyrillic = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя "
        val latin = arrayOf(
            "a", "b", "v", "g", "d", "e", "yo", "zh", "z", "i", "y", "k", "l", "m",
            "n", "o", "p", "r", "s", "t", "u", "f", "kh", "ts", "ch", "sh", "shch",
            "", "y", "", "e", "yu", "ya", "_"
        )
        val sb = StringBuilder()
        for (ch in text.lowercase()) {
            val idx = cyrillic.indexOf(ch)
            if (idx >= 0 && idx < latin.size) {
                sb.append(latin[idx])
            } else if (ch.isLetterOrDigit()) {
                sb.append(ch)
            }
        }
        return sb.toString().replaceFirstChar { it.uppercase() }.ifEmpty { "Subject" }
    }
}
