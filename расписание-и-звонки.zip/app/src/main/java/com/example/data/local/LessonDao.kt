package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonDao {

    @Query("SELECT * FROM lessons ORDER BY dayOfWeek ASC, lessonNumber ASC")
    fun getAllLessons(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE dayOfWeek = :dayOfWeek AND (overrideDate IS NULL OR overrideDate = :dateStr) ORDER BY lessonNumber ASC")
    fun getLessonsForDay(dayOfWeek: Int, dateStr: String): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE dayOfWeek = :dayOfWeek AND lessonNumber = :lessonNum AND overrideDate = :dateStr LIMIT 1")
    suspend fun getDailyOverride(dayOfWeek: Int, lessonNum: Int, dateStr: String): LessonEntity?

    @Query("SELECT * FROM lessons WHERE dayOfWeek = :dayOfWeek AND lessonNumber = :lessonNum AND overrideDate IS NULL LIMIT 1")
    suspend fun getPermanentLesson(dayOfWeek: Int, lessonNum: Int): LessonEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLesson(lesson: LessonEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLessons(lessons: List<LessonEntity>)

    @Update
    suspend fun updateLesson(lesson: LessonEntity)

    @Query("DELETE FROM lessons WHERE id = :id")
    suspend fun deleteLessonById(id: Long)

    @Query("DELETE FROM lessons WHERE overrideDate = :dateStr")
    suspend fun clearOverridesForDate(dateStr: String)

    @Query("DELETE FROM lessons")
    suspend fun deleteAllLessons()

    @Query("SELECT COUNT(*) FROM lessons WHERE overrideDate IS NULL")
    suspend fun getPermanentLessonsCount(): Int
}
