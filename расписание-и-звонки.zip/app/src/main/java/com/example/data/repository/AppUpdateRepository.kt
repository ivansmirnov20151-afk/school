package com.example.data.repository

import com.example.data.model.ParsedUpdatePayload
import com.example.data.model.UpdateCheckResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class AppUpdateRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .callTimeout(5, TimeUnit.SECONDS)
        .build()
) {

    companion object {
        const val UPDATE_CHECK_URL = "https://raw.githubusercontent.com/ivansmirnov20151-afk/chiat/refs/heads/main/shcoolupdata"
        const val CURRENT_APP_VERSION = "2.0.0"
    }

    suspend fun checkForUpdates(): UpdateCheckResult = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(UPDATE_CHECK_URL)
                .cacheControl(CacheControl.Builder().noCache().noStore().build())
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext UpdateCheckResult.NetworkError("HTTP ${response.code}")
            }

            val body = response.body?.string()?.trim()
            if (body.isNullOrEmpty()) {
                return@withContext UpdateCheckResult.NetworkError("Пустой ответ от сервера")
            }

            val parsed = parseUpdatePayload(body)
            val remoteVer = parsed.remoteVersion

            if (remoteVer != null && isVersionDifferentOrNewer(remoteVer, CURRENT_APP_VERSION)) {
                UpdateCheckResult.UpdateRequired(
                    remoteVersion = remoteVer,
                    announcement = parsed.announcement,
                    updateUrl = parsed.updateUrl,
                    currentVersion = CURRENT_APP_VERSION
                )
            } else {
                UpdateCheckResult.UpToDate(
                    remoteVersion = remoteVer,
                    announcement = parsed.announcement
                )
            }
        } catch (e: Exception) {
            // No internet, DNS failure, timeout, etc. -> Return NetworkError so app continues gracefully
            UpdateCheckResult.NetworkError(e.message ?: "Нет подключения к сети")
        }
    }

    fun parseUpdatePayload(text: String): ParsedUpdatePayload {
        var version: String? = null
        var updateUrl: String? = null
        var announcement: String? = null

        val lines = text.lines()
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue

            when {
                trimmed.startsWith("version-", ignoreCase = true) -> {
                    version = trimmed.substringAfter("version-", "").trim()
                }
                trimmed.startsWith("version:", ignoreCase = true) -> {
                    version = trimmed.substringAfter("version:", "").trim()
                }
                trimmed.startsWith("version=", ignoreCase = true) -> {
                    version = trimmed.substringAfter("version=", "").trim()
                }
                trimmed.startsWith("updata-", ignoreCase = true) -> {
                    val rawUrl = trimmed.substringAfter("updata-", "").trim()
                    if (!rawUrl.equals("not", ignoreCase = true) &&
                        !rawUrl.equals("none", ignoreCase = true) &&
                        rawUrl.isNotEmpty()
                    ) {
                        updateUrl = rawUrl
                    }
                }
                trimmed.startsWith("updata:", ignoreCase = true) -> {
                    val rawUrl = trimmed.substringAfter("updata:", "").trim()
                    if (!rawUrl.equals("not", ignoreCase = true) &&
                        !rawUrl.equals("none", ignoreCase = true) &&
                        rawUrl.isNotEmpty()
                    ) {
                        updateUrl = rawUrl
                    }
                }
                trimmed.startsWith("ancoment-", ignoreCase = true) -> {
                    val rawAnnounce = trimmed.substringAfter("ancoment-", "").trim()
                    if (!rawAnnounce.equals("not", ignoreCase = true) &&
                        !rawAnnounce.equals("none", ignoreCase = true) &&
                        rawAnnounce.isNotEmpty()
                    ) {
                        announcement = rawAnnounce
                    }
                }
                trimmed.startsWith("ancoment:", ignoreCase = true) -> {
                    val rawAnnounce = trimmed.substringAfter("ancoment:", "").trim()
                    if (!rawAnnounce.equals("not", ignoreCase = true) &&
                        !rawAnnounce.equals("none", ignoreCase = true) &&
                        rawAnnounce.isNotEmpty()
                    ) {
                        announcement = rawAnnounce
                    }
                }
            }
        }

        // Fallback cleanup of version
        val cleanVersion = version?.removePrefix("version-")?.removePrefix("v")?.trim()

        return ParsedUpdatePayload(
            remoteVersion = cleanVersion,
            updateUrl = updateUrl,
            announcement = announcement,
            rawText = text
        )
    }

    private fun isVersionDifferentOrNewer(remoteVersion: String, currentVersion: String): Boolean {
        val cleanRemote = remoteVersion.removePrefix("v").trim()
        val cleanCurrent = currentVersion.removePrefix("v").trim()

        if (cleanRemote.isEmpty()) return false
        if (cleanRemote == cleanCurrent) return false

        // Compare semantic version numbers if format x.y.z
        return try {
            val remoteParts = cleanRemote.split(".").map { it.toIntOrNull() ?: 0 }
            val currentParts = cleanCurrent.split(".").map { it.toIntOrNull() ?: 0 }
            val maxLen = maxOf(remoteParts.size, currentParts.size)

            for (i in 0 until maxLen) {
                val r = remoteParts.getOrElse(i) { 0 }
                val c = currentParts.getOrElse(i) { 0 }
                if (r > c) return true
                if (r < c) return false
            }
            // If parts are identical, compare raw string difference
            cleanRemote != cleanCurrent
        } catch (e: Exception) {
            cleanRemote != cleanCurrent
        }
    }
}
