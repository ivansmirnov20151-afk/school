package com.example.data.model

data class SubjectGrades(
    val subjectName: String,
    val grades: List<Int> = emptyList()
) {
    val average: Double
        get() = if (grades.isEmpty()) 0.0 else grades.average()

    val totalPoints: Int
        get() = grades.sum()
}

data class GradesSummary(
    val subjects: List<SubjectGrades>,
    val overallAverage: Double,
    val totalPoints: Int,
    val totalCount: Int,
    val countFives: Int,
    val countFours: Int,
    val countThrees: Int,
    val countTwos: Int
) {
    val rankTitle: String
        get() = when {
            totalCount == 0 -> "Оценки пока не выставлены"
            overallAverage >= 4.75 -> "Круглый отличник 🌟"
            overallAverage >= 4.5 -> "Отличник 🎖️"
            overallAverage >= 3.75 -> "Ударник учёбы 📚"
            overallAverage >= 3.0 -> "Хороший старт 🚀"
            else -> "Нужно подтянуть предметы ✍️"
        }
}

object DefaultSubjects {
    val LIST = listOf(
        "Математика",
        "Русский язык",
        "Литература",
        "История",
        "Обществознание",
        "Биология",
        "Английский язык",
        "География",
        "Информатика",
        "Технология",
        "Музыка",
        "ИЗО",
        "Физкультура"
    )

    fun createInitialSubjects(): List<SubjectGrades> {
        return listOf(
            SubjectGrades("Математика", listOf(5, 5, 4)),
            SubjectGrades("Русский язык", listOf(5, 4, 5)),
            SubjectGrades("Литература", listOf(5, 5)),
            SubjectGrades("История", listOf(4, 5)),
            SubjectGrades("Обществознание", listOf(5)),
            SubjectGrades("Биология", listOf(5, 4)),
            SubjectGrades("Английский язык", listOf(4, 5)),
            SubjectGrades("География", listOf(5)),
            SubjectGrades("Информатика", listOf(5, 5)),
            SubjectGrades("Технология", listOf(5)),
            SubjectGrades("Музыка", listOf(5)),
            SubjectGrades("ИЗО", listOf(5)),
            SubjectGrades("Физкультура", listOf(5, 5))
        )
    }
}
