package com.example.data.repository

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiAiRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        private const val MODEL_NAME = "gemini-3.5-flash"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

        const val SYSTEM_PROMPT = """Ты — умный, чуткий и доброжелательный школьный репетитор и наставник для учеников 5-го класса.
ТВОЁ ГЛАВНОЕ И НЕПРЕЛОЖНОЕ ПРАВИЛО:
НИКОГДА НЕ ДАВАЙ ГОТОВЫЙ ОТВЕТ НА ЗАДАЧУ ИЛИ ДОМАШНЕЕ ЗАДАНИЕ! НИ ПРИ КАКИХ ОБСТОЯТЕЛЬСТВАХ!
Если ученик просит: "дай ответ", "реши за меня", "напиши готовое решение", "скажи число" — категорически НЕ давай готовый результат.
ВМЕСТО ЭТОГО:
1. Подробно и понятно ОБЪЯСНЯЙ суть темы, правила, формулы и логику шагов простыми словами и примерами.
2. Задавай наводящие вопросы и подсказывай направление мысли, чтобы ученик САМ понял решение и сам нашел правильный ответ!
3. Хвали за старания и вежливо подбадривай.
4. Отвечай красиво, структурированно, понятными абзацами.
Формат работы: только текст (фото отправлять нельзя)."""
    }

    suspend fun generateExplanation(
        conversationHistory: List<Pair<String, String>>,
        newUserMessage: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val apiKey = try {
                BuildConfig.GEMINI_API_KEY
            } catch (_: Throwable) {
                ""
            }

            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    Exception("Включите VPN для старта общения с нейросетью или настройте доступ.")
                )
            }

            val rootJson = JSONObject()

            // System instruction (never shown to the user in chat)
            val systemInstObj = JSONObject()
            val systemParts = JSONArray()
            systemParts.put(JSONObject().put("text", SYSTEM_PROMPT))
            systemInstObj.put("parts", systemParts)
            rootJson.put("systemInstruction", systemInstObj)

            // Conversation turns
            val contentsArray = JSONArray()
            for ((role, text) in conversationHistory) {
                val contentObj = JSONObject()
                contentObj.put("role", if (role == "user") "user" else "model")
                val parts = JSONArray()
                parts.put(JSONObject().put("text", text))
                contentObj.put("parts", parts)
                contentsArray.put(contentObj)
            }

            // Current message
            val currentContent = JSONObject()
            currentContent.put("role", "user")
            val currentParts = JSONArray()
            currentParts.put(JSONObject().put("text", newUserMessage))
            currentContent.put("parts", currentParts)
            contentsArray.put(currentContent)

            rootJson.put("contents", contentsArray)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = rootJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful) {
                return@withContext Result.failure(
                    Exception("Включите VPN для старта общения с нейросетью (код ошибки ${response.code}).")
                )
            }

            if (responseBody.isNullOrBlank()) {
                return@withContext Result.failure(
                    Exception("Включите VPN для старта общения с нейросетью: пустой ответ от сервера.")
                )
            }

            val respJson = JSONObject(responseBody)
            val candidates = respJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.failure(
                    Exception("Включите VPN для старта общения с нейросетью.")
                )
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text")

            if (text.isNullOrBlank()) {
                return@withContext Result.failure(
                    Exception("Включите VPN для старта общения с нейросетью.")
                )
            }

            Result.success(text)
        } catch (e: Exception) {
            Result.failure(
                Exception("Включите VPN для старта общения с нейросетью (${e.localizedMessage ?: "ошибка сети"}).")
            )
        }
    }
}
