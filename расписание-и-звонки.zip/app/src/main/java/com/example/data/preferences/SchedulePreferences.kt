package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences

class SchedulePreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("school_schedule_prefs", Context.MODE_PRIVATE)

    var pinCode: String
        get() = prefs.getString(KEY_PIN_CODE, "2015") ?: "2015"
        set(value) = prefs.edit().putString(KEY_PIN_CODE, value).apply()

    var isNotificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, value).apply()

    var notifyMinutesBefore: Int
        get() = prefs.getInt(KEY_NOTIFY_MINUTES_BEFORE, 5)
        set(value) = prefs.edit().putInt(KEY_NOTIFY_MINUTES_BEFORE, value).apply()

    var isAutoTrackActiveLesson: Boolean
        get() = prefs.getBoolean(KEY_AUTO_TRACK, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_TRACK, value).apply()

    var selectedClassName: String
        get() = prefs.getString(KEY_CLASS_NAME, "5Б") ?: "5Б"
        set(value) = prefs.edit().putString(KEY_CLASS_NAME, value).apply()

    var manualActiveLessonNumber: Int
        get() = prefs.getInt(KEY_MANUAL_LESSON, -1)
        set(value) = prefs.edit().putInt(KEY_MANUAL_LESSON, value).apply()

    var hasDismissedAiAnnouncement: Boolean
        get() = prefs.getBoolean(KEY_AI_ANNOUNCEMENT_DISMISSED, false)
        set(value) = prefs.edit().putBoolean(KEY_AI_ANNOUNCEMENT_DISMISSED, value).apply()

    var isVotedOrUnlocked: Boolean
        get() = prefs.getBoolean(KEY_VOTED_OR_UNLOCKED, false)
        set(value) = prefs.edit().putBoolean(KEY_VOTED_OR_UNLOCKED, value).apply()

    var childVerificationStatus: String
        get() = prefs.getString(KEY_CHILD_VERIFICATION_STATUS, "none") ?: "none"
        set(value) = prefs.edit().putString(KEY_CHILD_VERIFICATION_STATUS, value).apply()

    var childVerificationSubmitTime: Long
        get() = prefs.getLong(KEY_CHILD_VERIFICATION_SUBMIT_TIME, 0L)
        set(value) = prefs.edit().putLong(KEY_CHILD_VERIFICATION_SUBMIT_TIME, value).apply()

    var childStudentFio: String
        get() = prefs.getString(KEY_CHILD_STUDENT_FIO, "") ?: ""
        set(value) = prefs.edit().putString(KEY_CHILD_STUDENT_FIO, value).apply()

    var childStudentBirthDate: String
        get() = prefs.getString(KEY_CHILD_STUDENT_BIRTH_DATE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_CHILD_STUDENT_BIRTH_DATE, value).apply()

    var isUserRegistered: Boolean
        get() = prefs.getBoolean(KEY_USER_REGISTERED, false)
        set(value) = prefs.edit().putBoolean(KEY_USER_REGISTERED, value).apply()

    var isGuestUser: Boolean
        get() = prefs.getBoolean(KEY_IS_GUEST, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_GUEST, value).apply()

    var userLogin: String
        get() = prefs.getString(KEY_USER_LOGIN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_LOGIN, value).apply()

    var userDisplayName: String
        get() = prefs.getString(KEY_USER_DISPLAY_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_DISPLAY_NAME, value).apply()

    var userRawHomeworkUrl: String
        get() = prefs.getString(KEY_USER_RAW_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_RAW_URL, value).apply()

    var canPublishHomework: Boolean
        get() = prefs.getBoolean(KEY_CAN_PUBLISH_HW, false)
        set(value) = prefs.edit().putBoolean(KEY_CAN_PUBLISH_HW, value).apply()

    var cachedHomeworkJson: String
        get() = prefs.getString(KEY_CACHED_HOMEWORK, "[]") ?: "[]"
        set(value) = prefs.edit().putString(KEY_CACHED_HOMEWORK, value).apply()

    fun loadSubjectGrades(): List<com.example.data.model.SubjectGrades> {
        val jsonStr = prefs.getString(KEY_GRADES_JSON, null)
        if (jsonStr.isNullOrBlank()) {
            val initial = com.example.data.model.DefaultSubjects.createInitialSubjects()
            saveSubjectGrades(initial)
            return initial
        }
        return try {
            val array = org.json.JSONArray(jsonStr)
            val result = mutableListOf<com.example.data.model.SubjectGrades>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val name = obj.getString("subjectName")
                val gradesArr = obj.getJSONArray("grades")
                val grades = mutableListOf<Int>()
                for (j in 0 until gradesArr.length()) {
                    grades.add(gradesArr.getInt(j))
                }
                result.add(com.example.data.model.SubjectGrades(name, grades))
            }
            if (result.isEmpty()) {
                val initial = com.example.data.model.DefaultSubjects.createInitialSubjects()
                saveSubjectGrades(initial)
                initial
            } else {
                result
            }
        } catch (_: Exception) {
            val initial = com.example.data.model.DefaultSubjects.createInitialSubjects()
            saveSubjectGrades(initial)
            initial
        }
    }

    fun saveSubjectGrades(subjects: List<com.example.data.model.SubjectGrades>) {
        val array = org.json.JSONArray()
        for (subj in subjects) {
            val obj = org.json.JSONObject()
            obj.put("subjectName", subj.subjectName)
            val gradesArr = org.json.JSONArray()
            subj.grades.forEach { gradesArr.put(it) }
            obj.put("grades", gradesArr)
            array.put(obj)
        }
        prefs.edit().putString(KEY_GRADES_JSON, array.toString()).apply()
    }

    companion object {
        private const val KEY_PIN_CODE = "pin_code"
        private const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        private const val KEY_NOTIFY_MINUTES_BEFORE = "notify_minutes_before"
        private const val KEY_AUTO_TRACK = "auto_track_active_lesson"
        private const val KEY_CLASS_NAME = "selected_class_name"
        private const val KEY_MANUAL_LESSON = "manual_active_lesson"
        private const val KEY_AI_ANNOUNCEMENT_DISMISSED = "ai_announcement_dismissed"
        private const val KEY_VOTED_OR_UNLOCKED = "voted_or_unlocked"
        private const val KEY_CHILD_VERIFICATION_STATUS = "child_verification_status"
        private const val KEY_CHILD_VERIFICATION_SUBMIT_TIME = "child_verification_submit_time"
        private const val KEY_CHILD_STUDENT_FIO = "child_student_fio"
        private const val KEY_CHILD_STUDENT_BIRTH_DATE = "child_student_birth_date"
        private const val KEY_GRADES_JSON = "grades_json_v1"
        private const val KEY_USER_REGISTERED = "user_registered"
        private const val KEY_IS_GUEST = "is_guest"
        private const val KEY_USER_LOGIN = "user_login"
        private const val KEY_USER_DISPLAY_NAME = "user_display_name"
        private const val KEY_USER_RAW_URL = "user_raw_url"
        private const val KEY_CAN_PUBLISH_HW = "can_publish_hw"
        private const val KEY_CACHED_HOMEWORK = "cached_homework_v1"
    }
}
