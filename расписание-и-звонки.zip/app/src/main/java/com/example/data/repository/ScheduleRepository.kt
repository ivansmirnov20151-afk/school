package com.example.data.repository

import com.example.data.local.LessonDao
import com.example.data.local.LessonEntity
import com.example.data.model.BellSlot
import com.example.data.model.DefaultSchedule
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScheduleRepository(
    private val lessonDao: LessonDao
) {

    val allLessons: Flow<List<LessonEntity>> = lessonDao.getAllLessons()

    suspend fun ensureDefaultSchedulePopulated() {
        val count = lessonDao.getPermanentLessonsCount()
        if (count == 0) {
            val entities = DefaultSchedule.grade5BSchedule.map { item ->
                LessonEntity(
                    dayOfWeek = item.dayOfWeek,
                    lessonNumber = item.lessonNumber,
                    subject = item.subject,
                    cabinet = item.cabinet,
                    teacher = item.teacher,
                    isOverrideForToday = false,
                    overrideDate = null
                )
            }
            lessonDao.insertLessons(entities)
        }
    }

    suspend fun resetToDefaultSchedule() {
        lessonDao.deleteAllLessons()
        val entities = DefaultSchedule.grade5BSchedule.map { item ->
            LessonEntity(
                dayOfWeek = item.dayOfWeek,
                lessonNumber = item.lessonNumber,
                subject = item.subject,
                cabinet = item.cabinet,
                teacher = item.teacher,
                isOverrideForToday = false,
                overrideDate = null
            )
        }
        lessonDao.insertLessons(entities)
    }

    fun getLessonsForDay(dayOfWeek: Int, dateStr: String): Flow<List<LessonEntity>> {
        return lessonDao.getLessonsForDay(dayOfWeek, dateStr)
    }

    suspend fun updateLessonPermanent(
        dayOfWeek: Int,
        lessonNumber: Int,
        subject: String,
        cabinet: String,
        teacher: String,
        existingId: Long? = null
    ) {
        val permanent = lessonDao.getPermanentLesson(dayOfWeek, lessonNumber)
        if (permanent != null) {
            lessonDao.updateLesson(
                permanent.copy(
                    subject = subject,
                    cabinet = cabinet,
                    teacher = teacher
                )
            )
        } else {
            lessonDao.insertLesson(
                LessonEntity(
                    id = existingId ?: 0L,
                    dayOfWeek = dayOfWeek,
                    lessonNumber = lessonNumber,
                    subject = subject,
                    cabinet = cabinet,
                    teacher = teacher,
                    isOverrideForToday = false,
                    overrideDate = null
                )
            )
        }
    }

    suspend fun updateLessonForDate(
        dayOfWeek: Int,
        lessonNumber: Int,
        dateStr: String,
        subject: String,
        cabinet: String,
        teacher: String
    ) {
        val existingOverride = lessonDao.getDailyOverride(dayOfWeek, lessonNumber, dateStr)
        if (existingOverride != null) {
            lessonDao.updateLesson(
                existingOverride.copy(
                    subject = subject,
                    cabinet = cabinet,
                    teacher = teacher
                )
            )
        } else {
            lessonDao.insertLesson(
                LessonEntity(
                    dayOfWeek = dayOfWeek,
                    lessonNumber = lessonNumber,
                    subject = subject,
                    cabinet = cabinet,
                    teacher = teacher,
                    isOverrideForToday = true,
                    overrideDate = dateStr
                )
            )
        }
    }

    suspend fun deleteLesson(lesson: LessonEntity) {
        lessonDao.deleteLessonById(lesson.id)
    }

    fun getBellSlots(): List<BellSlot> {
        return DefaultSchedule.bellsGrade5Shift1
    }

    companion object {
        fun getTodayDateString(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            return sdf.format(Date())
        }
    }
}
