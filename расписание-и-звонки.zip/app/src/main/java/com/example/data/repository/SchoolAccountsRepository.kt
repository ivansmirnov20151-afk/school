package com.example.data.repository

import com.example.data.model.AccountVerifyResult
import com.example.data.model.HomeworkItem
import com.example.data.model.SchoolAccount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.UUID
import java.util.concurrent.TimeUnit

class SchoolAccountsRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .build()
) {

    companion object {
        const val ACCOUNTS_PRIMARY_URL =
            "https://raw.githubusercontent.com/ivansmirnov20151-afk/school/refs/heads/main/accounts"
        const val ACCOUNTS_FALLBACK_URL =
            "https://raw.githubusercontent.com/ivansmirnov20151-afk/school/main/accounts"
    }

    suspend fun fetchAccounts(): List<SchoolAccount> = withContext(Dispatchers.IO) {
        val rawText = fetchUrlContent(ACCOUNTS_PRIMARY_URL) ?: fetchUrlContent(ACCOUNTS_FALLBACK_URL)
        if (rawText.isNullOrBlank()) {
            return@withContext emptyList()
        }
        parseAccounts(rawText)
    }

    suspend fun verifyLogin(login: String, pass: String): AccountVerifyResult = withContext(Dispatchers.IO) {
        val trimmedLogin = login.trim()
        val trimmedPass = pass.trim()

        if (trimmedLogin.isEmpty()) {
            return@withContext AccountVerifyResult.Error("Поле логина не может быть пустым. Введите логин.")
        }
        if (trimmedPass.isEmpty()) {
            return@withContext AccountVerifyResult.Error("Поле пароля не может быть пустым. Введите пароль.")
        }

        val accounts = fetchAccounts()
        if (accounts.isEmpty()) {
            return@withContext AccountVerifyResult.Error(
                "Не удалось загрузить базу аккаунтов. Проверьте интернет-соединение или доступность GitHub."
            )
        }

        val matchedAccount = accounts.firstOrNull { it.username.equals(trimmedLogin, ignoreCase = true) }
            ?: return@withContext AccountVerifyResult.Error(
                "Логин '$trimmedLogin' отсутствует в списке зарегистрированных аккаунтов школы."
            )

        if (matchedAccount.password != trimmedPass) {
            return@withContext AccountVerifyResult.Error(
                "Неверный пароль для пользователя '$trimmedLogin'. Проверьте введённые символы."
            )
        }

        AccountVerifyResult.Success(matchedAccount)
    }

    suspend fun checkUserRawUrl(username: String): String? = withContext(Dispatchers.IO) {
        val accounts = fetchAccounts()
        accounts.firstOrNull { it.username.equals(username.trim(), ignoreCase = true) }?.rawUrl
    }

    suspend fun fetchAllHomework(accounts: List<SchoolAccount>): List<HomeworkItem> = withContext(Dispatchers.IO) {
        val allItems = mutableListOf<HomeworkItem>()
        for (account in accounts) {
            val url = account.rawUrl ?: continue
            try {
                val content = fetchUrlContent(url) ?: continue
                val parsed = parseHomeworkFile(content, account.username)
                allItems.addAll(parsed)
            } catch (_: Exception) {
                // Ignore individual network or parsing issues
            }
        }
        allItems.distinctBy { "${it.subjectRu}_${it.date}_${it.task}" }
    }

    suspend fun verifyPublishedHomework(
        rawUrl: String,
        expectedTask: String,
        expectedDate: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val content = fetchUrlContent(rawUrl) ?: return@withContext false
            val normalizedContent = content.lowercase()
            val normalizedDate = expectedDate.trim().lowercase()
            val normalizedTask = expectedTask.trim().lowercase()

            val hasDate = normalizedContent.contains(normalizedDate)
            // Take the first 15 characters of task for flexible matching
            val taskSnippet = if (normalizedTask.length > 15) normalizedTask.take(15) else normalizedTask
            val hasTask = normalizedContent.contains(taskSnippet)

            hasDate && hasTask
        } catch (_: Exception) {
            false
        }
    }

    private fun fetchUrlContent(url: String): String? {
        return try {
            val request = Request.Builder()
                .url(url)
                .cacheControl(CacheControl.Builder().noCache().noStore().build())
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                response.body?.string()
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseAccounts(rawText: String): List<SchoolAccount> {
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val result = mutableListOf<SchoolAccount>()
        var currentUsername: String? = null
        var currentPassword = ""
        var currentRawUrl: String? = null

        for (line in lines) {
            val lower = line.lowercase()
            when {
                lower.startsWith("passworld:") || lower.startsWith("password:") || lower.startsWith("pass:") -> {
                    currentPassword = line.substringAfter(":").trim()
                }
                lower.startsWith("raw:") || lower.startsWith("raw :") -> {
                    val candidate = line.substringAfter(":").trim()
                    currentRawUrl = if (candidate.startsWith("http")) {
                        candidate
                    } else if (line.contains("http")) {
                        line.substring(line.indexOf("http")).trim()
                    } else {
                        candidate
                    }
                }
                else -> {
                    // Encountered new username
                    if (currentUsername != null && currentPassword.isNotEmpty()) {
                        result.add(SchoolAccount(currentUsername, currentPassword, currentRawUrl))
                    }
                    currentUsername = line
                    currentPassword = ""
                    currentRawUrl = null
                }
            }
        }
        if (currentUsername != null && currentPassword.isNotEmpty()) {
            result.add(SchoolAccount(currentUsername, currentPassword, currentRawUrl))
        }
        return result
    }

    private fun parseHomeworkFile(content: String, defaultAuthor: String): List<HomeworkItem> {
        val result = mutableListOf<HomeworkItem>()
        val blocks = content.split("=== HOMEWORK ===", "=== HOMEWORK===", "===HOMEWORK===")

        for (block in blocks) {
            val trimmedBlock = block.trim()
            if (trimmedBlock.isEmpty()) continue

            var subjectRu = ""
            var subjectEn = ""
            var date = ""
            var task = ""
            var author = defaultAuthor

            val lines = trimmedBlock.lines()
            for (line in lines) {
                val trimmedLine = line.trim()
                val lower = trimmedLine.lowercase()
                when {
                    lower.startsWith("subject_ru:") || lower.startsWith("предмет:") -> {
                        subjectRu = trimmedLine.substringAfter(":").trim()
                    }
                    lower.startsWith("subject:") || lower.startsWith("subject_en:") -> {
                        subjectEn = trimmedLine.substringAfter(":").trim()
                    }
                    lower.startsWith("date:") || lower.startsWith("дата:") -> {
                        date = trimmedLine.substringAfter(":").trim()
                    }
                    lower.startsWith("task:") || lower.startsWith("задание:") || lower.startsWith("дз:") -> {
                        task = trimmedLine.substringAfter(":").trim()
                    }
                    lower.startsWith("author:") || lower.startsWith("автор:") -> {
                        author = trimmedLine.substringAfter(":").trim()
                    }
                    trimmedLine.contains("|") -> {
                        // Support single line format: Subject | Date | Task
                        val parts = trimmedLine.split("|").map { it.trim() }
                        if (parts.size >= 3) {
                            subjectRu = parts[0]
                            date = parts[1]
                            task = parts[2]
                        }
                    }
                }
            }

            if (subjectRu.isNotEmpty() && task.isNotEmpty()) {
                if (subjectEn.isEmpty()) {
                    subjectEn = com.example.data.model.SubjectHelper.getEnglishName(subjectRu)
                }
                result.add(
                    HomeworkItem(
                        id = UUID.randomUUID().toString(),
                        subjectRu = subjectRu,
                        subjectEn = subjectEn,
                        date = date.ifEmpty { "На след. урок" },
                        task = task,
                        author = author.ifEmpty { defaultAuthor }
                    )
                )
            }
        }
        return result
    }
}
