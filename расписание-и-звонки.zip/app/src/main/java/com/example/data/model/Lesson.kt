package com.example.data.model

data class BellSlot(
    val lessonNumber: Int,
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int,
    val durationMinutes: Int,
    val breakAfterMinutes: Int,
    val isLunchAfter: Boolean = false // e.g. 11:05 - 11:25 is the lunch meal break
) {
    val startTimeFormatted: String
        get() = String.format("%02d:%02d", startHour, startMinute)

    val endTimeFormatted: String
        get() = String.format("%02d:%02d", endHour, endMinute)

    val timeRangeFormatted: String
        get() = "$startTimeFormatted – $endTimeFormatted"
}

enum class DayOfWeekRussian(val dayNumber: Int, val shortName: String, val fullName: String) {
    MONDAY(1, "Пн", "Понедельник"),
    TUESDAY(2, "Вт", "Вторник"),
    WEDNESDAY(3, "Ср", "Среда"),
    THURSDAY(4, "Чт", "Четверг"),
    FRIDAY(5, "Пт", "Пятница"),
    SATURDAY(6, "Сб", "Суббота"),
    SUNDAY(7, "Вс", "Воскресенье");

    companion object {
        fun fromDayNumber(day: Int): DayOfWeekRussian {
            return entries.firstOrNull { it.dayNumber == day } ?: MONDAY
        }
    }
}

enum class SchoolTimeStatus {
    BEFORE_SCHOOL,
    IN_LESSON,
    IN_BREAK,
    IN_LUNCH_BREAK,
    AFTER_SCHOOL,
    WEEKEND
}

data class CurrentStatusInfo(
    val status: SchoolTimeStatus,
    val activeLessonNumber: Int?,
    val activeSubject: String?,
    val activeCabinet: String?,
    val nextLessonNumber: Int?,
    val nextSubject: String?,
    val nextCabinet: String?,
    val secondsRemaining: Long,
    val totalSeconds: Long,
    val progressFraction: Float,
    val formattedRemainingTime: String,
    val statusHeadline: String,
    val statusSubtext: String,
    val lessonsUntilLunch: Int,
    val lunchTimeText: String
)
