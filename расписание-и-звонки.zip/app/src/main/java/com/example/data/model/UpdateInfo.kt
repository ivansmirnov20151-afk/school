package com.example.data.model

sealed interface UpdateCheckResult {
    data class UpdateRequired(
        val remoteVersion: String,
        val announcement: String?,
        val updateUrl: String?,
        val currentVersion: String
    ) : UpdateCheckResult

    data class UpToDate(
        val remoteVersion: String? = null,
        val announcement: String? = null
    ) : UpdateCheckResult

    data class NetworkError(
        val message: String
    ) : UpdateCheckResult
}

data class ParsedUpdatePayload(
    val remoteVersion: String? = null,
    val updateUrl: String? = null,
    val announcement: String? = null,
    val rawText: String = ""
)
