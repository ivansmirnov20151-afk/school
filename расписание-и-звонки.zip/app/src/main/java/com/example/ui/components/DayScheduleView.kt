package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Dining
import androidx.compose.material.icons.filled.DoorFront
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LessonEntity
import com.example.data.model.BellSlot
import com.example.data.model.DayOfWeekRussian
import com.example.ui.theme.GeoBorder
import com.example.ui.theme.GeoBorderLight
import com.example.ui.theme.GeoBorderPurple
import com.example.ui.theme.GeoOnPrimary
import com.example.ui.theme.GeoOnPrimaryContainer
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryContainer
import com.example.ui.theme.GeoSecondaryContainer
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceVariant
import com.example.ui.theme.GeoTextPrimary
import com.example.ui.theme.GeoTextSecondary

@Composable
fun DayScheduleView(
    selectedDay: DayOfWeekRussian,
    todayDay: DayOfWeekRussian,
    lessons: List<LessonEntity>,
    bells: List<BellSlot>,
    activeLessonNumber: Int?,
    homeworkList: List<com.example.data.model.HomeworkItem> = emptyList(),
    onSelectDay: (DayOfWeekRussian) -> Unit,
    onSelectToday: () -> Unit,
    onLessonClick: (LessonEntity) -> Unit,
    onAddLessonClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = GeoSurface),
        border = BorderStroke(1.dp, GeoBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header Row: "TIMELINE / РАСПИСАНИЕ УРОКОВ"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "РАСПИСАНИЕ УРОКОВ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = GeoTextSecondary
                )

                if (selectedDay != todayDay) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = GeoPrimaryContainer,
                        onClick = onSelectToday
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Today,
                                contentDescription = null,
                                tint = GeoOnPrimaryContainer,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Сегодня (${todayDay.shortName})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeoOnPrimaryContainer
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Days horizontal geometric selector
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(DayOfWeekRussian.entries) { day ->
                    val isSelected = day == selectedDay
                    val isToday = day == todayDay

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) GeoPrimary else GeoSurfaceVariant,
                        border = if (isSelected) null else BorderStroke(1.dp, GeoBorderLight),
                        onClick = { onSelectDay(day) },
                        modifier = Modifier.testTag("chip_day_${day.shortName}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = day.shortName,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) GeoOnPrimary else GeoTextPrimary
                            )
                            if (isToday) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) GeoSecondaryContainer else GeoPrimary)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Empty state
            if (lessons.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(GeoSurfaceVariant)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "На ${selectedDay.fullName.lowercase()} уроков нет",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeoTextPrimary
                        )
                        Text(
                            text = "Выходной день или свободное время",
                            fontSize = 12.sp,
                            color = GeoTextSecondary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                // Lessons timeline list
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    lessons.forEachIndexed { index, lesson ->
                        val bell = bells.firstOrNull { it.lessonNumber == lesson.lessonNumber }
                        val isActive = (selectedDay == todayDay) && (activeLessonNumber == lesson.lessonNumber)
                        val isAfterLunchBell = bell?.isLunchAfter == true
                        val hw = homeworkList.firstOrNull {
                            it.subjectRu.equals(lesson.subject, ignoreCase = true) ||
                            it.subjectEn.equals(lesson.subject, ignoreCase = true)
                        }

                        LessonRowCard(
                            lesson = lesson,
                            bellSlot = bell,
                            isActive = isActive,
                            homework = hw,
                            onClick = { onLessonClick(lesson) }
                        )

                        // Insert Lunch break banner between 4th and 5th lesson
                        if (isAfterLunchBell) {
                            LunchBreakDivider()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LessonRowCard(
    lesson: LessonEntity,
    bellSlot: BellSlot?,
    isActive: Boolean,
    homework: com.example.data.model.HomeworkItem? = null,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("lesson_card_${lesson.lessonNumber}"),
        shape = RoundedCornerShape(16.dp),
        color = if (isActive) GeoPrimaryContainer else GeoSurface,
        border = if (isActive)
            BorderStroke(1.5.dp, GeoPrimary)
        else
            BorderStroke(1.dp, GeoBorderLight)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Lesson Number & Time block
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(58.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (isActive) GeoPrimary else GeoSurfaceVariant,
                    modifier = Modifier.size(30.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "${lesson.lessonNumber}",
                            fontWeight = FontWeight.Bold,
                            color = if (isActive) GeoOnPrimary else GeoTextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = bellSlot?.startTimeFormatted ?: "08:00",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) GeoOnPrimaryContainer else GeoTextPrimary
                )
                Text(
                    text = bellSlot?.endTimeFormatted ?: "08:40",
                    fontSize = 10.sp,
                    color = GeoTextSecondary
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Main Details
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = lesson.subject,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) GeoOnPrimaryContainer else GeoTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (lesson.isOverrideForToday) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFEF3C7)
                        ) {
                            Text(
                                text = "Замена",
                                color = Color(0xFFB45309),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (isActive) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = GeoPrimary
                        ) {
                            Text(
                                text = "СЕЙЧАС",
                                color = GeoOnPrimary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isActive) Color.White.copy(alpha = 0.6f) else GeoSurfaceVariant
                    ) {
                        Text(
                            text = "Каб. ${lesson.cabinet}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isActive) GeoOnPrimaryContainer else GeoTextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (lesson.teacher.isNotBlank()) {
                        Text(
                            text = lesson.teacher,
                            fontSize = 11.sp,
                            color = GeoTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (homework != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isActive) Color.White.copy(alpha = 0.25f) else Color(0xFF6366F1).copy(alpha = 0.12f),
                        border = BorderStroke(
                            1.dp,
                            if (isActive) Color.White.copy(alpha = 0.45f) else Color(0xFF818CF8).copy(alpha = 0.35f)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = if (isActive) GeoOnPrimaryContainer else Color(0xFF6366F1),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ДЗ (${homework.date}): ${homework.task}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isActive) GeoOnPrimaryContainer else Color(0xFF4338CA),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Edit icon hint
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Изменить урок",
                tint = if (isActive) GeoPrimary else GeoTextSecondary.copy(alpha = 0.5f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun LunchBreakDivider() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        shape = RoundedCornerShape(14.dp),
        color = GeoPrimaryContainer.copy(alpha = 0.5f),
        border = BorderStroke(1.dp, GeoBorderPurple)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Dining,
                contentDescription = null,
                tint = GeoPrimary,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "Обед и питание: 11:05 – 11:25 (20 минут)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = GeoOnPrimaryContainer
            )
        }
    }
}
