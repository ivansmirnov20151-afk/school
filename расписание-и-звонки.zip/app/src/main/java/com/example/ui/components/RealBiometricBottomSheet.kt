package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class BiometricScanState {
    PROMPT,     // User needs to place finger
    SCANNING,   // Finger detected, verifying
    SUCCESS,    // Authenticated
    LOADING     // Loading application
}

@Composable
fun RealBiometricBottomSheet(
    isVisible: Boolean,
    onDismiss: () -> Unit,
    onSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = modifier
    ) {
        var scanState by remember { mutableStateOf(BiometricScanState.PROMPT) }

        LaunchedEffect(isVisible) {
            if (isVisible) {
                scanState = BiometricScanState.PROMPT
            }
        }

        val infiniteTransition = rememberInfiniteTransition(label = "biometricPulse")
        val pulseScale by infiniteTransition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.12f,
            animationSpec = infiniteRepeatable(
                animation = tween(750, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse"
        )

        LaunchedEffect(scanState) {
            if (scanState == BiometricScanState.SCANNING) {
                delay(700)
                scanState = BiometricScanState.SUCCESS
                delay(400)
                scanState = BiometricScanState.LOADING
                delay(500)
                onSuccess()
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 24.dp,
                        shape = RoundedCornerShape(28.dp),
                        spotColor = Color(0xFF8B5CF6).copy(alpha = 0.5f),
                        ambientColor = Color(0xFF1E1B4B).copy(alpha = 0.8f)
                    ),
                shape = RoundedCornerShape(28.dp),
                color = Color(0xFF1E1B4B).copy(alpha = 0.94f),
                border = BorderStroke(
                    1.dp,
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFFA78BFA).copy(alpha = 0.6f),
                            Color(0xFF8B5CF6).copy(alpha = 0.25f)
                        )
                    )
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF8B5CF6).copy(alpha = 0.25f),
                                border = BorderStroke(1.dp, Color(0xFFA78BFA))
                            ) {
                                Box(
                                    modifier = Modifier.size(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Fingerprint,
                                        contentDescription = null,
                                        tint = Color(0xFFDDD6FE),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "Вход по отпечатку пальца",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFF8FAFC)
                                )
                                Text(
                                    text = "Биометрическая аутентификация",
                                    fontSize = 11.sp,
                                    color = Color(0xFFC4B5FD)
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Закрыть",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Center Interactive Sensor Target
                    val sensorActive = scanState == BiometricScanState.SCANNING || scanState == BiometricScanState.PROMPT
                    val isSuccess = scanState == BiometricScanState.SUCCESS || scanState == BiometricScanState.LOADING

                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .scale(if (sensorActive) pulseScale else 1f)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = if (isSuccess) {
                                        listOf(
                                            Color(0xFF10B981).copy(alpha = 0.4f),
                                            Color(0xFF059669).copy(alpha = 0.1f),
                                            Color.Transparent
                                        )
                                    } else {
                                        listOf(
                                            Color(0xFF8B5CF6).copy(alpha = 0.45f),
                                            Color(0xFF6D28D9).copy(alpha = 0.15f),
                                            Color.Transparent
                                        )
                                    }
                                )
                            )
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                enabled = scanState == BiometricScanState.PROMPT
                            ) {
                                scanState = BiometricScanState.SCANNING
                            }
                            .testTag("biometric_sensor_surface"),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            modifier = Modifier.size(70.dp),
                            shape = CircleShape,
                            color = if (isSuccess) Color(0xFF064E3B) else Color(0xFF2E1065),
                            border = BorderStroke(
                                2.dp,
                                if (isSuccess) Color(0xFF34D399) else Color(0xFFA78BFA)
                            )
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (isSuccess) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Успешно",
                                        tint = Color(0xFF34D399),
                                        modifier = Modifier.size(36.dp)
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Fingerprint,
                                        contentDescription = "Сканер",
                                        tint = if (scanState == BiometricScanState.SCANNING) Color(0xFFF5F3FF) else Color(0xFFDDD6FE),
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dynamic Status Prompt
                    Text(
                        text = when (scanState) {
                            BiometricScanState.PROMPT -> "Приложите палец к сенсору"
                            BiometricScanState.SCANNING -> "Считывание отпечатка..."
                            BiometricScanState.SUCCESS -> "Отпечаток подтвержден!"
                            BiometricScanState.LOADING -> "Загрузка расписания..."
                        },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = when (scanState) {
                            BiometricScanState.SUCCESS, BiometricScanState.LOADING -> Color(0xFF34D399)
                            BiometricScanState.SCANNING -> Color(0xFFE9D5FF)
                            else -> Color(0xFFF8FAFC)
                        },
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = when (scanState) {
                            BiometricScanState.PROMPT -> "Нажмите на сенсор пальцем для быстрой авторизации"
                            BiometricScanState.SCANNING -> "Держите палец на сенсоре..."
                            BiometricScanState.SUCCESS -> "Добро пожаловать в систему 5Б"
                            BiometricScanState.LOADING -> "Синхронизация уроков и звонков..."
                        },
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Center
                    )

                    if (scanState == BiometricScanState.LOADING || scanState == BiometricScanState.SCANNING) {
                        Spacer(modifier = Modifier.height(14.dp))
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = if (scanState == BiometricScanState.LOADING) Color(0xFF34D399) else Color(0xFFA78BFA)
                        )
                    }
                }
            }
        }
    }
}
