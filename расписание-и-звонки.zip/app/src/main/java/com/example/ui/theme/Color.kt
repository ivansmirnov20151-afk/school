package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Palette
val GeoBackground = Color(0xFFF6F2F7)
val GeoSurface = Color(0xFFFFFFFF)
val GeoSurfaceVariant = Color(0xFFF3EDF7)
val GeoPrimary = Color(0xFF6750A4)
val GeoOnPrimary = Color(0xFFFFFFFF)
val GeoPrimaryContainer = Color(0xFFEADDFF)
val GeoOnPrimaryContainer = Color(0xFF21005D)
val GeoSecondaryContainer = Color(0xFFD0BCFF)
val GeoOnSecondaryContainer = Color(0xFF21005D)
val GeoTextPrimary = Color(0xFF1C1B1F)
val GeoTextSecondary = Color(0xFF49454F)
val GeoBorder = Color(0xFFCAC4D0)
val GeoBorderLight = Color(0xFFE7E0EC)
val GeoBorderPurple = Color(0xFFD0BCFF)
val GeoDarkCard = Color(0xFF1C1B1F)
val GeoGreenAccent = Color(0xFF4ADE80)

// Dark Theme equivalents
val GeoDarkBackground = Color(0xFF141218)
val GeoDarkSurface = Color(0xFF1D1B20)
val GeoDarkSurfaceVariant = Color(0xFF2B2830)
val GeoDarkPrimaryContainer = Color(0xFF381E72)
val GeoDarkOnPrimaryContainer = Color(0xFFEADDFF)
