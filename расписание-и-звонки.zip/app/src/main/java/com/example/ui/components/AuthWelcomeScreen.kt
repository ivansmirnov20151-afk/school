package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class AuthMode {
    CHOOSE,
    LOGIN_INPUT,
    GUEST_INPUT,
    SET_NAME_AFTER_LOGIN,
    SET_PIN,
    CONFIRM_PIN
}

@Composable
fun AuthWelcomeScreen(
    isCheckingCredentials: Boolean,
    errorMessage: String?,
    onVerifyLogin: (login: String, pass: String, onSuccess: (username: String) -> Unit) -> Unit,
    onCompleteAuth: (login: String, displayName: String, pin: String, isGuest: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var mode by remember { mutableStateOf(AuthMode.CHOOSE) }
    var isGuestFlow by remember { mutableStateOf(false) }

    var loginInput by remember { mutableStateOf("") }
    var passInput by remember { mutableStateOf("") }
    var passVisible by remember { mutableStateOf(false) }

    var verifiedUsername by remember { mutableStateOf("") }
    var displayNameInput by remember { mutableStateOf("") }

    var pinToSet by remember { mutableStateOf("") }
    var pinToConfirm by remember { mutableStateOf("") }
    var pinMismatchError by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E1B4B),
                        Color(0xFF090D16)
                    )
                )
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Header Logo
            Surface(
                modifier = Modifier
                    .size(72.dp)
                    .shadow(
                        elevation = 12.dp,
                        shape = CircleShape,
                        spotColor = Color(0xFF6366F1).copy(alpha = 0.5f),
                        ambientColor = Color(0xFF6366F1).copy(alpha = 0.3f)
                    ),
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.09f),
                border = BorderStroke(
                    1.5.dp,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.5f), Color.White.copy(alpha = 0.15f))
                    )
                )
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(Color.White.copy(alpha = 0.25f), Color.Transparent),
                                center = Offset(size.width * 0.5f, size.height * 0.35f),
                                radius = size.width * 0.5f
                            )
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = null,
                        tint = Color(0xFFE0E7FF),
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "Расписание 5Б",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFF8FAFC)
            )

            Text(
                text = when (mode) {
                    AuthMode.CHOOSE -> "Выберите вариант входа в систему"
                    AuthMode.LOGIN_INPUT -> "Вход по школьному аккаунту"
                    AuthMode.GUEST_INPUT -> "Вход как гость"
                    AuthMode.SET_NAME_AFTER_LOGIN -> "Настройка профиля"
                    AuthMode.SET_PIN -> "Создание PIN-кода"
                    AuthMode.CONFIRM_PIN -> "Подтверждение PIN-кода"
                },
                fontSize = 13.sp,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Liquid Glass Card Container
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 14.dp,
                        shape = RoundedCornerShape(26.dp),
                        spotColor = Color(0xFF0F172A).copy(alpha = 0.45f),
                        ambientColor = Color(0xFF0F172A).copy(alpha = 0.25f)
                    ),
                shape = RoundedCornerShape(26.dp),
                color = Color.White.copy(alpha = 0.07f),
                border = BorderStroke(
                    1.dp,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0.12f))
                    )
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(Color.White.copy(alpha = 0.08f), Color.Transparent),
                                center = Offset(size.width * 0.5f, 0f),
                                radius = size.width * 0.7f
                            )
                        )
                    }

                    Column(modifier = Modifier.fillMaxWidth()) {
                        when (mode) {
                            AuthMode.CHOOSE -> {
                                // "Войти" and "Войти как гость под именем"
                                LiquidGlassActionButton(
                                    title = "Войти",
                                    subtitle = "Школьный аккаунт с правами публикации ДЗ",
                                    icon = Icons.Default.Lock,
                                    onClick = {
                                        isGuestFlow = false
                                        mode = AuthMode.LOGIN_INPUT
                                    },
                                    testTag = "btn_auth_login"
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                LiquidGlassActionButton(
                                    title = "Войти как гость под именем",
                                    subtitle = "Просмотр расписания и домашних заданий",
                                    icon = Icons.Default.Person,
                                    onClick = {
                                        isGuestFlow = true
                                        mode = AuthMode.GUEST_INPUT
                                    },
                                    testTag = "btn_auth_guest"
                                )
                            }

                            AuthMode.LOGIN_INPUT -> {
                                Text(
                                    text = "Введите данные от аккаунта",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFF1F5F9)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = loginInput,
                                    onValueChange = { loginInput = it },
                                    label = { Text("Логин") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Badge, contentDescription = null, tint = Color(0xFFA5B4FC))
                                    },
                                    singleLine = true,
                                    colors = authTextFieldColors(),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_login_field")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = passInput,
                                    onValueChange = { passInput = it },
                                    label = { Text("Пароль") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Key, contentDescription = null, tint = Color(0xFFA5B4FC))
                                    },
                                    trailingIcon = {
                                        IconButton(onClick = { passVisible = !passVisible }) {
                                            Icon(
                                                imageVector = if (passVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                                contentDescription = null,
                                                tint = Color(0xFF94A3B8)
                                            )
                                        }
                                    },
                                    visualTransformation = if (passVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    singleLine = true,
                                    colors = authTextFieldColors(),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_pass_field")
                                )

                                if (!errorMessage.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Color(0xFFEF4444).copy(alpha = 0.15f),
                                                RoundedCornerShape(10.dp)
                                            )
                                            .padding(10.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.ErrorOutline,
                                            contentDescription = null,
                                            tint = Color(0xFFF87171),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = errorMessage,
                                            fontSize = 12.sp,
                                            color = Color(0xFFFCA5A5),
                                            lineHeight = 16.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(18.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { mode = AuthMode.CHOOSE },
                                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF94A3B8))
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Назад")
                                    }

                                    Button(
                                        onClick = {
                                            onVerifyLogin(loginInput, passInput) { username ->
                                                verifiedUsername = username
                                                mode = AuthMode.SET_NAME_AFTER_LOGIN
                                            }
                                        },
                                        enabled = loginInput.isNotBlank() && passInput.isNotBlank() && !isCheckingCredentials,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF6366F1),
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.testTag("auth_login_submit_btn")
                                    ) {
                                        if (isCheckingCredentials) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp,
                                                color = Color.White
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Проверка...")
                                        } else {
                                            Text("Войти", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            AuthMode.GUEST_INPUT -> {
                                Text(
                                    text = "Как вас зовут?",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFF1F5F9)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = displayNameInput,
                                    onValueChange = { displayNameInput = it },
                                    label = { Text("Ваше имя или никнейм") },
                                    placeholder = { Text("Например: Иван") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFFA5B4FC))
                                    },
                                    singleLine = true,
                                    colors = authTextFieldColors(),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_guest_name_field")
                                )

                                Spacer(modifier = Modifier.height(18.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { mode = AuthMode.CHOOSE },
                                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF94A3B8))
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Назад")
                                    }

                                    Button(
                                        onClick = { mode = AuthMode.SET_PIN },
                                        enabled = displayNameInput.isNotBlank(),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF6366F1),
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.testTag("auth_guest_next_btn")
                                    ) {
                                        Text("Далее", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            AuthMode.SET_NAME_AFTER_LOGIN -> {
                                Text(
                                    text = "Как к вам обращаться?",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFF1F5F9)
                                )
                                Text(
                                    text = "Логин подтверждён: $verifiedUsername",
                                    fontSize = 12.sp,
                                    color = Color(0xFF34D399),
                                    modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                                )

                                OutlinedTextField(
                                    value = displayNameInput,
                                    onValueChange = { displayNameInput = it },
                                    label = { Text("Имя и Фамилия") },
                                    placeholder = { Text("Например: Иван Смирнов") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFFA5B4FC))
                                    },
                                    singleLine = true,
                                    colors = authTextFieldColors(),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(18.dp))

                                Button(
                                    onClick = { mode = AuthMode.SET_PIN },
                                    enabled = displayNameInput.isNotBlank(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF6366F1),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Продолжить", fontWeight = FontWeight.Bold)
                                }
                            }

                            AuthMode.SET_PIN -> {
                                Text(
                                    text = "Какой PIN-код поставить?",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFF1F5F9)
                                )
                                Text(
                                    text = "Придумайте 4 цифры для быстрого входа",
                                    fontSize = 12.sp,
                                    color = Color(0xFF94A3B8),
                                    modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
                                )

                                OutlinedTextField(
                                    value = pinToSet,
                                    onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pinToSet = it },
                                    label = { Text("4-значный PIN-код") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFA5B4FC))
                                    },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true,
                                    colors = authTextFieldColors(),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_pin_set_field")
                                )

                                Spacer(modifier = Modifier.height(18.dp))

                                Button(
                                    onClick = { mode = AuthMode.CONFIRM_PIN },
                                    enabled = pinToSet.length == 4,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF6366F1),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_pin_next_btn")
                                ) {
                                    Text("Далее: Повторить PIN", fontWeight = FontWeight.Bold)
                                }
                            }

                            AuthMode.CONFIRM_PIN -> {
                                Text(
                                    text = "Повторите PIN-код",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFF1F5F9)
                                )
                                Text(
                                    text = "Введите тот же PIN-код ещё раз для проверки",
                                    fontSize = 12.sp,
                                    color = Color(0xFF94A3B8),
                                    modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
                                )

                                OutlinedTextField(
                                    value = pinToConfirm,
                                    onValueChange = {
                                        if (it.length <= 4 && it.all { c -> c.isDigit() }) {
                                            pinToConfirm = it
                                            pinMismatchError = false
                                        }
                                    },
                                    label = { Text("Повторите PIN-код") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFFA5B4FC))
                                    },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true,
                                    colors = authTextFieldColors(),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_pin_confirm_field")
                                )

                                if (pinMismatchError) {
                                    Text(
                                        text = "PIN-коды не совпадают! Попробуйте снова.",
                                        fontSize = 12.sp,
                                        color = Color(0xFFF87171),
                                        modifier = Modifier.padding(top = 6.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(18.dp))

                                Button(
                                    onClick = {
                                        if (pinToConfirm == pinToSet) {
                                            onCompleteAuth(
                                                if (isGuestFlow) "" else verifiedUsername,
                                                displayNameInput.trim(),
                                                pinToSet,
                                                isGuestFlow
                                            )
                                        } else {
                                            pinMismatchError = true
                                        }
                                    },
                                    enabled = pinToConfirm.length == 4,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF10B981),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_pin_finish_btn")
                                ) {
                                    Text("Завершить и войти", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiquidGlassActionButton(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.08f),
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0.12f))
            )
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.White.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(0f, size.height * 0.5f),
                        radius = size.width * 0.6f
                    )
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF6366F1).copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, Color(0xFFA5B4FC).copy(alpha = 0.5f)),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color(0xFFE0E7FF),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF8FAFC)
                    )
                    Text(
                        text = subtitle,
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8),
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun authTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color(0xFFF8FAFC),
    unfocusedTextColor = Color(0xFFF8FAFC),
    focusedBorderColor = Color(0xFF818CF8),
    unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
    focusedLabelColor = Color(0xFFA5B4FC),
    unfocusedLabelColor = Color(0xFF94A3B8),
    cursorColor = Color(0xFF818CF8),
    focusedContainerColor = Color.White.copy(alpha = 0.05f),
    unfocusedContainerColor = Color.White.copy(alpha = 0.03f)
)
