package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.LessonEntity
import com.example.data.model.BellSlot
import com.example.data.model.CurrentStatusInfo
import com.example.data.model.DayOfWeekRussian
import com.example.data.model.DefaultSchedule
import com.example.data.model.SchoolTimeStatus
import com.example.data.model.UpdateCheckResult
import com.example.data.preferences.SchedulePreferences
import com.example.data.repository.AppUpdateRepository
import com.example.data.repository.ScheduleRepository
import com.example.receiver.ScheduleWidgetProvider
import com.example.service.ScheduleNotificationManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

data class ScheduleUiState(
    val isUnlocked: Boolean = false,
    val isWelcomeUnlockAnim: Boolean = false,
    val pinError: Boolean = false,
    val enteredPin: String = "",
    val currentPinCode: String = "2015",
    val isCheckingPinUpdate: Boolean = false,
    val isCheckingUpdateManual: Boolean = false,
    val isUpdateRequired: Boolean = false,
    val currentVersion: String = "2.0.0",
    val remoteVersion: String = "",
    val updateAnnouncement: String? = null,
    val updateUrl: String? = null,
    val isElectionsDialogOpen: Boolean = false,
    val isWelcomeUpdateDialogOpen: Boolean = false,
    val isSupportDialogOpen: Boolean = false,
    val isAiDialogOpen: Boolean = false,
    val isAiLoading: Boolean = false,
    val aiError: String? = null,
    val aiMessages: List<Pair<String, String>> = emptyList(),
    val isGradesDialogOpen: Boolean = false,
    val subjectsGrades: List<com.example.data.model.SubjectGrades> = emptyList(),
    val greetingText: String = "Добрый день, 5Б!",
    val greetingEmoji: String = "☀️",
    val isVotedOrUnlocked: Boolean = false,
    val childVerificationStatus: String = "none",
    val childVerificationSubmitTime: Long = 0L,
    val childStudentFio: String = "",
    val childStudentBirthDate: String = "",
    val isRestricted: Boolean = true,
    val selectedDay: DayOfWeekRussian = DayOfWeekRussian.MONDAY,
    val todayDay: DayOfWeekRussian = DayOfWeekRussian.MONDAY,
    val selectedClassName: String = "5Б",
    val isAutoTracking: Boolean = true,
    val manualActiveLessonIndex: Int = -1,
    val isNotificationsEnabled: Boolean = true,
    val notifyMinutesBefore: Int = 5,
    val currentStatus: CurrentStatusInfo = CurrentStatusInfo(
        status = SchoolTimeStatus.BEFORE_SCHOOL,
        activeLessonNumber = null,
        activeSubject = null,
        activeCabinet = null,
        nextLessonNumber = null,
        nextSubject = null,
        nextCabinet = null,
        secondsRemaining = 0L,
        totalSeconds = 0L,
        progressFraction = 0f,
        formattedRemainingTime = "00:00",
        statusHeadline = "Загрузка...",
        statusSubtext = "",
        lessonsUntilLunch = 4,
        lunchTimeText = "11:05 – 11:25"
    ),
    val editingLesson: LessonEntity? = null,
    val isEditingLessonOpen: Boolean = false,
    val isBellsDialogOpen: Boolean = false,
    val isSettingsDialogOpen: Boolean = false,
    val isChangePinDialogOpen: Boolean = false,
    val isAddLessonDialogOpen: Boolean = false,
    val isUserRegistered: Boolean = false,
    val isGuestUser: Boolean = false,
    val userLogin: String = "",
    val userDisplayName: String = "",
    val userRawHomeworkUrl: String = "",
    val canPublishHomework: Boolean = false,
    val isCheckingAuthCredentials: Boolean = false,
    val authErrorMessage: String? = null,
    val allHomework: List<com.example.data.model.HomeworkItem> = emptyList(),
    val selectedLessonForDetails: LessonEntity? = null,
    val isLessonDetailsOpen: Boolean = false,
    val isPublishHomeworkOpen: Boolean = false,
    val isGitHubInstructionOpen: Boolean = false,
    val isCheckingRawBinding: Boolean = false,
    val isHomeworkPublishSuccessBanner: Boolean = false
)

class ScheduleViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = ScheduleRepository(db.lessonDao())
    private val preferences = SchedulePreferences(application)
    private val notificationManager = ScheduleNotificationManager(application)
    private val updateRepository = AppUpdateRepository()
    private val geminiAiRepository = com.example.data.repository.GeminiAiRepository()
    private val accountsRepository = com.example.data.repository.SchoolAccountsRepository()

    private val _uiState = MutableStateFlow(
        ScheduleUiState(
            currentPinCode = preferences.pinCode,
            isNotificationsEnabled = preferences.isNotificationsEnabled,
            notifyMinutesBefore = preferences.notifyMinutesBefore,
            isAutoTracking = preferences.isAutoTrackActiveLesson,
            selectedClassName = preferences.selectedClassName,
            isVotedOrUnlocked = preferences.isVotedOrUnlocked,
            childVerificationStatus = preferences.childVerificationStatus,
            childVerificationSubmitTime = preferences.childVerificationSubmitTime,
            childStudentFio = preferences.childStudentFio,
            childStudentBirthDate = preferences.childStudentBirthDate,
            isUserRegistered = preferences.isUserRegistered,
            isGuestUser = preferences.isGuestUser,
            userLogin = preferences.userLogin,
            userDisplayName = preferences.userDisplayName,
            userRawHomeworkUrl = preferences.userRawHomeworkUrl,
            canPublishHomework = preferences.canPublishHomework,
            subjectsGrades = preferences.loadSubjectGrades(),
            isRestricted = !preferences.isVotedOrUnlocked && preferences.childVerificationStatus != "approved" &&
                !(preferences.childVerificationStatus == "pending" && (System.currentTimeMillis() - preferences.childVerificationSubmitTime >= 5 * 60 * 1000L))
        )
    )
    val uiState: StateFlow<ScheduleUiState> = _uiState.asStateFlow()

    val allLessons: StateFlow<List<LessonEntity>> = repository.allLessons
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val bellSlots: List<BellSlot> = repository.getBellSlots()

    init {
        viewModelScope.launch {
            repository.ensureDefaultSchedulePopulated()
            initInitialDay()
            startTicker()
            if (preferences.isUserRegistered) {
                refreshAllHomework()
                if (!preferences.isGuestUser) {
                    checkUserRawBinding()
                }
            }
        }
    }

    private fun initInitialDay() {
        val cal = Calendar.getInstance()
        val dayNum = when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            Calendar.SUNDAY -> 7
            else -> 1
        }
        val today = DayOfWeekRussian.fromDayNumber(dayNum)
        _uiState.update { it.copy(selectedDay = today, todayDay = today) }
    }

    // PIN Authentication & Update check
    fun enterPinDigit(digit: Char) {
        if (_uiState.value.enteredPin.length >= 4 || _uiState.value.isCheckingPinUpdate) return
        val newPin = _uiState.value.enteredPin + digit
        _uiState.update { it.copy(enteredPin = newPin, pinError = false) }

        if (newPin.length == 4) {
            checkPinAndUpdates(newPin)
        }
    }

    fun deletePinDigit() {
        if (_uiState.value.enteredPin.isNotEmpty() && !_uiState.value.isCheckingPinUpdate) {
            _uiState.update { it.copy(enteredPin = it.enteredPin.dropLast(1), pinError = false) }
        }
    }

    fun clearPin() {
        if (!_uiState.value.isCheckingPinUpdate) {
            _uiState.update { it.copy(enteredPin = "", pinError = false) }
        }
    }

    fun unlockWithFingerprint() {
        if (_uiState.value.isCheckingPinUpdate || _uiState.value.isWelcomeUnlockAnim) return
        val targetPin = preferences.pinCode
        _uiState.update { it.copy(enteredPin = targetPin, pinError = false) }
        checkPinAndUpdates(targetPin)
    }

    private fun checkPinAndUpdates(pin: String) {
        val targetPin = preferences.pinCode
        if (pin == targetPin) {
            _uiState.update { it.copy(isCheckingPinUpdate = true, isWelcomeUnlockAnim = true, pinError = false) }
            
            viewModelScope.launch {
                delay(700) // Brief smooth "Добро пожаловать" transition
                // Perform online update check
                val result = updateRepository.checkForUpdates()
                
                when (result) {
                    is UpdateCheckResult.UpdateRequired -> {
                        _uiState.update {
                            it.copy(
                                isCheckingPinUpdate = false,
                                isWelcomeUnlockAnim = false,
                                isUnlocked = true,
                                isUpdateRequired = true,
                                remoteVersion = result.remoteVersion,
                                updateAnnouncement = result.announcement,
                                updateUrl = result.updateUrl,
                                enteredPin = ""
                            )
                        }
                    }
                    is UpdateCheckResult.UpToDate, is UpdateCheckResult.NetworkError -> {
                        // If no internet or up-to-date, grant entry and show Elections 2026 dialog on entry
                        _uiState.update {
                            it.copy(
                                isCheckingPinUpdate = false,
                                isWelcomeUnlockAnim = false,
                                isUnlocked = true,
                                isUpdateRequired = false,
                                isElectionsDialogOpen = true,
                                enteredPin = ""
                            )
                        }
                    }
                }
            }
        } else {
            _uiState.update { it.copy(pinError = true, enteredPin = "", isCheckingPinUpdate = false, isWelcomeUnlockAnim = false) }
        }
    }

    fun checkUpdatesFromMandatoryScreen() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCheckingUpdateManual = true) }
            val result = updateRepository.checkForUpdates()
            when (result) {
                is UpdateCheckResult.UpdateRequired -> {
                    _uiState.update {
                        it.copy(
                            isCheckingUpdateManual = false,
                            isUpdateRequired = true,
                            remoteVersion = result.remoteVersion,
                            updateAnnouncement = result.announcement,
                            updateUrl = result.updateUrl
                        )
                    }
                }
                is UpdateCheckResult.UpToDate, is UpdateCheckResult.NetworkError -> {
                    _uiState.update {
                        it.copy(
                            isCheckingUpdateManual = false,
                            isUpdateRequired = false
                        )
                    }
                }
            }
        }
    }

    fun checkUpdatesManual(onResult: (String) -> Unit = {}) {
        viewModelScope.launch {
            _uiState.update { it.copy(isCheckingUpdateManual = true) }
            val result = updateRepository.checkForUpdates()
            _uiState.update { it.copy(isCheckingUpdateManual = false) }
            when (result) {
                is UpdateCheckResult.UpdateRequired -> {
                    _uiState.update {
                        it.copy(
                            isUpdateRequired = true,
                            remoteVersion = result.remoteVersion,
                            updateAnnouncement = result.announcement,
                            updateUrl = result.updateUrl
                        )
                    }
                    onResult("Доступна новая версия v${result.remoteVersion}!")
                }
                is UpdateCheckResult.UpToDate -> {
                    onResult("У вас установлена актуальная версия v${AppUpdateRepository.CURRENT_APP_VERSION}")
                }
                is UpdateCheckResult.NetworkError -> {
                    onResult("Нет соединения с интернетом для проверки обновлений")
                }
            }
        }
    }

    fun dismissElectionsDialog() {
        _uiState.update { it.copy(isElectionsDialogOpen = false) }
    }

    fun openElectionsDialog() {
        _uiState.update { it.copy(isElectionsDialogOpen = true) }
    }

    fun dismissWelcomeUpdateDialog() {
        _uiState.update { it.copy(isWelcomeUpdateDialogOpen = false) }
    }

    fun openWelcomeUpdateDialog() {
        _uiState.update { it.copy(isWelcomeUpdateDialogOpen = true) }
    }

    private fun isDateSeptember3OrLater(): Boolean {
        val cal = Calendar.getInstance()
        val month = cal.get(Calendar.MONTH) // 0-indexed: Calendar.SEPTEMBER is 8
        val day = cal.get(Calendar.DAY_OF_MONTH)
        return (month == Calendar.SEPTEMBER && day >= 3) || month > Calendar.SEPTEMBER
    }

    fun lockApp() {
        _uiState.update { it.copy(isUnlocked = false, enteredPin = "", pinError = false, isCheckingPinUpdate = false) }
    }

    fun updatePinCode(newPin: String) {
        if (newPin.length == 4) {
            preferences.pinCode = newPin
            _uiState.update { it.copy(currentPinCode = newPin, isChangePinDialogOpen = false) }
        }
    }

    // Day navigation
    fun selectDay(day: DayOfWeekRussian) {
        _uiState.update { it.copy(selectedDay = day) }
    }

    fun selectToday() {
        _uiState.update { it.copy(selectedDay = it.todayDay) }
    }

    // Auto-tracking & manual completion
    fun toggleAutoTracking(enabled: Boolean) {
        preferences.isAutoTrackActiveLesson = enabled
        _uiState.update { it.copy(isAutoTracking = enabled) }
    }

    fun advanceManualLesson() {
        val currentIdx = _uiState.value.manualActiveLessonIndex
        val nextIdx = if (currentIdx < 0) {
            val autoNum = _uiState.value.currentStatus.activeLessonNumber ?: 1
            autoNum + 1
        } else {
            currentIdx + 1
        }
        preferences.manualActiveLessonNumber = nextIdx
        _uiState.update { it.copy(manualActiveLessonIndex = nextIdx, isAutoTracking = false) }
    }

    fun resetToAutoTracking() {
        preferences.isAutoTrackActiveLesson = true
        preferences.manualActiveLessonNumber = -1
        _uiState.update { it.copy(isAutoTracking = true, manualActiveLessonIndex = -1) }
    }

    // Notifications
    fun toggleNotifications(enabled: Boolean) {
        preferences.isNotificationsEnabled = enabled
        _uiState.update { it.copy(isNotificationsEnabled = enabled) }
        if (enabled) {
            scheduleDailyNotifications()
        }
    }

    fun sendTestNotification() {
        val status = _uiState.value.currentStatus
        val subject = status.activeSubject ?: status.nextSubject ?: "Математика"
        val cabinet = status.activeCabinet ?: status.nextCabinet ?: "209Г"
        notificationManager.showImmediateTestNotification(subject, cabinet, _uiState.value.notifyMinutesBefore)
    }

    private fun scheduleDailyNotifications() {
        viewModelScope.launch {
            val todayStr = ScheduleRepository.getTodayDateString()
            val lessons = allLessons.value.filter {
                it.dayOfWeek == _uiState.value.todayDay.dayNumber &&
                        (it.overrideDate == null || it.overrideDate == todayStr)
            }
            notificationManager.scheduleAlarmsForToday(lessons, bellSlots, _uiState.value.notifyMinutesBefore)
        }
    }

    // Edit Lesson Dialog
    fun openEditLesson(lesson: LessonEntity) {
        _uiState.update { it.copy(editingLesson = lesson, isEditingLessonOpen = true) }
    }

    fun closeEditLesson() {
        _uiState.update { it.copy(editingLesson = null, isEditingLessonOpen = false) }
    }

    fun saveEditedLesson(
        subject: String,
        cabinet: String,
        teacher: String,
        isOnlyToday: Boolean
    ) {
        val lesson = _uiState.value.editingLesson ?: return
        viewModelScope.launch {
            if (isOnlyToday) {
                val todayStr = ScheduleRepository.getTodayDateString()
                repository.updateLessonForDate(
                    dayOfWeek = lesson.dayOfWeek,
                    lessonNumber = lesson.lessonNumber,
                    dateStr = todayStr,
                    subject = subject,
                    cabinet = cabinet,
                    teacher = teacher
                )
            } else {
                repository.updateLessonPermanent(
                    dayOfWeek = lesson.dayOfWeek,
                    lessonNumber = lesson.lessonNumber,
                    subject = subject,
                    cabinet = cabinet,
                    teacher = teacher,
                    existingId = if (lesson.overrideDate == null) lesson.id else null
                )
            }
            closeEditLesson()
            updateWidget()
        }
    }

    fun deleteLesson(lesson: LessonEntity) {
        viewModelScope.launch {
            repository.deleteLesson(lesson)
            closeEditLesson()
            updateWidget()
        }
    }

    fun addLesson(
        dayOfWeek: Int,
        lessonNumber: Int,
        subject: String,
        cabinet: String,
        teacher: String
    ) {
        viewModelScope.launch {
            repository.updateLessonPermanent(
                dayOfWeek = dayOfWeek,
                lessonNumber = lessonNumber,
                subject = subject,
                cabinet = cabinet,
                teacher = teacher
            )
            _uiState.update { it.copy(isAddLessonDialogOpen = false) }
            updateWidget()
        }
    }

    fun resetScheduleToDefault() {
        viewModelScope.launch {
            repository.resetToDefaultSchedule()
            updateWidget()
        }
    }

    // Dialog toggles
    fun setBellsDialogOpen(open: Boolean) = _uiState.update { it.copy(isBellsDialogOpen = open) }
    fun setSupportDialogOpen(open: Boolean) = _uiState.update { it.copy(isSupportDialogOpen = open) }

    fun confirmAdultVote() {
        preferences.isVotedOrUnlocked = true
        _uiState.update {
            it.copy(
                isVotedOrUnlocked = true,
                isRestricted = false,
                isElectionsDialogOpen = false
            )
        }
    }

    fun submitChildVerification(fio: String, birthDate: String) {
        val now = System.currentTimeMillis()
        preferences.childStudentFio = fio
        preferences.childStudentBirthDate = birthDate
        preferences.childVerificationStatus = "pending"
        preferences.childVerificationSubmitTime = now
        _uiState.update {
            it.copy(
                childStudentFio = fio,
                childStudentBirthDate = birthDate,
                childVerificationStatus = "pending",
                childVerificationSubmitTime = now,
                isRestricted = true
            )
        }
    }

    fun approveChildVerification() {
        preferences.childVerificationStatus = "approved"
        preferences.isVotedOrUnlocked = true
        _uiState.update {
            it.copy(
                childVerificationStatus = "approved",
                isVotedOrUnlocked = true,
                isRestricted = false
            )
        }
    }

    fun setSettingsDialogOpen(open: Boolean) = _uiState.update { it.copy(isSettingsDialogOpen = open) }
    fun setChangePinDialogOpen(open: Boolean) = _uiState.update { it.copy(isChangePinDialogOpen = open) }
    fun setAddLessonDialogOpen(open: Boolean) = _uiState.update { it.copy(isAddLessonDialogOpen = open) }

    // Auth & Registration methods
    fun verifyLogin(login: String, pass: String, onSuccess: (String) -> Unit) {
        _uiState.update { it.copy(isCheckingAuthCredentials = true, authErrorMessage = null) }
        viewModelScope.launch {
            val result = accountsRepository.verifyLogin(login, pass)
            when (result) {
                is com.example.data.model.AccountVerifyResult.Success -> {
                    _uiState.update { it.copy(isCheckingAuthCredentials = false, authErrorMessage = null) }
                    onSuccess(result.account.username)
                }
                is com.example.data.model.AccountVerifyResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isCheckingAuthCredentials = false,
                            authErrorMessage = result.message
                        )
                    }
                }
            }
        }
    }

    fun completeRegistration(login: String, displayName: String, pin: String, isGuest: Boolean) {
        preferences.isUserRegistered = true
        preferences.isGuestUser = isGuest
        preferences.userLogin = login
        preferences.userDisplayName = displayName
        preferences.pinCode = pin

        _uiState.update {
            it.copy(
                isUserRegistered = true,
                isGuestUser = isGuest,
                userLogin = login,
                userDisplayName = displayName,
                currentPinCode = pin,
                isUnlocked = true,
                authErrorMessage = null
            )
        }

        viewModelScope.launch {
            if (!isGuest) {
                checkUserRawBinding()
            }
            refreshAllHomework()
        }
    }

    fun checkUserRawBinding() {
        val login = _uiState.value.userLogin
        if (login.isBlank()) return
        _uiState.update { it.copy(isCheckingRawBinding = true) }
        viewModelScope.launch {
            val rawUrl = accountsRepository.checkUserRawUrl(login)
            if (!rawUrl.isNullOrBlank()) {
                preferences.userRawHomeworkUrl = rawUrl
                preferences.canPublishHomework = true
                _uiState.update {
                    it.copy(
                        userRawHomeworkUrl = rawUrl,
                        canPublishHomework = true,
                        isCheckingRawBinding = false
                    )
                }
            } else {
                preferences.canPublishHomework = false
                _uiState.update {
                    it.copy(
                        canPublishHomework = false,
                        isCheckingRawBinding = false
                    )
                }
            }
        }
    }

    fun refreshAllHomework() {
        viewModelScope.launch {
            val accounts = accountsRepository.fetchAccounts()
            val myLogin = _uiState.value.userLogin
            if (myLogin.isNotBlank()) {
                val myAcc = accounts.firstOrNull { it.username.equals(myLogin, ignoreCase = true) }
                if (myAcc?.rawUrl != null && myAcc.rawUrl.isNotBlank()) {
                    preferences.userRawHomeworkUrl = myAcc.rawUrl
                    preferences.canPublishHomework = true
                    _uiState.update { it.copy(userRawHomeworkUrl = myAcc.rawUrl, canPublishHomework = true) }
                }
            }
            val hwList = accountsRepository.fetchAllHomework(accounts)
            if (hwList.isNotEmpty()) {
                _uiState.update { it.copy(allHomework = hwList) }
            }
        }
    }

    fun publishHomework(item: com.example.data.model.HomeworkItem) {
        val currentList = _uiState.value.allHomework.toMutableList()
        currentList.removeAll { it.subjectRu.equals(item.subjectRu, ignoreCase = true) && it.date == item.date }
        currentList.add(0, item)
        _uiState.update {
            it.copy(
                allHomework = currentList,
                isPublishHomeworkOpen = false,
                isLessonDetailsOpen = false,
                isHomeworkPublishSuccessBanner = true
            )
        }
    }

    fun openLessonDetails(lesson: LessonEntity) {
        _uiState.update { it.copy(selectedLessonForDetails = lesson, isLessonDetailsOpen = true) }
    }

    fun closeLessonDetails() {
        _uiState.update { it.copy(isLessonDetailsOpen = false, selectedLessonForDetails = null) }
    }

    fun openPublishHomework() {
        if (!_uiState.value.canPublishHomework) {
            _uiState.update { it.copy(isGitHubInstructionOpen = true) }
        } else {
            _uiState.update { it.copy(isPublishHomeworkOpen = true) }
        }
    }

    fun closePublishHomework() {
        _uiState.update { it.copy(isPublishHomeworkOpen = false) }
    }

    fun openGitHubInstruction() {
        _uiState.update { it.copy(isGitHubInstructionOpen = true) }
    }

    fun closeGitHubInstruction() {
        _uiState.update { it.copy(isGitHubInstructionOpen = false) }
    }

    fun dismissHomeworkSuccessBanner() {
        _uiState.update { it.copy(isHomeworkPublishSuccessBanner = false) }
    }

    // AI Tutor methods
    fun openAiDialog() = _uiState.update { it.copy(isAiDialogOpen = true) }
    fun dismissAiDialog() = _uiState.update { it.copy(isAiDialogOpen = false) }

    fun sendAiMessage(message: String) {
        val trimmed = message.trim()
        if (trimmed.isBlank()) return

        val currentMessages = _uiState.value.aiMessages.toMutableList()
        currentMessages.add("user" to trimmed)

        _uiState.update {
            it.copy(
                aiMessages = currentMessages,
                isAiLoading = true,
                aiError = null
            )
        }

        viewModelScope.launch {
            val historyForApi = currentMessages.dropLast(1)
            val result = geminiAiRepository.generateExplanation(historyForApi, trimmed)
            result.onSuccess { responseText ->
                val updated = _uiState.value.aiMessages.toMutableList()
                updated.add("model" to responseText)
                _uiState.update {
                    it.copy(
                        aiMessages = updated,
                        isAiLoading = false,
                        aiError = null
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isAiLoading = false,
                        aiError = error.message ?: "Включите VPN для старта общения с нейросетью или проверьте подключение к интернету."
                    )
                }
            }
        }
    }

    fun retryLastAiMessage() {
        val lastUserMsg = _uiState.value.aiMessages.lastOrNull { it.first == "user" }?.second
        if (lastUserMsg != null) {
            _uiState.update {
                it.copy(
                    isAiLoading = true,
                    aiError = null
                )
            }
            viewModelScope.launch {
                val history = _uiState.value.aiMessages.filterNot { it.first == "user" && it.second == lastUserMsg }
                val result = geminiAiRepository.generateExplanation(history, lastUserMsg)
                result.onSuccess { responseText ->
                    val updated = _uiState.value.aiMessages.toMutableList()
                    updated.add("model" to responseText)
                    _uiState.update {
                        it.copy(
                            aiMessages = updated,
                            isAiLoading = false,
                            aiError = null
                        )
                    }
                }.onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isAiLoading = false,
                            aiError = error.message ?: "Включите VPN для старта общения с нейросетью или проверьте подключение к интернету."
                        )
                    }
                }
            }
        }
    }

    fun clearAiChat() {
        _uiState.update { it.copy(aiMessages = emptyList(), aiError = null, isAiLoading = false) }
    }

    // Grades and Points methods
    fun openGradesDialog() {
        val grades = preferences.loadSubjectGrades()
        _uiState.update { it.copy(isGradesDialogOpen = true, subjectsGrades = grades) }
    }

    fun dismissGradesDialog() = _uiState.update { it.copy(isGradesDialogOpen = false) }

    fun addGrade(subjectName: String, grade: Int) {
        val current = preferences.loadSubjectGrades().toMutableList()
        val index = current.indexOfFirst { it.subjectName.equals(subjectName, ignoreCase = true) }
        if (index >= 0) {
            val subj = current[index]
            val newGrades = subj.grades + grade
            current[index] = subj.copy(grades = newGrades)
        } else {
            current.add(com.example.data.model.SubjectGrades(subjectName, listOf(grade)))
        }
        preferences.saveSubjectGrades(current)
        _uiState.update { it.copy(subjectsGrades = current) }
    }

    fun removeGrade(subjectName: String, gradeIndex: Int) {
        val current = preferences.loadSubjectGrades().toMutableList()
        val index = current.indexOfFirst { it.subjectName.equals(subjectName, ignoreCase = true) }
        if (index >= 0) {
            val subj = current[index]
            if (gradeIndex in subj.grades.indices) {
                val newGrades = subj.grades.toMutableList().also { it.removeAt(gradeIndex) }
                current[index] = subj.copy(grades = newGrades)
                preferences.saveSubjectGrades(current)
                _uiState.update { it.copy(subjectsGrades = current) }
            }
        }
    }

    fun resetGradesToDefault() {
        val initial = com.example.data.model.DefaultSubjects.createInitialSubjects()
        preferences.saveSubjectGrades(initial)
        _uiState.update { it.copy(subjectsGrades = initial) }
    }

    private fun updateWidget() {
        ScheduleWidgetProvider.updateAllWidgets(getApplication())
    }

    // 1-second background ticker
    private fun startTicker() {
        viewModelScope.launch {
            while (isActive) {
                checkChildVerificationTimer()
                calculateCurrentStatus()
                delay(1000L)
            }
        }
    }

    private fun checkChildVerificationTimer() {
        if (preferences.childVerificationStatus == "pending") {
            val elapsed = System.currentTimeMillis() - preferences.childVerificationSubmitTime
            if (elapsed >= 5 * 60 * 1000L) {
                preferences.childVerificationStatus = "approved"
                preferences.isVotedOrUnlocked = true
                _uiState.update {
                    it.copy(
                        childVerificationStatus = "approved",
                        isVotedOrUnlocked = true,
                        isRestricted = false
                    )
                }
            }
        }
    }

    private fun calculateCurrentStatus() {
        val calendar = Calendar.getInstance()
        val currentDayNum = when (calendar.get(Calendar.DAY_OF_WEEK)) {
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            Calendar.SUNDAY -> 7
            else -> 1
        }
        val currentDay = DayOfWeekRussian.fromDayNumber(currentDayNum)

        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val second = calendar.get(Calendar.SECOND)
        val currentSecondsOfDay = hour * 3600 + minute * 60 + second

        val todayDateStr = ScheduleRepository.getTodayDateString()
        val currentDayLessons = allLessons.value
            .filter { it.dayOfWeek == currentDayNum && (it.overrideDate == null || it.overrideDate == todayDateStr) }
            .sortedBy { it.lessonNumber }

        val bells = bellSlots
        val firstBell = bells.firstOrNull() ?: return
        val lastBell = bells.lastOrNull() ?: return
        val schoolStartSec = firstBell.startHour * 3600 + firstBell.startMinute * 60
        val schoolEndSec = lastBell.endHour * 3600 + lastBell.endMinute * 60

        // Lunch definition (after lesson 4, from 11:05 to 11:25)
        val lunchBell = bells.firstOrNull { it.isLunchAfter } ?: bells.getOrNull(3)
        val lunchStartSec = if (lunchBell != null) lunchBell.endHour * 3600 + lunchBell.endMinute * 60 else (11 * 3600 + 5 * 60)
        val lunchEndSec = lunchStartSec + (lunchBell?.breakAfterMinutes ?: 20) * 60

        var status = SchoolTimeStatus.BEFORE_SCHOOL
        var activeLessonNum: Int? = null
        var activeSubj: String? = null
        var activeCab: String? = null
        var nextLessonNum: Int? = null
        var nextSubj: String? = null
        var nextCab: String? = null
        var secondsRemaining = 0L
        var totalSeconds = 1L
        var headline = ""
        var subtext = ""
        var lessonsUntilLunch = 0

        if (currentDayNum !in 1..5) {
            status = SchoolTimeStatus.WEEKEND
            headline = "Выходной день"
            subtext = "Уроков сегодня нет. Отдыхайте!"
            val mondayLesson1 = allLessons.value.firstOrNull { it.dayOfWeek == 1 && it.lessonNumber == 1 }
            nextLessonNum = 1
            nextSubj = mondayLesson1?.subject ?: "Разговор о важном"
            nextCab = mondayLesson1?.cabinet ?: "309А"
        } else if (currentSecondsOfDay < schoolStartSec) {
            status = SchoolTimeStatus.BEFORE_SCHOOL
            secondsRemaining = (schoolStartSec - currentSecondsOfDay).toLong()
            totalSeconds = 3600L
            val l1 = currentDayLessons.firstOrNull { it.lessonNumber == 1 }
            activeLessonNum = null
            nextLessonNum = 1
            nextSubj = l1?.subject ?: "1-й урок"
            nextCab = l1?.cabinet ?: ""
            headline = "До начала уроков"
            subtext = "Следующий: 1-й урок — ${l1?.subject ?: "Урок"} (Каб. ${l1?.cabinet ?: "—"})"
            lessonsUntilLunch = 4
        } else if (currentSecondsOfDay >= schoolEndSec) {
            status = SchoolTimeStatus.AFTER_SCHOOL
            headline = "Уроки на сегодня окончены"
            subtext = "Все занятия прошли. До завтра!"
            lessonsUntilLunch = 0
        } else {
            // Inside school day hours
            for (i in bells.indices) {
                val bell = bells[i]
                val lStart = bell.startHour * 3600 + bell.startMinute * 60
                val lEnd = bell.endHour * 3600 + bell.endMinute * 60
                val breakEnd = lEnd + bell.breakAfterMinutes * 60

                val curLesson = currentDayLessons.firstOrNull { it.lessonNumber == bell.lessonNumber }
                val nextLesson = currentDayLessons.firstOrNull { it.lessonNumber == bell.lessonNumber + 1 }

                // Check inside lesson
                if (currentSecondsOfDay in lStart until lEnd) {
                    status = SchoolTimeStatus.IN_LESSON
                    activeLessonNum = bell.lessonNumber
                    activeSubj = curLesson?.subject ?: "Урок ${bell.lessonNumber}"
                    activeCab = curLesson?.cabinet ?: "—"
                    nextLessonNum = if (nextLesson != null) bell.lessonNumber + 1 else null
                    nextSubj = nextLesson?.subject
                    nextCab = nextLesson?.cabinet
                    secondsRemaining = (lEnd - currentSecondsOfDay).toLong()
                    totalSeconds = (bell.durationMinutes * 60).toLong()
                    headline = "${bell.lessonNumber}-й урок: ${curLesson?.subject ?: "Урок"}"
                    subtext = "Кабинет: ${curLesson?.cabinet ?: "—"} (${bell.timeRangeFormatted})"
                    lessonsUntilLunch = maxOf(0, 4 - bell.lessonNumber)
                    break
                }

                // Check inside break
                if (currentSecondsOfDay in lEnd until breakEnd) {
                    val isLunch = bell.isLunchAfter || (bell.lessonNumber == 4)
                    status = if (isLunch) SchoolTimeStatus.IN_LUNCH_BREAK else SchoolTimeStatus.IN_BREAK
                    activeLessonNum = null
                    nextLessonNum = bell.lessonNumber + 1
                    nextSubj = nextLesson?.subject ?: "Следующий урок"
                    nextCab = nextLesson?.cabinet ?: "—"
                    secondsRemaining = (breakEnd - currentSecondsOfDay).toLong()
                    totalSeconds = (bell.breakAfterMinutes * 60).toLong()

                    if (isLunch) {
                        headline = "Обед и питание (20 мин)"
                        subtext = "Перемена с питанием до 11:25. Следующий: ${nextLesson?.subject ?: "Урок 5"}"
                        lessonsUntilLunch = 0
                    } else {
                        headline = "Перемена (${bell.breakAfterMinutes} мин)"
                        subtext = "Идите в каб. ${nextLesson?.cabinet ?: "—"} на ${nextLesson?.subject ?: "следующий урок"}"
                        lessonsUntilLunch = maxOf(0, 4 - bell.lessonNumber)
                    }
                    break
                }
            }
        }

        val progress = if (totalSeconds > 0) {
            1f - (secondsRemaining.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)
        } else 0f

        val mins = secondsRemaining / 60
        val secs = secondsRemaining % 60
        val formattedTimer = String.format("%02d:%02d", mins, secs)

        val updatedStatus = CurrentStatusInfo(
            status = status,
            activeLessonNumber = activeLessonNum,
            activeSubject = activeSubj,
            activeCabinet = activeCab,
            nextLessonNumber = nextLessonNum,
            nextSubject = nextSubj,
            nextCabinet = nextCab,
            secondsRemaining = secondsRemaining,
            totalSeconds = totalSeconds,
            progressFraction = progress,
            formattedRemainingTime = formattedTimer,
            statusHeadline = headline,
            statusSubtext = subtext,
            lessonsUntilLunch = lessonsUntilLunch,
            lunchTimeText = "11:05 – 11:25 (после 4-го урока)"
        )

        val (greeting, emoji) = when (hour) {
            in 5..11 -> "Доброе утро, 5Б!" to "☀️"
            in 12..17 -> "Добрый день, 5Б!" to "🌤️"
            in 18..22 -> "Добрый вечер, 5Б!" to "🌆"
            else -> "Доброй ночи, 5Б!" to "🌙"
        }

        _uiState.update {
            it.copy(
                todayDay = currentDay,
                currentStatus = updatedStatus,
                greetingText = greeting,
                greetingEmoji = emoji
            )
        }
    }
}
