package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GradesSummary
import com.example.data.model.SubjectGrades

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun GradesDialog(
    isOpen: Boolean,
    subjects: List<SubjectGrades>,
    onAddGrade: (String, Int) -> Unit,
    onRemoveGrade: (String, Int) -> Unit,
    onResetToDefault: () -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var subjectToDeleteGradeFrom by remember { mutableStateOf<Pair<String, Int>?>(null) }

    val allGrades = subjects.flatMap { it.grades }
    val totalCount = allGrades.size
    val totalPoints = allGrades.sum()
    val overallAverage = if (totalCount > 0) allGrades.average() else 0.0

    val summary = remember(subjects) {
        GradesSummary(
            subjects = subjects,
            overallAverage = overallAverage,
            totalPoints = totalPoints,
            totalCount = totalCount,
            countFives = allGrades.count { it == 5 },
            countFours = allGrades.count { it == 4 },
            countThrees = allGrades.count { it == 3 },
            countTwos = allGrades.count { it == 2 }
        )
    }

    ModalBottomSheet(
        onDismissRequest = { onDismiss() },
        sheetState = sheetState,
        containerColor = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.15f),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.BarChart,
                                contentDescription = null,
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Дневник и баллы 5Б",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "Ставь оценки сам и копи баллы успеваемости",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                Row {
                    IconButton(
                        onClick = onResetToDefault,
                        modifier = Modifier.testTag("grades_reset_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Сброс",
                            tint = Color(0xFF64748B)
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("grades_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Закрыть",
                            tint = Color(0xFF64748B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Score Banner (Overall GPA + Points)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF047857), Color(0xFF065F46), Color(0xFF1E293B))
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = summary.rankTitle,
                                    color = Color(0xFFFDE68A),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Всего баллов успеваемости: $totalPoints",
                                    color = Color(0xFFE2E8F0),
                                    fontSize = 13.sp
                                )
                            }

                            // Circular GPA badge
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .border(2.dp, Color(0xFF34D399), CircleShape)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = if (totalCount > 0) String.format("%.2f", overallAverage) else "0.0",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "средний",
                                        fontSize = 8.sp,
                                        color = Color(0xFFCBD5E1)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Stats count row: 5s, 4s, 3s, 2s
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            GradeStatPill(label = "«5»", count = summary.countFives, color = Color(0xFF10B981), modifier = Modifier.weight(1f))
                            GradeStatPill(label = "«4»", count = summary.countFours, color = Color(0xFF3B82F6), modifier = Modifier.weight(1f))
                            GradeStatPill(label = "«3»", count = summary.countThrees, color = Color(0xFFF59E0B), modifier = Modifier.weight(1f))
                            GradeStatPill(label = "«2»", count = summary.countTwos, color = Color(0xFFEF4444), modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Предметы и оценки (нажмите на оценку для удаления):",
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = Color(0xFF475569)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Subjects list
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(subjects) { subject ->
                    SubjectCardItem(
                        subject = subject,
                        onAddGrade = { grade -> onAddGrade(subject.subjectName, grade) },
                        onGradeClick = { index -> subjectToDeleteGradeFrom = subject.subjectName to index }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // Confirmation dialog for deleting a single grade
    if (subjectToDeleteGradeFrom != null) {
        val (subjName, gradeIdx) = subjectToDeleteGradeFrom!!
        AlertDialog(
            onDismissRequest = { subjectToDeleteGradeFrom = null },
            title = { Text("Удалить оценку?") },
            text = { Text("Удалить выбранную оценку по предмету «$subjName»?") },
            confirmButton = {
                Button(
                    onClick = {
                        onRemoveGrade(subjName, gradeIdx)
                        subjectToDeleteGradeFrom = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { subjectToDeleteGradeFrom = null }) {
                    Text("Отмена")
                }
            }
        )
    }
}

@Composable
fun GradeStatPill(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color.White.copy(alpha = 0.15f),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(vertical = 4.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontWeight = FontWeight.Bold, color = color, fontSize = 12.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = count.toString(), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubjectCardItem(
    subject: SubjectGrades,
    onAddGrade: (Int) -> Unit,
    onGradeClick: (Int) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("subject_card_${subject.subjectName.hashCode()}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = subject.subjectName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFF1E293B)
                )

                // Average badge
                val avg = subject.average
                val (avgColor, avgBg) = when {
                    subject.grades.isEmpty() -> Color(0xFF94A3B8) to Color(0xFFF1F5F9)
                    avg >= 4.5 -> Color(0xFF059669) to Color(0xFFD1FAE5)
                    avg >= 3.5 -> Color(0xFF2563EB) to Color(0xFFDBEAFE)
                    avg >= 2.5 -> Color(0xFFD97706) to Color(0xFFFEF3C7)
                    else -> Color(0xFFDC2626) to Color(0xFFFEE2E2)
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = avgBg
                ) {
                    Text(
                        text = if (subject.grades.isNotEmpty()) String.format("%.2f", avg) else "—",
                        color = avgColor,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Grades list
            if (subject.grades.isEmpty()) {
                Text(
                    text = "Оценок пока нет",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            } else {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    subject.grades.forEachIndexed { index, mark ->
                        val (markColor, markBg) = when (mark) {
                            5 -> Color(0xFF047857) to Color(0xFFD1FAE5)
                            4 -> Color(0xFF1D4ED8) to Color(0xFFDBEAFE)
                            3 -> Color(0xFFB45309) to Color(0xFFFEF3C7)
                            else -> Color(0xFFB91C1C) to Color(0xFFFEE2E2)
                        }

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(markBg)
                                .clickable { onGradeClick(index) }
                        ) {
                            Text(
                                text = mark.toString(),
                                fontWeight = FontWeight.Bold,
                                color = markColor,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick add mark buttons: [+5], [+4], [+3], [+2]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Поставить:",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(4.dp))
                AddMarkButton(mark = 5, color = Color(0xFF059669), onClick = { onAddGrade(5) })
                AddMarkButton(mark = 4, color = Color(0xFF2563EB), onClick = { onAddGrade(4) })
                AddMarkButton(mark = 3, color = Color(0xFFD97706), onClick = { onAddGrade(3) })
                AddMarkButton(mark = 2, color = Color(0xFFDC2626), onClick = { onAddGrade(2) })
            }
        }
    }
}

@Composable
fun AddMarkButton(
    mark: Int,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.12f),
        modifier = Modifier
            .clickable { onClick() }
            .testTag("add_mark_${mark}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = "$mark",
                fontWeight = FontWeight.Bold,
                color = color,
                fontSize = 12.sp
            )
        }
    }
}
