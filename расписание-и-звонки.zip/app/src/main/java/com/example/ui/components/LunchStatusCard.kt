package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dining
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurrentStatusInfo
import com.example.data.model.SchoolTimeStatus
import com.example.ui.theme.GeoBorder
import com.example.ui.theme.GeoOnPrimaryContainer
import com.example.ui.theme.GeoOnSecondaryContainer
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoSecondaryContainer
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoTextPrimary
import com.example.ui.theme.GeoTextSecondary

@Composable
fun LunchStatusCard(
    statusInfo: CurrentStatusInfo,
    modifier: Modifier = Modifier
) {
    val isLunchNow = statusInfo.status == SchoolTimeStatus.IN_LUNCH_BREAK

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Card 1: Until Lunch (White geometric card)
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = GeoSurface),
            border = BorderStroke(1.dp, GeoBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Dining,
                        contentDescription = "Обед",
                        tint = GeoPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "ДО ОБЕДА",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        color = GeoTextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val lunchHeadline = when {
                    isLunchNow -> "СЕЙЧАС ОБЕД"
                    statusInfo.lessonsUntilLunch == 1 -> "1 урок"
                    statusInfo.lessonsUntilLunch in 2..4 -> "${statusInfo.lessonsUntilLunch} урока"
                    statusInfo.lessonsUntilLunch > 4 -> "${statusInfo.lessonsUntilLunch} уроков"
                    statusInfo.status == SchoolTimeStatus.AFTER_SCHOOL -> "Завершен"
                    statusInfo.status == SchoolTimeStatus.WEEKEND -> "В 11:05"
                    else -> "Прошел"
                }

                Text(
                    text = lunchHeadline,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = GeoTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = if (isLunchNow) "До 11:25 (20 мин)" else "Обед в 11:05 • 20 мин",
                    fontSize = 11.sp,
                    color = GeoTextSecondary
                )
            }
        }

        // Card 2: Next Subject (Soft Purple geometric card)
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = GeoSecondaryContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Следующий",
                        tint = GeoOnSecondaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "ДАЛЕЕ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        color = GeoOnSecondaryContainer.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val nextName = statusInfo.nextSubject ?: if (statusInfo.status == SchoolTimeStatus.AFTER_SCHOOL) "Конец уроков" else "Нет уроков"

                Text(
                    text = nextName,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = GeoOnSecondaryContainer,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                val nextSubtext = if (statusInfo.nextCabinet != null) {
                    "Кабинет ${statusInfo.nextCabinet}"
                } else if (statusInfo.status == SchoolTimeStatus.AFTER_SCHOOL) {
                    "До завтра"
                } else {
                    "По расписанию"
                }

                Text(
                    text = nextSubtext,
                    fontSize = 11.sp,
                    color = GeoOnSecondaryContainer.copy(alpha = 0.85f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
