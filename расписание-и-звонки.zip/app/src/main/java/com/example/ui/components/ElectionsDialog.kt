package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoBorder
import com.example.ui.theme.GeoBorderLight
import com.example.ui.theme.GeoOnPrimary
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryContainer
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceVariant
import com.example.ui.theme.GeoTextPrimary
import com.example.ui.theme.GeoTextSecondary
import kotlinx.coroutines.delay

@Composable
fun ElectionsDialog(
    onDismiss: () -> Unit,
    onVoteConfirmed: () -> Unit = {},
    onOpenSupport: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var secondsLeft by remember { mutableIntStateOf(3) }
    var showAgeCheckDialog by remember { mutableStateOf(false) }
    var showUnderAgeInfoDialog by remember { mutableStateOf(false) }

    // 3-second timer before enabling close
    LaunchedEffect(Unit) {
        while (secondsLeft > 0) {
            delay(1000)
            secondsLeft -= 1
        }
    }

    Dialog(
        onDismissRequest = {
            if (secondsLeft == 0) {
                onDismiss()
            }
        },
        properties = DialogProperties(
            dismissOnBackPress = secondsLeft == 0,
            dismissOnClickOutside = secondsLeft == 0,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.94f)
                .testTag("elections_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = GeoSurface,
            border = BorderStroke(1.5.dp, Color(0xFF265EA7)),
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Badge
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFF1E40AF)
                ) {
                    Text(
                        text = "ВЫБОРЫ ДЕПУТАТОВ",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "ГОСУДАРСТВЕННОЙ ДУМЫ",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF1E3A8A),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Date blocks matching 18 19 20 сентября
                ElectionsDateCard()

                Spacer(modifier = Modifier.height(12.dp))

                // Slogan
                Text(
                    text = "ТВОЙ ГОЛОС — СИЛА РОССИИ!",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFDC2626),
                    textAlign = TextAlign.Center,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = GeoBorderLight)
                Spacer(modifier = Modifier.height(12.dp))

                // Political Parties Section
                Text(
                    text = "Участвующие парламентские партии:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = GeoTextPrimary,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PartyInfoRow(
                        name = "Единая Россия",
                        description = "Партия большинства, поддержка государственных программ и проектов развития",
                        badgeColor = Color(0xFF0284C7),
                        accent = "Голосуйте за стабильность и развитие"
                    )
                    PartyInfoRow(
                        name = "КПРФ",
                        description = "Коммунистическая партия Российской Федерации",
                        badgeColor = Color(0xFFDC2626)
                    )
                    PartyInfoRow(
                        name = "ЛДПР",
                        description = "Либерально-демократическая партия России",
                        badgeColor = Color(0xFF2563EB)
                    )
                    PartyInfoRow(
                        name = "Справедливая Россия — За правду",
                        description = "Социалистическая политическая партия",
                        badgeColor = Color(0xFFD97706)
                    )
                    PartyInfoRow(
                        name = "Новые люди",
                        description = "Политическая партия развития предпринимательства и технологий",
                        badgeColor = Color(0xFF0D9488)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Civic Education Card for 5B students
                CivicEducationCard()

                Spacer(modifier = Modifier.height(18.dp))

                // Vote / Action Button
                Button(
                    onClick = { showAgeCheckDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("vote_action_btn"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF))
                ) {
                    Icon(
                        imageVector = Icons.Default.HowToVote,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Проголосовать (ДЭГ / Госуслуги)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Close Button with 3s Timer
                OutlinedButton(
                    onClick = onDismiss,
                    enabled = secondsLeft == 0,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("close_elections_btn"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, if (secondsLeft == 0) GeoBorder else GeoBorderLight)
                ) {
                    if (secondsLeft > 0) {
                        Text(
                            text = "Закрыть можно через $secondsLeft сек...",
                            fontSize = 13.sp,
                            color = GeoTextSecondary
                        )
                    } else {
                        Text(
                            text = "Закрыть",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = GeoTextPrimary
                        )
                    }
                }
            }
        }
    }

    // 18+ Age Check Dialog
    if (showAgeCheckDialog) {
        AlertDialog(
            onDismissRequest = { showAgeCheckDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = Color(0xFF1E40AF),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Подтверждение возраста",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "Вам уже исполнилось 18 лет?\n\nВ соответствии с законодательством РФ право голосовать имеют совершеннолетние граждане (с 18 лет).",
                    fontSize = 14.sp,
                    color = GeoTextSecondary,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAgeCheckDialog = false
                        onVoteConfirmed()
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://vybory.gov.ru/"))
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://gosuslugi.ru/"))
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF))
                ) {
                    Text("Да, мне есть 18 лет")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showAgeCheckDialog = false
                        showUnderAgeInfoDialog = true
                    }
                ) {
                    Text("Мне меньше 18 лет")
                }
            }
        )
    }

    // Under-18 informational dialog
    if (showUnderAgeInfoDialog) {
        AlertDialog(
            onDismissRequest = { showUnderAgeInfoDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = GeoPrimary,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Информация для учащихся",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Text(
                    text = "Ученикам 5Б класса пока не исполнилось 18 лет, поэтому участие в голосовании недоступно.\n\nЧтобы разблокировать функции расписания уроков, звонков и настроек, перейдите в Поддержку и отправьте анкету учащегося («Я ребёнок»). Проверка займет 5 минут.",
                    fontSize = 13.sp,
                    color = GeoTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnderAgeInfoDialog = false
                        onDismiss()
                        onOpenSupport()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                ) {
                    Text("Написать в поддержку")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showUnderAgeInfoDialog = false }
                ) {
                    Text("Позже")
                }
            }
        )
    }
}

@Composable
fun ElectionsDateCard(
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "2026",
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFDC2626)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 18
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White,
                    border = BorderStroke(1.5.dp, Color(0xFF1E3A8A)),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "18",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF1E3A8A)
                        )
                    }
                }

                // 19
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1E3A8A),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "19",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }

                // 20
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFDC2626),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "20",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "СЕНТЯБРЯ",
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFDC2626),
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
private fun PartyInfoRow(
    name: String,
    description: String,
    badgeColor: Color,
    accent: String? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = GeoSurfaceVariant),
        border = BorderStroke(1.dp, GeoBorderLight)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = badgeColor,
                    modifier = Modifier.size(10.dp)
                ) {}

                Text(
                    text = name,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = GeoTextPrimary
                )
            }

            Text(
                text = description,
                fontSize = 11.sp,
                color = GeoTextSecondary,
                lineHeight = 14.sp,
                modifier = Modifier.padding(start = 18.dp, top = 2.dp)
            )

            if (accent != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFEFF6FF),
                    modifier = Modifier.padding(start = 18.dp, top = 4.dp)
                ) {
                    Text(
                        text = "★ $accent",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E40AF),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CivicEducationCard(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
        border = BorderStroke(1.dp, Color(0xFFBFDBFE))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "🏛️", fontSize = 18.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Как устроен парламент (Гид для 5Б)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF1E3A8A)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "• В Государственной Думе 450 депутатов, которые избираются гражданами на 5 лет.\n" +
                        "• Депутаты создают и утверждают законы, в том числе о школах, питании и безопасности.\n" +
                        "• В 5Б классе тоже есть самоуправление: староста класса и совет класса помогают организовывать дежурство и мероприятия!\n" +
                        "• Гражданское право: голосовать на выборах граждане могут с 18 лет.",
                fontSize = 12.sp,
                color = Color(0xFF1E293B),
                lineHeight = 17.sp
            )
        }
    }
}
