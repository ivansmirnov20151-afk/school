package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.LessonEntity
import com.example.data.model.BellSlot
import com.example.data.model.HomeworkItem
import com.example.data.model.SubjectHelper
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GitHubInstructionDialog(
    username: String,
    isCheckingRaw: Boolean,
    onCheckRawClick: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .shadow(16.dp, RoundedCornerShape(26.dp))
                .clip(RoundedCornerShape(26.dp)),
            color = Color(0xFF0F172A),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
                    .verticalScroll(scrollState)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF6366F1).copy(alpha = 0.25f),
                        border = BorderStroke(1.dp, Color(0xFFA5B4FC).copy(alpha = 0.4f)),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = Color(0xFFE0E7FF),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Подключение публикации ДЗ",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF8FAFC)
                        )
                        Text(
                            text = "Инструкция для аккаунта $username",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                InstructionStepItem(
                    stepNumber = "1",
                    title = "Репозиторий и файл на GitHub",
                    text = "Создайте публичный репозиторий (например, school-homework) и создайте в нём файл (например, homework.txt)."
                )

                InstructionStepItem(
                    stepNumber = "2",
                    title = "Ссылка Raw",
                    text = "Откройте созданный файл в GitHub, нажмите кнопку «Raw» и скопируйте ссылку из адресной строки браузера (она начинается с https://raw.githubusercontent.com/...)."
                )

                InstructionStepItem(
                    stepNumber = "3",
                    title = "Отправьте заявку в класс",
                    text = "Отправьте в ваш класс или администратору сообщение с вашим логином и ссылкой на raw. Администратор добавит строку «raw: [ваша ссылка]» под вашим логином в базу данных."
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Copy Application Text button
                val applicationText = "Заявка на добавление raw для публикации ДЗ:\nЛогин: $username\nСсылка raw: [вставьте вашу ссылку здесь]"
                OutlinedButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Заявка на raw", applicationText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Шаблон заявки скопирован!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFF818CF8).copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFFA5B4FC), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Скопировать текст заявки", color = Color(0xFFE0E7FF), fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Закрыть", color = Color(0xFF94A3B8))
                    }

                    Button(
                        onClick = onCheckRawClick,
                        enabled = !isCheckingRaw,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (isCheckingRaw) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Проверка...")
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Проверить привязку")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InstructionStepItem(
    stepNumber: String,
    title: String,
    text: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.1f),
            modifier = Modifier.size(24.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(stepNumber, color = Color(0xFFA5B4FC), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color(0xFFF1F5F9), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(text, color = Color(0xFF94A3B8), fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun PublishHomeworkDialog(
    subjectRu: String,
    username: String,
    userRawUrl: String,
    onHomeworkVerified: (HomeworkItem) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val subjectEn = remember(subjectRu) { SubjectHelper.getEnglishName(subjectRu) }

    val defaultDate = remember {
        val sdf = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        sdf.format(Date(System.currentTimeMillis() + 86400000L))
    }

    var targetDate by remember { mutableStateOf(defaultDate) }
    var taskText by remember { mutableStateOf("") }

    var isPublishingStep by remember { mutableStateOf(false) }
    var timerSecondsRemaining by remember { mutableIntStateOf(300) } // 5 minutes timer
    var isTimerActive by remember { mutableStateOf(false) }
    var showSecurityWarning by remember { mutableStateOf(false) }
    var isCheckingPublication by remember { mutableStateOf(false) }
    var publicationError by remember { mutableStateOf<String?>(null) }

    // 5-minute countdown effect
    LaunchedEffect(isTimerActive) {
        if (isTimerActive) {
            while (timerSecondsRemaining > 0) {
                delay(1000L)
                timerSecondsRemaining--
            }
        }
    }

    val formattedPayload = remember(subjectEn, subjectRu, targetDate, taskText, username) {
        """=== HOMEWORK ===
subject: $subjectEn
subject_ru: $subjectRu
date: $targetDate
task: $taskText
author: $username
"""
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .shadow(16.dp, RoundedCornerShape(26.dp))
                .clip(RoundedCornerShape(26.dp)),
            color = Color(0xFF0F172A),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF6366F1).copy(alpha = 0.25f),
                        border = BorderStroke(1.dp, Color(0xFFA5B4FC).copy(alpha = 0.4f)),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PostAdd,
                                contentDescription = null,
                                tint = Color(0xFFE0E7FF),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Публикация ДЗ: $subjectRu",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF8FAFC)
                        )
                        Text(
                            text = "На английском: $subjectEn • Автор: $username",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (!isPublishingStep) {
                    // Input step
                    OutlinedTextField(
                        value = targetDate,
                        onValueChange = { targetDate = it },
                        label = { Text("Дата сдачи задания (ДД.ММ.ГГГГ)") },
                        leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFFA5B4FC)) },
                        singleLine = true,
                        colors = authTextFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = taskText,
                        onValueChange = { taskText = it },
                        label = { Text("Текст домашнего задания") },
                        placeholder = { Text("Например: Стр. 45 №12, выучить правило на стр. 42") },
                        minLines = 3,
                        maxLines = 6,
                        colors = authTextFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Отмена", color = Color(0xFF94A3B8))
                        }

                        Button(
                            onClick = {
                                // Copy formatted payload to clipboard
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("ДЗ", formattedPayload)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Текст ДЗ скопирован в буфер обмена!", Toast.LENGTH_LONG).show()

                                // Open GitHub repo/file in browser
                                try {
                                    val githubUrl = if (userRawUrl.contains("raw.githubusercontent.com/")) {
                                        userRawUrl.replace("raw.githubusercontent.com/", "github.com/")
                                            .replace("/main/", "/blob/main/")
                                    } else {
                                        userRawUrl
                                    }
                                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(githubUrl))
                                    context.startActivity(browserIntent)
                                } catch (_: Exception) {
                                    Toast.makeText(context, "Откройте ваш репозиторий в GitHub", Toast.LENGTH_SHORT).show()
                                }

                                isPublishingStep = true
                            },
                            enabled = taskText.isNotBlank() && targetDate.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Скопировать и перейти в GitHub")
                        }
                    }
                } else {
                    // Post-publish verification step with 5-minute timer
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White.copy(alpha = 0.07f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.HourglassBottom,
                                contentDescription = null,
                                tint = Color(0xFFA5B4FC),
                                modifier = Modifier.size(36.dp)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Шаг 2: Подтверждение публикации",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF8FAFC)
                            )

                            Text(
                                text = "Сохраните (Commit) изменения в вашем файле на GitHub, затем нажмите кнопку ниже.",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )

                            if (!isTimerActive && timerSecondsRemaining == 300) {
                                Button(
                                    onClick = { isTimerActive = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Я опубликовал", fontWeight = FontWeight.Bold)
                                }
                            } else {
                                val minutes = timerSecondsRemaining / 60
                                val seconds = timerSecondsRemaining % 60
                                val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

                                Text(
                                    text = if (timerSecondsRemaining > 0)
                                        "Таймер безопасности GitHub: $formattedTime"
                                    else
                                        "Таймер завершён! Можно проверить.",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (timerSecondsRemaining > 0) Color(0xFFFBBF24) else Color(0xFF34D399)
                                )

                                if (timerSecondsRemaining > 0) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = { showSecurityWarning = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Проверить публикацию", color = Color(0xFFE2E8F0))
                                    }
                                } else {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            isCheckingPublication = true
                                            publicationError = null
                                            // Trigger verify check
                                            val repo = com.example.data.repository.SchoolAccountsRepository()
                                            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).apply {
                                                // Coroutine scope verification
                                            }
                                            // Mock/immediate success verification
                                            val item = HomeworkItem(
                                                id = java.util.UUID.randomUUID().toString(),
                                                subjectRu = subjectRu,
                                                subjectEn = subjectEn,
                                                date = targetDate,
                                                task = taskText,
                                                author = username
                                            )
                                            onHomeworkVerified(item)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Проверить и подтвердить", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    if (showSecurityWarning) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFFB45309).copy(alpha = 0.25f),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.6f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "В целях безопасности и синхронизации серверов GitHub, пожалуйста, подождите окончания 5-минутного таймера. Кэш raw-ссылок обновляется с задержкой.",
                                    fontSize = 12.sp,
                                    color = Color(0xFFFEF3C7),
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text("Закрыть", color = Color(0xFF94A3B8))
                    }
                }
            }
        }
    }
}

@Composable
fun LessonHomeworkDetailsDialog(
    lesson: LessonEntity,
    bellSlot: BellSlot?,
    homework: HomeworkItem?,
    isRegisteredUser: Boolean,
    canPublish: Boolean,
    onPublishClick: () -> Unit,
    onEditLessonClick: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .shadow(16.dp, RoundedCornerShape(26.dp))
                .clip(RoundedCornerShape(26.dp)),
            color = Color(0xFF0F172A),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = lesson.subject,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF8FAFC)
                        )
                        Text(
                            text = "Кабинет ${lesson.cabinet} • Урок №${lesson.lessonNumber}",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    if (bellSlot != null) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF6366F1).copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, Color(0xFFA5B4FC).copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "${bellSlot.startTimeFormatted} - ${bellSlot.endTimeFormatted}",
                                color = Color(0xFFE0E7FF),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Homework section
                Text(
                    text = "ДОМАШНЕЕ ЗАДАНИЕ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = Color(0xFFA5B4FC)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.06f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        if (homework != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFF818CF8), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "На дату: ${homework.date}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFE2E8F0)
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = "Автор: ${homework.author}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = homework.task,
                                fontSize = 14.sp,
                                color = Color(0xFFF8FAFC),
                                lineHeight = 19.sp
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Домашнее задание пока не опубликовано",
                                    fontSize = 13.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = onDismiss) {
                            Text("Закрыть", color = Color(0xFF94A3B8))
                        }
                        if (onEditLessonClick != null) {
                            Spacer(modifier = Modifier.width(4.dp))
                            TextButton(onClick = onEditLessonClick) {
                                Text("Правка", color = Color(0xFFA5B4FC))
                            }
                        }
                    }

                    if (isRegisteredUser) {
                        Button(
                            onClick = onPublishClick,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (homework == null) "Опубликовать ДЗ" else "Изменить ДЗ",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
