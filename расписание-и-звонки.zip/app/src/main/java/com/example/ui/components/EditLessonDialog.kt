package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoorFront
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LessonEntity
import com.example.data.model.DefaultSchedule

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditLessonDialog(
    lesson: LessonEntity,
    onDismiss: () -> Unit,
    onSave: (subject: String, cabinet: String, teacher: String, isOnlyToday: Boolean) -> Unit,
    onDelete: (LessonEntity) -> Unit
) {
    var subject by remember { mutableStateOf(lesson.subject) }
    var cabinet by remember { mutableStateOf(lesson.cabinet) }
    var teacher by remember { mutableStateOf(lesson.teacher) }
    var isOnlyToday by remember { mutableStateOf(lesson.isOverrideForToday) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "Редактировать ${lesson.lessonNumber}-й урок",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Измените предмет или кабинет",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Subject TextField
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Название предмета") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.School, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_subject_input")
                )

                // Quick Subject Chips
                Text(
                    text = "Быстрый выбор предмета:",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    DefaultSchedule.popularSubjects.take(10).forEach { item ->
                        SuggestionChip(
                            onClick = { subject = item },
                            label = { Text(item, fontSize = 11.sp) }
                        )
                    }
                }

                // Cabinet TextField
                OutlinedTextField(
                    value = cabinet,
                    onValueChange = { cabinet = it },
                    label = { Text("Кабинет (например, 209Г)") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.DoorFront, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_cabinet_input")
                )

                // Teacher TextField (Optional)
                OutlinedTextField(
                    value = teacher,
                    onValueChange = { teacher = it },
                    label = { Text("Учитель / Заметка (необязательно)") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Scope: Only for today (substitution) vs Permanent
                Text(
                    text = "Как применить изменение?",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(
                        selected = isOnlyToday,
                        onClick = { isOnlyToday = true }
                    )
                    Column(
                        modifier = Modifier
                            .padding(start = 4.dp)
                            .weight(1f)
                    ) {
                        Text(
                            text = "Только на сегодня (замена)",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Завтра расписание вернется к обычному",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(
                        selected = !isOnlyToday,
                        onClick = { isOnlyToday = false }
                    )
                    Column(
                        modifier = Modifier
                            .padding(start = 4.dp)
                            .weight(1f)
                    ) {
                        Text(
                            text = "Навсегда (в расписание)",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Изменит постоянное еженедельное расписание",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (subject.isNotBlank()) {
                        onSave(subject.trim(), cabinet.trim(), teacher.trim(), isOnlyToday)
                    }
                },
                modifier = Modifier.testTag("save_lesson_btn")
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            Row {
                TextButton(
                    onClick = { onDelete(lesson) },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF4444))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Удалить",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Удалить")
                }
                TextButton(onClick = onDismiss) {
                    Text("Отмена")
                }
            }
        }
    )
}
