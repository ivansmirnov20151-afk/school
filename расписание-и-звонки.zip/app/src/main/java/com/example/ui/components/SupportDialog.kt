package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContactSupport
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.GeoBorder
import com.example.ui.theme.GeoBorderLight
import com.example.ui.theme.GeoBorderPurple
import com.example.ui.theme.GeoOnPrimary
import com.example.ui.theme.GeoOnPrimaryContainer
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryContainer
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceVariant
import com.example.ui.theme.GeoTextPrimary
import com.example.ui.theme.GeoTextSecondary
import kotlinx.coroutines.delay

enum class SupportTopic {
    ELECTIONS_AND_RESTRICTIONS,
    TECH_SUPPORT,
    SCHEDULE_QUESTIONS,
    SECURITY_PIN
}

@Composable
fun SupportDialog(
    isRestricted: Boolean,
    verificationStatus: String, // "none", "pending", "approved"
    submitTimestamp: Long,
    savedFio: String,
    savedBirthDate: String,
    onSubmitChildVerification: (fio: String, birthDate: String) -> Unit,
    onAdultVoteClick: () -> Unit,
    onVerificationApproved: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTopic by remember {
        mutableStateOf<SupportTopic?>(
            if (isRestricted) SupportTopic.ELECTIONS_AND_RESTRICTIONS else null
        )
    }

    var isChildFormActive by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .testTag("support_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = GeoSurface,
            border = BorderStroke(1.5.dp, GeoBorderPurple),
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header with Back and Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (selectedTopic != null) {
                        IconButton(
                            onClick = {
                                if (isChildFormActive) {
                                    isChildFormActive = false
                                } else {
                                    selectedTopic = null
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Назад",
                                tint = GeoPrimary
                            )
                        }
                    } else {
                        Surface(
                            shape = CircleShape,
                            color = GeoPrimaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.SupportAgent,
                                    contentDescription = null,
                                    tint = GeoPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Служба поддержки",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeoTextPrimary
                        )
                        Text(
                            text = if (isRestricted) "Режим снятия ограничений" else "Помощь и обратная связь",
                            fontSize = 11.sp,
                            color = if (isRestricted) Color(0xFFDC2626) else GeoTextSecondary
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Закрыть",
                            tint = GeoTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = GeoBorderLight)
                Spacer(modifier = Modifier.height(14.dp))

                when (selectedTopic) {
                    null -> {
                        // Support Categories Menu
                        SupportMenuScreen(
                            isRestricted = isRestricted,
                            verificationStatus = verificationStatus,
                            onSelectTopic = { selectedTopic = it }
                        )
                    }
                    SupportTopic.ELECTIONS_AND_RESTRICTIONS -> {
                        ElectionsSupportTopicScreen(
                            verificationStatus = verificationStatus,
                            submitTimestamp = submitTimestamp,
                            savedFio = savedFio,
                            savedBirthDate = savedBirthDate,
                            isChildFormActive = isChildFormActive,
                            onSetChildFormActive = { isChildFormActive = it },
                            onSubmitChildVerification = onSubmitChildVerification,
                            onAdultVoteClick = onAdultVoteClick,
                            onVerificationApproved = onVerificationApproved,
                            onDismiss = onDismiss
                        )
                    }
                    SupportTopic.TECH_SUPPORT -> {
                        TechSupportScreen()
                    }
                    SupportTopic.SCHEDULE_QUESTIONS -> {
                        ScheduleQuestionsScreen()
                    }
                    SupportTopic.SECURITY_PIN -> {
                        SecurityPinScreen()
                    }
                }
            }
        }
    }
}

@Composable
private fun SupportMenuScreen(
    isRestricted: Boolean,
    verificationStatus: String,
    onSelectTopic: (SupportTopic) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (isRestricted) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFFFEF2F2),
                border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = "Внимание: функции приложения заблокированы",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF991B1B)
                        )
                        Text(
                            text = "Выберите первый пункт меню ниже, чтобы снять ограничения (для взрослых или детей).",
                            fontSize = 11.sp,
                            color = Color(0xFFB91C1C)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }

        Text(
            text = "Выберите тему обращения:",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = GeoTextPrimary
        )

        SupportTopicCard(
            title = "Выборы в Госдуму и снятие ограничений",
            subtitle = if (verificationStatus == "pending") "Статус: В обработке (5 мин)"
            else if (verificationStatus == "approved") "Ограничения сняты"
            else "Разблокировать расписание уроков, обед и настройки",
            icon = Icons.Default.HowToVote,
            iconTint = Color(0xFF1E40AF),
            isHighlighted = isRestricted,
            onClick = { onSelectTopic(SupportTopic.ELECTIONS_AND_RESTRICTIONS) }
        )

        SupportTopicCard(
            title = "Технические неполадки и обновления",
            subtitle = "Сбои, виджеты уведомлений, версия 1.2.0",
            icon = Icons.Default.HelpOutline,
            iconTint = GeoPrimary,
            onClick = { onSelectTopic(SupportTopic.TECH_SUPPORT) }
        )

        SupportTopicCard(
            title = "Расписание звонков и уроков",
            subtitle = "Информация по урокам 5Б класса и переменам",
            icon = Icons.Default.Schedule,
            iconTint = Color(0xFF0D9488),
            onClick = { onSelectTopic(SupportTopic.SCHEDULE_QUESTIONS) }
        )

        SupportTopicCard(
            title = "Безопасность и PIN-код",
            subtitle = "Восстановление и смена пароля доступа",
            icon = Icons.Default.Security,
            iconTint = Color(0xFF7C3AED),
            onClick = { onSelectTopic(SupportTopic.SECURITY_PIN) }
        )
    }
}

@Composable
private fun SupportTopicCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    isHighlighted: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlighted) Color(0xFFEFF6FF) else GeoSurfaceVariant
        ),
        border = BorderStroke(
            1.2.dp,
            if (isHighlighted) Color(0xFF3B82F6) else GeoBorderLight
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = iconTint.copy(alpha = 0.12f),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = GeoTextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = GeoTextSecondary,
                    lineHeight = 14.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForwardIos,
                contentDescription = null,
                tint = GeoTextSecondary,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun ElectionsSupportTopicScreen(
    verificationStatus: String,
    submitTimestamp: Long,
    savedFio: String,
    savedBirthDate: String,
    isChildFormActive: Boolean,
    onSetChildFormActive: (Boolean) -> Unit,
    onSubmitChildVerification: (fio: String, birthDate: String) -> Unit,
    onAdultVoteClick: () -> Unit,
    onVerificationApproved: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    // Live 5-minute timer state calculation
    val now = System.currentTimeMillis()
    val elapsedMillis = if (submitTimestamp > 0) now - submitTimestamp else 0L
    val fiveMinutesMillis = 5 * 60 * 1000L
    val remainingMillis = (fiveMinutesMillis - elapsedMillis).coerceAtLeast(0L)

    var secondsLeft by remember(submitTimestamp) {
        mutableLongStateOf(remainingMillis / 1000)
    }

    var isApprovedLocally by remember {
        mutableStateOf(verificationStatus == "approved" || (verificationStatus == "pending" && remainingMillis <= 0))
    }

    // Timer effect for 5 minutes countdown
    LaunchedEffect(verificationStatus, submitTimestamp) {
        if (verificationStatus == "pending" && !isApprovedLocally) {
            while (true) {
                val currentNow = System.currentTimeMillis()
                val rem = (fiveMinutesMillis - (currentNow - submitTimestamp)) / 1000
                if (rem <= 0) {
                    secondsLeft = 0
                    isApprovedLocally = true
                    onVerificationApproved()
                    break
                } else {
                    secondsLeft = rem
                }
                delay(1000)
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // CASE 1: Approved!
        if (isApprovedLocally || verificationStatus == "approved") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                border = BorderStroke(1.5.dp, Color(0xFF22C55E))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF16A34A),
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "Обработано!",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D)
                    )
                    Text(
                        text = "Анкета учащегося успешно проверена. Все ограничения сняты!\nРасписание уроков, звонки, обед и настройки разблокированы.",
                        fontSize = 13.sp,
                        color = Color(0xFF166534),
                        textAlign = TextAlign.Center
                    )

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                    ) {
                        Text("Вернуться к расписанию")
                    }
                }
            }
            return
        }

        // CASE 2: Pending (Under 5-minute review)
        if (verificationStatus == "pending") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                border = BorderStroke(1.5.dp, Color(0xFFF59E0B))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFFEF3C7),
                        modifier = Modifier.size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.HourglassTop,
                                contentDescription = null,
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }

                    Text(
                        text = "Заявка в обработке",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF92400E)
                    )

                    val minutes = secondsLeft / 60
                    val seconds = secondsLeft % 60
                    val timerStr = String.format("%02d:%02d", minutes, seconds)

                    Text(
                        text = "Осталось времени: $timerStr",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFB45309)
                    )

                    val progress = ((300 - secondsLeft).toFloat() / 300f).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = Color(0xFFD97706),
                        trackColor = Color(0xFFFDE68A)
                    )

                    Text(
                        text = "Заявка проверяется системой поддержки. Ровно через 5 минут после отправки статус изменится на «Обработано», и ограничения снимутся автоматически.",
                        fontSize = 12.sp,
                        color = Color(0xFF78350F),
                        textAlign = TextAlign.Center
                    )

                    if (savedFio.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEF3C7),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Данные учащегося:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E)
                                )
                                Text(
                                    text = "ФИО: $savedFio",
                                    fontSize = 11.sp,
                                    color = Color(0xFF78350F)
                                )
                                if (savedBirthDate.isNotBlank()) {
                                    Text(
                                        text = "Дата рождения: $savedBirthDate",
                                        fontSize = 11.sp,
                                        color = Color(0xFF78350F)
                                    )
                                }
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            val cur = System.currentTimeMillis()
                            if (cur - submitTimestamp >= fiveMinutesMillis) {
                                isApprovedLocally = true
                                onVerificationApproved()
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Обновить статус")
                    }
                }
            }
            return
        }

        // CASE 3: Child Form Active
        if (isChildFormActive) {
            ChildVerificationForm(
                onSubmit = { fio, bDate ->
                    onSubmitChildVerification(fio, bDate)
                },
                onCancel = { onSetChildFormActive(false) }
            )
            return
        }

        // CASE 4: Initial Choices ("Я взрослый" or "Я ребёнок")
        Text(
            text = "Снятие ограничений доступа",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = GeoTextPrimary
        )

        Text(
            text = "Если вы не проголосовали на выборах, доступ к расписанию заблокирован. Выберите ваш статус, чтобы снять ограничения:",
            fontSize = 12.sp,
            color = GeoTextSecondary
        )

        // Option 1: Adult (Vote)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onAdultVoteClick() },
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
            border = BorderStroke(1.dp, Color(0xFF93C5FD))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF1E40AF),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.HowToVote,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Я совершеннолетний (18+)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E3A8A)
                    )
                    Text(
                        text = "Перейти по ссылке к официальному голосованию на Госуслуги / ДЭГ. Ограничения снимутся сразу.",
                        fontSize = 11.sp,
                        color = Color(0xFF1D4ED8)
                    )
                }

                Icon(
                    imageVector = Icons.Default.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF1E40AF),
                    modifier = Modifier.size(14.dp)
                )
            }
        }

        // Option 2: Child (School Student)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSetChildFormActive(true) },
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF5FF)),
            border = BorderStroke(1.2.dp, Color(0xFFC084FC))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF7C3AED),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.ChildCare,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Я ребёнок (ученик 5Б класса)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF581C87)
                    )
                    Text(
                        text = "Заполнить анкету: указать ФИО, дату рождения и согласие на обработку. Проверка займёт 5 минут.",
                        fontSize = 11.sp,
                        color = Color(0xFF6B21A8)
                    )
                }

                Icon(
                    imageVector = Icons.Default.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF7C3AED),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
private fun ChildVerificationForm(
    onSubmit: (fio: String, birthDate: String) -> Unit,
    onCancel: () -> Unit
) {
    var fio by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var isConsentChecked by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(50),
            color = Color(0xFFF3E8FF)
        ) {
            Text(
                text = "АНКЕТА УЧАЩЕГОСЯ",
                color = Color(0xFF6B21A8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }

        Text(
            text = "Снятие ограничений для учащегося",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = GeoTextPrimary
        )

        Text(
            text = "Укажите ваши данные учащегося. Через 5 минут после отправки система подтвердит статус и снимет блокировку с расписания.",
            fontSize = 12.sp,
            color = GeoTextSecondary
        )

        // FIO input
        OutlinedTextField(
            value = fio,
            onValueChange = {
                fio = it
                errorMessage = null
            },
            label = { Text("Фамилия Имя Отчество") },
            placeholder = { Text("например: Смирнов Иван Алексеевич") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("child_fio_input"),
            shape = RoundedCornerShape(12.dp)
        )

        // Birth Date input
        OutlinedTextField(
            value = birthDate,
            onValueChange = {
                birthDate = it
                errorMessage = null
            },
            label = { Text("Дата рождения (ДД.ММ.ГГГГ)") },
            placeholder = { Text("например: 15.05.2015") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("child_birth_date_input"),
            shape = RoundedCornerShape(12.dp)
        )

        // Consent Checkbox
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { isConsentChecked = !isConsentChecked }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isConsentChecked,
                onCheckedChange = { isConsentChecked = it },
                colors = CheckboxDefaults.colors(checkedColor = GeoPrimary),
                modifier = Modifier.testTag("consent_checkbox")
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Я согласен на обработку персональных данных учащегося",
                fontSize = 12.sp,
                color = GeoTextPrimary,
                lineHeight = 15.sp
            )
        }

        if (errorMessage != null) {
            Text(
                text = errorMessage!!,
                color = Color(0xFFDC2626),
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Submit Button
        Button(
            onClick = {
                if (fio.trim().length < 4) {
                    errorMessage = "Пожалуйста, введите Фамилию, Имя и Отчество полностью"
                } else if (birthDate.trim().length < 4) {
                    errorMessage = "Пожалуйста, укажите дату рождения"
                } else if (!isConsentChecked) {
                    errorMessage = "Необходимо подтвердить согласие на обработку данных"
                } else {
                    onSubmit(fio.trim(), birthDate.trim())
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("submit_child_verification_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
        ) {
            Icon(
                imageVector = Icons.Default.Send,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Отправить заявку (обработка 5 минут)",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }

        OutlinedButton(
            onClick = onCancel,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text("Назад к выбору статуса")
        }
    }
}

@Composable
private fun TechSupportScreen() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Техническая поддержка",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = GeoTextPrimary
        )

        FaqCard(
            question = "Почему заблокированы расписание и звонки?",
            answer = "Для снятия блокировки необходимо либо перейти по ссылке голосования (для 18+), либо заполнить анкету «Я ребёнок» в этом же меню поддержки."
        )

        FaqCard(
            question = "Как долго проверяется анкета?",
            answer = "Проверка данных учащегося длится ровно 5 минут. По истечении таймера система автоматически снимет все ограничения."
        )

        FaqCard(
            question = "Как работают уведомления о звонках?",
            answer = "Уведомления отправляются за 5 минут до начала каждого урока и перемены. Их можно настроить в меню «Настройки» после снятия ограничений."
        )
    }
}

@Composable
private fun ScheduleQuestionsScreen() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Расписание 5Б класса",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = GeoTextPrimary
        )

        FaqCard(
            question = "Когда начинается обеденная перемена?",
            answer = "Обед в 5Б классе проходит после 3-го урока: с 11:10 до 11:30 (длится 20 минут)."
        )

        FaqCard(
            question = "Сколько всего уроков в день?",
            answer = "В понедельник, вторник и пятницу — по 6 уроков (до 14:15). В среду и четверг — по 7 уроков (до 15:10)."
        )
    }
}

@Composable
private fun SecurityPinScreen() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Безопасность и PIN-код",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = GeoTextPrimary
        )

        FaqCard(
            question = "Какой стандартный PIN-код?",
            answer = "Стандартный PIN-код приложения — 2015. Вы можете сменить его в настройках на любой 4-значный код."
        )

        FaqCard(
            question = "Что делать, если забыли PIN?",
            answer = "Свяжитесь со старостой или администратором расписания класса 5Б для сброса данных."
        )
    }
}

@Composable
private fun FaqCard(
    question: String,
    answer: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = GeoSurfaceVariant),
        border = BorderStroke(1.dp, GeoBorderLight)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = question,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = GeoTextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = answer,
                fontSize = 11.sp,
                color = GeoTextSecondary,
                lineHeight = 15.sp
            )
        }
    }
}
