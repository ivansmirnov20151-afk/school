package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dining
import androidx.compose.material.icons.filled.DoorFront
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurrentStatusInfo
import com.example.data.model.SchoolTimeStatus
import com.example.ui.theme.GeoBorderPurple
import com.example.ui.theme.GeoOnPrimaryContainer
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryContainer
import com.example.ui.theme.GeoSecondaryContainer
import com.example.ui.theme.GeoTextSecondary

@Composable
fun CurrentLessonHeroCard(
    statusInfo: CurrentStatusInfo,
    isAutoTracking: Boolean,
    onLessonFinishedClick: () -> Unit,
    onResetToAutoClick: () -> Unit,
    onOpenBellsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBreak = statusInfo.status == SchoolTimeStatus.IN_BREAK ||
            statusInfo.status == SchoolTimeStatus.IN_LUNCH_BREAK
    val isLesson = statusInfo.status == SchoolTimeStatus.IN_LESSON

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize()
            .testTag("current_lesson_hero_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = GeoPrimaryContainer
        ),
        border = BorderStroke(1.dp, GeoBorderPurple),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp)
        ) {
            // Header Row: Status Badge & Room / Bells Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Geometric Pill Badge
                Surface(
                    shape = RoundedCornerShape(50),
                    color = GeoOnPrimaryContainer
                ) {
                    Text(
                        text = when (statusInfo.status) {
                            SchoolTimeStatus.IN_LESSON -> "ИДЁТ УРОК"
                            SchoolTimeStatus.IN_LUNCH_BREAK -> "ПЕРЕМЕНА • ОБЕД"
                            SchoolTimeStatus.IN_BREAK -> "ПЕРЕМЕНА"
                            SchoolTimeStatus.BEFORE_SCHOOL -> "ДО НАЧАЛА"
                            SchoolTimeStatus.AFTER_SCHOOL -> "УРОКИ ЗАВЕРШЕНЫ"
                            SchoolTimeStatus.WEEKEND -> "ВЫХОДНОЙ"
                        },
                        color = GeoPrimaryContainer,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.6.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }

                // Room / Bells indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (isLesson && !statusInfo.activeCabinet.isNullOrBlank()) {
                        Text(
                            text = "Каб. ${statusInfo.activeCabinet}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = GeoTextSecondary
                        )
                    }

                    Surface(
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)),
                        color = Color.White.copy(alpha = 0.6f),
                        onClick = onOpenBellsClick
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Звонки",
                                tint = GeoOnPrimaryContainer,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Звонки",
                                color = GeoOnPrimaryContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Subject Title
            if (isLesson) {
                Text(
                    text = "${statusInfo.activeLessonNumber}-й урок",
                    color = GeoPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = statusInfo.activeSubject ?: "Урок",
                    color = GeoOnPrimaryContainer,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            } else if (isBreak) {
                Text(
                    text = if (statusInfo.status == SchoolTimeStatus.IN_LUNCH_BREAK) "ПИТАНИЕ И ОБЕД" else "ПЕРЕМЕНА",
                    color = GeoPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = if (statusInfo.status == SchoolTimeStatus.IN_LUNCH_BREAK) "Обед в столовой 🍲" else "Отдых между уроками",
                    color = GeoOnPrimaryContainer,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Text(
                    text = statusInfo.statusHeadline,
                    color = GeoOnPrimaryContainer,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = statusInfo.statusSubtext,
                    color = GeoTextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // Progress Bar & Timer Countdown
            if (isLesson || isBreak || statusInfo.status == SchoolTimeStatus.BEFORE_SCHOOL) {
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { statusInfo.progressFraction },
                        modifier = Modifier
                            .weight(1f)
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = GeoPrimary,
                        trackColor = GeoSecondaryContainer,
                        strokeCap = StrokeCap.Round
                    )

                    Text(
                        text = "${statusInfo.formattedRemainingTime} осталось",
                        color = GeoPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Bottom action row: Status info + "Урок окончен" button
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isLesson) "Урок в процессе" else statusInfo.statusSubtext.take(30),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = GeoTextSecondary
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!isAutoTracking) {
                        OutlinedButton(
                            onClick = onResetToAutoClick,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, GeoPrimary),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = GeoPrimary
                            )
                        ) {
                            Text(
                                text = "Автопо часам",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.8f),
                        border = BorderStroke(1.dp, Color.White),
                        onClick = onLessonFinishedClick,
                        modifier = Modifier.testTag("lesson_finished_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = GeoOnPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Урок окончен",
                                color = GeoOnPrimaryContainer,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
