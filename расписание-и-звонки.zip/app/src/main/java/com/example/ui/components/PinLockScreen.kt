package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun PinLockScreen(
    enteredPin: String,
    pinError: Boolean,
    isChecking: Boolean = false,
    welcomeMode: Boolean = false,
    onDigitClick: (Char) -> Unit,
    onDeleteClick: () -> Unit,
    onClearClick: () -> Unit,
    onFingerprintSuccess: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val shakeOffset = remember { Animatable(0f) }

    // Fingerprint prompt bottom popup state
    var showBiometricSheet by remember { mutableStateOf(false) }

    LaunchedEffect(pinError) {
        if (pinError) {
            shakeOffset.animateTo(
                targetValue = 0f,
                animationSpec = keyframes {
                    durationMillis = 400
                    0f at 0
                    -20f at 50
                    20f at 100
                    -15f at 150
                    15f at 200
                    -10f at 250
                    10f at 300
                    0f at 400
                }
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E1B4B),
                        Color(0xFF090D16)
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 380.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Pixel-style lock indicator
            Surface(
                modifier = Modifier
                    .size(68.dp)
                    .scale(if (welcomeMode) 1.08f else 1f),
                shape = CircleShape,
                color = if (welcomeMode) Color(0xFF10B981).copy(alpha = 0.18f) else Color(0xFF6366F1).copy(alpha = 0.2f),
                border = BorderStroke(
                    1.5.dp,
                    if (welcomeMode) Color(0xFF10B981) else Color(0xFF818CF8).copy(alpha = 0.5f)
                )
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (welcomeMode) Icons.Default.CheckCircle else Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = if (welcomeMode) Color(0xFF34D399) else Color(0xFFE0E7FF),
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Header Text
            Text(
                text = if (welcomeMode) "Добро пожаловать!" else "Расписание 5Б",
                fontSize = if (welcomeMode) 26.sp else 23.sp,
                fontWeight = FontWeight.Bold,
                color = if (welcomeMode) Color(0xFF34D399) else Color(0xFFF8FAFC),
                textAlign = TextAlign.Center
            )

            Text(
                text = if (welcomeMode) "Загрузка расписания..." else "Введите PIN-код или нажмите на отпечаток",
                fontSize = 13.sp,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp)
            )

            Spacer(modifier = Modifier.height(30.dp))

            // Google Pixel Style PIN Input Cells
            Row(
                modifier = Modifier
                    .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 4) {
                    val isFilled = i < enteredPin.length
                    val isCurrent = i == enteredPin.length

                    Box(
                        modifier = Modifier
                            .size(width = 54.dp, height = 58.dp)
                            .shadow(
                                elevation = 4.dp,
                                shape = RoundedCornerShape(16.dp),
                                spotColor = Color(0xFF0F172A).copy(alpha = 0.3f),
                                ambientColor = Color(0xFF0F172A).copy(alpha = 0.2f)
                            )
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                when {
                                    welcomeMode -> Color(0xFF059669).copy(alpha = 0.25f)
                                    pinError -> Color(0xFFEF4444).copy(alpha = 0.22f)
                                    isFilled -> Color(0xFF818CF8).copy(alpha = 0.25f)
                                    else -> Color.White.copy(alpha = 0.07f)
                                }
                            )
                            .border(
                                width = if (isCurrent && !welcomeMode) 1.5.dp else 1.dp,
                                color = when {
                                    welcomeMode -> Color(0xFF10B981)
                                    pinError -> Color(0xFFEF4444)
                                    isFilled -> Color(0xFFA5B4FC)
                                    isCurrent -> Color(0xFFE0E7FF).copy(alpha = 0.9f)
                                    else -> Color.White.copy(alpha = 0.25f)
                                },
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isFilled) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(if (welcomeMode) Color(0xFF34D399) else Color(0xFFEEF2FF))
                            )
                        } else if (isCurrent && !welcomeMode) {
                            Box(
                                modifier = Modifier
                                    .size(width = 16.dp, height = 2.dp)
                                    .clip(RoundedCornerShape(1.dp))
                                    .background(Color(0xFF94A3B8))
                            )
                        }
                    }
                }
            }

            // Status message / checking / hint
            Spacer(modifier = Modifier.height(18.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp),
                contentAlignment = Alignment.Center
            ) {
                when {
                    welcomeMode || isChecking -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = if (welcomeMode) Color(0xFF34D399) else Color(0xFF818CF8)
                            )
                            Text(
                                text = if (welcomeMode) "Вход выполнен успешно!" else "Проверка доступа...",
                                color = if (welcomeMode) Color(0xFF34D399) else Color(0xFF818CF8),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    pinError -> {
                        Text(
                            text = "Неверный PIN! Попробуйте снова",
                            color = Color(0xFFF87171),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    showBiometricSheet -> {
                        Text(
                            text = "Сканирование отпечатка пальца...",
                            color = Color(0xFFA5B4FC),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    else -> {
                        Text(
                            text = "Код доступа: 2015",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Google Pixel Style Numpad (Large circular touch surfaces with haptic feel)
            val keypad = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("FP", "0", "DEL")
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                for (row in keypad) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        for (key in row) {
                            when (key) {
                                "FP" -> {
                                    PixelFingerprintButton(
                                        isScanning = showBiometricSheet,
                                        pulseScale = 1f,
                                        onClick = {
                                            if (!isChecking && !welcomeMode) {
                                                showBiometricSheet = true
                                            }
                                        }
                                    )
                                }
                                "DEL" -> {
                                    PixelKeypadIconButton(
                                        icon = Icons.AutoMirrored.Filled.Backspace,
                                        testTag = "pin_backspace_btn",
                                        onClick = onDeleteClick
                                    )
                                }
                                else -> {
                                    PixelKeypadDigitButton(
                                        digit = key[0],
                                        testTag = "pin_digit_$key",
                                        onClick = { onDigitClick(key[0]) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Real Biometric Bottom Popup (slid up from bottom with authentic interactive touch scanner & loading)
        RealBiometricBottomSheet(
            isVisible = showBiometricSheet,
            onDismiss = { showBiometricSheet = false },
            onSuccess = {
                showBiometricSheet = false
                onFingerprintSuccess()
            },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
fun PixelKeypadDigitButton(
    digit: Char,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(74.dp)
            .shadow(
                elevation = 6.dp,
                shape = CircleShape,
                spotColor = Color(0xFF0F172A).copy(alpha = 0.35f),
                ambientColor = Color(0xFF0F172A).copy(alpha = 0.20f)
            )
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.08f),
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = 0.45f),
                    Color.White.copy(alpha = 0.15f)
                )
            )
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            // Liquid glass highlight
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.18f),
                            Color.White.copy(alpha = 0.04f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.32f),
                        radius = size.width * 0.52f
                    )
                )
            }
            Text(
                text = digit.toString(),
                fontSize = 27.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFF8FAFC)
            )
        }
    }
}

@Composable
fun PixelKeypadIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(74.dp)
            .shadow(
                elevation = 6.dp,
                shape = CircleShape,
                spotColor = Color(0xFF0F172A).copy(alpha = 0.35f),
                ambientColor = Color(0xFF0F172A).copy(alpha = 0.20f)
            )
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.06f),
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = 0.35f),
                    Color.White.copy(alpha = 0.10f)
                )
            )
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.35f),
                        radius = size.width * 0.5f
                    )
                )
            }
            Icon(
                imageVector = icon,
                contentDescription = "Удалить",
                tint = Color(0xFFE2E8F0),
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun PixelFingerprintButton(
    isScanning: Boolean,
    pulseScale: Float,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(74.dp)
            .scale(if (isScanning) pulseScale else 1f)
            .shadow(
                elevation = 6.dp,
                shape = CircleShape,
                spotColor = Color(0xFF0F172A).copy(alpha = 0.35f),
                ambientColor = Color(0xFF0F172A).copy(alpha = 0.20f)
            )
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .testTag("pin_fingerprint_btn"),
        shape = CircleShape,
        color = if (isScanning) Color(0xFF6366F1).copy(alpha = 0.22f) else Color.White.copy(alpha = 0.08f),
        border = BorderStroke(
            1.2.dp,
            if (isScanning)
                Brush.linearGradient(listOf(Color(0xFFA5B4FC), Color(0xFF6366F1)))
            else
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.40f), Color.White.copy(alpha = 0.12f)))
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.15f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.35f),
                        radius = size.width * 0.5f
                    )
                )
            }
            Icon(
                imageVector = Icons.Default.Fingerprint,
                contentDescription = "Отпечаток пальца",
                tint = if (isScanning) Color(0xFFA5B4FC) else Color(0xFFE2E8F0),
                modifier = Modifier.size(30.dp)
            )
        }
    }
}
