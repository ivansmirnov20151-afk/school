package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoBorder
import com.example.ui.theme.GeoBorderLight
import com.example.ui.theme.GeoBorderPurple
import com.example.ui.theme.GeoOnPrimary
import com.example.ui.theme.GeoOnPrimaryContainer
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryContainer
import com.example.ui.theme.GeoSecondaryContainer
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceVariant
import com.example.ui.theme.GeoTextPrimary
import com.example.ui.theme.GeoTextSecondary

@Composable
fun MandatoryUpdateScreen(
    currentVersion: String,
    remoteVersion: String,
    announcement: String?,
    updateUrl: String?,
    isCheckingAgain: Boolean,
    onCheckAgainClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Disallow exiting the mandatory update screen via back button
    BackHandler(enabled = true) {
        // Deliberately no-op to block bypassing the update screen
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GeoBackground)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 480.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Geometric Warning Badge
            Surface(
                modifier = Modifier.size(80.dp),
                shape = CircleShape,
                color = Color(0xFFFDE8E8),
                border = BorderStroke(2.dp, Color(0xFFF8B4B4))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.SystemUpdate,
                        contentDescription = "Обновление",
                        tint = Color(0xFF9B1C1C),
                        modifier = Modifier.size(42.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Main Status Text
            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFF9B1C1C)
            ) {
                Text(
                    text = "ТРЕБУЕТСЯ ОБНОВЛЕНИЕ",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Данная версия не поддерживается",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = GeoTextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Для продолжения работы с расписанием 5Б класса необходимо установить актуальную версию приложения.",
                fontSize = 13.sp,
                color = GeoTextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Version Comparison Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = GeoSurface),
                border = BorderStroke(1.dp, GeoBorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "У вас установлена",
                            fontSize = 11.sp,
                            color = GeoTextSecondary
                        )
                        Text(
                            text = "v$currentVersion",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF9B1C1C)
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFDE8E8),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                text = "Устарела",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF9B1C1C),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(GeoSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("➔", color = GeoPrimary, fontWeight = FontWeight.Bold)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Доступна новая",
                            fontSize = 11.sp,
                            color = GeoTextSecondary
                        )
                        Text(
                            text = "v$remoteVersion",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeoPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = GeoPrimaryContainer,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                text = "Актуальная",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeoOnPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // What's updated announcement card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = GeoPrimaryContainer.copy(alpha = 0.6f)),
                border = BorderStroke(1.dp, GeoBorderPurple),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = GeoPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "ЧТО НОВОГО В ОБНОВЛЕНИИ",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp,
                            color = GeoOnPrimaryContainer
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val changelogText = if (!announcement.isNullOrBlank()) {
                        announcement
                    } else {
                        "• Добавлены новые функции и улучшения расписания\n• Оптимизация работы таймера и оповещений\n• Исправление мелких ошибок и стабильности"
                    }

                    Text(
                        text = changelogText,
                        fontSize = 13.sp,
                        color = GeoTextPrimary,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Download / Install Action Button
            if (!updateUrl.isNullOrBlank() && (updateUrl.startsWith("http://") || updateUrl.startsWith("https://"))) {
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(updateUrl))
                            context.startActivity(intent)
                        } catch (_: Exception) {
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("download_update_btn"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GeoPrimary)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = GeoOnPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Установить обновление",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeoOnPrimary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            } else {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GeoSurface,
                    border = BorderStroke(1.dp, GeoBorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = GeoPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Файл обновления доступен в официальном канале или у классного руководителя.",
                            fontSize = 12.sp,
                            color = GeoTextSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Retry / Check Again button
            OutlinedButton(
                onClick = onCheckAgainClick,
                enabled = !isCheckingAgain,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("recheck_update_btn"),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GeoBorder)
            ) {
                if (isCheckingAgain) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = GeoPrimary
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(
                        text = "Проверка...",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GeoTextSecondary
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = GeoTextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(
                        text = "Проверить снова",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GeoTextPrimary
                    )
                }
            }
        }
    }
}
