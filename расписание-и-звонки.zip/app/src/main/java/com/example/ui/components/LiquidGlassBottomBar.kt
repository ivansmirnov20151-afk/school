package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class BottomTab {
    SCHEDULE,
    AI_TUTOR,
    GRADES,
    BELLS,
    SETTINGS
}

private val tabsList = listOf(
    BottomTab.SCHEDULE,
    BottomTab.AI_TUTOR,
    BottomTab.GRADES,
    BottomTab.BELLS,
    BottomTab.SETTINGS
)

@Composable
fun LiquidGlassBottomBar(
    currentTab: BottomTab,
    onTabSelected: (BottomTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    // Active tab index (0..4)
    val targetIndex = tabsList.indexOf(currentTab).coerceAtLeast(0)
    val thumbPosition = remember { Animatable(targetIndex.toFloat()) }
    var isDragging by remember { mutableStateOf(false) }
    var isTouchingTab by remember { mutableStateOf(false) }

    // Sync position when target tab changes outside drag
    LaunchedEffect(targetIndex) {
        if (!isDragging) {
            thumbPosition.animateTo(
                targetValue = targetIndex.toFloat(),
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessLow
                )
            )
        }
    }

    val isActive by remember {
        derivedStateOf { isDragging || isTouchingTab }
    }

    // Styles according to user CSS:
    // When moving/active:
    // border-radius: 25px, border: 0px solid rgba(255, 255, 255, 0.45) -> 1px solid
    // background-color: rgba(255, 255, 255, 0.05)
    // box-shadow: 0 8px 15px rgba(15,23,42,0.35), 0 20px 38px rgba(15,23,42,0.45)
    // noise opacity: 0.4
    //
    // When resting on place:
    // border-radius: 48px, border: 0px solid rgba(167, 139, 250, 0.45)
    // background-color: rgba(167, 139, 250, 0.00)
    // box-shadow: 0 8px 40px rgba(15,23,42,0.35), 0 20px 100px rgba(15,23,42,0.45)
    // noise opacity: 0.0
    val cardRadius by animateDpAsState(
        targetValue = if (isActive) 25.dp else 48.dp,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "cardRadius"
    )
    val cardBorderColor by animateColorAsState(
        targetValue = if (isActive) Color(0xFFFFFFFF).copy(alpha = 0.45f) else Color(0xFFA78BFA).copy(alpha = 0.45f),
        animationSpec = tween(300),
        label = "cardBorderColor"
    )
    val cardBgColor by animateColorAsState(
        targetValue = if (isActive) Color(0xFFFFFFFF).copy(alpha = 0.05f) else Color(0xFFA78BFA).copy(alpha = 0.00f),
        animationSpec = tween(300),
        label = "cardBgColor"
    )
    val cardElevation by animateDpAsState(
        targetValue = if (isActive) 14.dp else 24.dp,
        animationSpec = tween(300),
        label = "cardElevation"
    )
    val noiseAlpha by animateFloatAsState(
        targetValue = if (isActive) 0.40f else 0.0f,
        animationSpec = tween(300),
        label = "noiseAlpha"
    )

    // Bottom container: fixed on bottom, doesn't translate away ("она сама передвигатся не должна")
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        val totalWidth = 340.dp
        val totalHeight = 82.dp
        val horizontalPad = 14.dp
        val slotWidth = (totalWidth - horizontalPad * 2) / 5
        val thumbSize = 52.dp

        Surface(
            modifier = Modifier
                .width(totalWidth)
                .height(totalHeight)
                .shadow(
                    elevation = cardElevation,
                    shape = RoundedCornerShape(cardRadius),
                    spotColor = Color(0xFF0F172A).copy(alpha = 0.45f),
                    ambientColor = Color(0xFF0F172A).copy(alpha = 0.35f)
                )
                .clip(RoundedCornerShape(cardRadius))
                .border(
                    width = 1.dp,
                    color = cardBorderColor,
                    shape = RoundedCornerShape(cardRadius)
                )
                // Gesture detector for moving the slider indicator ("перетаствиник")
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            isDragging = true
                            val touchedX = (offset.x - 14.dp.toPx()).coerceIn(0f, (totalWidth - horizontalPad * 2).toPx())
                            val newIdx = (touchedX / slotWidth.toPx()).coerceIn(0f, 4f)
                            coroutineScope.launch {
                                thumbPosition.snapTo(newIdx)
                            }
                        },
                        onDragEnd = {
                            isDragging = false
                            val finalIdx = thumbPosition.value.roundToInt().coerceIn(0, 4)
                            coroutineScope.launch {
                                thumbPosition.animateTo(
                                    targetValue = finalIdx.toFloat(),
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioLowBouncy,
                                        stiffness = Spring.StiffnessLow
                                    )
                                )
                                onTabSelected(tabsList[finalIdx])
                            }
                        },
                        onDragCancel = {
                            isDragging = false
                            val finalIdx = targetIndex.toFloat()
                            coroutineScope.launch {
                                thumbPosition.animateTo(finalIdx)
                            }
                        },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            coroutineScope.launch {
                                val currentPx = thumbPosition.value * slotWidth.toPx()
                                val nextPx = (currentPx + dragAmount).coerceIn(0f, slotWidth.toPx() * 4f)
                                thumbPosition.snapTo(nextPx / slotWidth.toPx())
                            }
                        }
                    )
                },
            shape = RoundedCornerShape(cardRadius),
            color = cardBgColor
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.CenterStart
            ) {
                // ::before Radial Gradient Highlight
                val hlColor = if (isActive) Color(0xFFFFFFFF) else Color(0xFFA78BFA)
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                hlColor.copy(alpha = if (isActive) 0.05f else 0.02f),
                                hlColor.copy(alpha = if (isActive) 0.01f else 0.005f),
                                Color.Transparent
                            ),
                            center = Offset(size.width / 2f, size.height / 2f),
                            radius = size.width * 0.5f
                        )
                    )
                }

                // ::after Noise Pattern (opacity: 0.4 active, 0 resting)
                if (noiseAlpha > 0.01f) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val dotStep = 7f
                        val w = size.width
                        val h = size.height
                        val dotColor = Color.White.copy(alpha = noiseAlpha * 0.15f)
                        var y = 0f
                        var row = 0
                        while (y < h) {
                            var x = if (row % 2 == 0) 0f else dotStep / 2f
                            while (x < w) {
                                val hash = ((x * 13.1f + y * 77.3f).toInt() % 100) / 100f
                                if (hash > 0.55f) {
                                    drawCircle(
                                        color = dotColor,
                                        radius = 1.1f,
                                        center = Offset(x, y)
                                    )
                                }
                                x += dotStep
                            }
                            y += dotStep
                            row++
                        }
                    }
                }

                // Interactive Slider Thumb ("перетаствиник")
                val thumbOffsetPx = horizontalPad + (slotWidth * thumbPosition.value) + ((slotWidth - thumbSize) / 2)
                Box(
                    modifier = Modifier
                        .offset { IntOffset(thumbOffsetPx.roundToPx(), 0) }
                        .size(thumbSize)
                        .shadow(
                            elevation = if (isActive) 12.dp else 8.dp,
                            shape = RoundedCornerShape(if (isActive) 22.dp else 26.dp),
                            spotColor = Color(0xFFA855F7).copy(alpha = 0.45f),
                            ambientColor = Color(0xFF7E22CE).copy(alpha = 0.35f)
                        )
                        .clip(RoundedCornerShape(if (isActive) 22.dp else 26.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = if (isActive) 0.22f else 0.14f),
                                    Color(0xFFA855F7).copy(alpha = if (isActive) 0.32f else 0.20f),
                                    Color(0xFF6B21A8).copy(alpha = if (isActive) 0.25f else 0.12f)
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = if (isActive) 0.65f else 0.40f),
                                    Color(0xFFA78BFA).copy(alpha = 0.30f)
                                )
                            ),
                            shape = RoundedCornerShape(if (isActive) 22.dp else 26.dp)
                        )
                )

                // 5 Tab Icons row
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = horizontalPad),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LiquidGlassTabButton(
                        icon = Icons.Default.CalendarMonth,
                        contentDescription = "Расписание",
                        isSelected = currentTab == BottomTab.SCHEDULE,
                        testTag = "tab_schedule",
                        accentColor = Color(0xFF3B82F6),
                        slotWidth = slotWidth,
                        thumbSize = thumbSize,
                        onPressStateChange = { isTouchingTab = it },
                        onClick = { onTabSelected(BottomTab.SCHEDULE) }
                    )

                    LiquidGlassTabButton(
                        icon = Icons.Default.AutoAwesome,
                        contentDescription = "ИИ-Репетитор",
                        isSelected = currentTab == BottomTab.AI_TUTOR,
                        testTag = "tab_ai_tutor",
                        accentColor = Color(0xFFA855F7),
                        slotWidth = slotWidth,
                        thumbSize = thumbSize,
                        onPressStateChange = { isTouchingTab = it },
                        onClick = { onTabSelected(BottomTab.AI_TUTOR) }
                    )

                    LiquidGlassTabButton(
                        icon = Icons.Default.BarChart,
                        contentDescription = "Оценки",
                        isSelected = currentTab == BottomTab.GRADES,
                        testTag = "tab_grades",
                        accentColor = Color(0xFF10B981),
                        slotWidth = slotWidth,
                        thumbSize = thumbSize,
                        onPressStateChange = { isTouchingTab = it },
                        onClick = { onTabSelected(BottomTab.GRADES) }
                    )

                    LiquidGlassTabButton(
                        icon = Icons.Default.Notifications,
                        contentDescription = "Звонки",
                        isSelected = currentTab == BottomTab.BELLS,
                        testTag = "tab_bells",
                        accentColor = Color(0xFFF59E0B),
                        slotWidth = slotWidth,
                        thumbSize = thumbSize,
                        onPressStateChange = { isTouchingTab = it },
                        onClick = { onTabSelected(BottomTab.BELLS) }
                    )

                    LiquidGlassTabButton(
                        icon = Icons.Default.Settings,
                        contentDescription = "Настройки",
                        isSelected = currentTab == BottomTab.SETTINGS,
                        testTag = "tab_settings",
                        accentColor = Color(0xFFEC4899),
                        slotWidth = slotWidth,
                        thumbSize = thumbSize,
                        onPressStateChange = { isTouchingTab = it },
                        onClick = { onTabSelected(BottomTab.SETTINGS) }
                    )
                }
            }
        }
    }
}

@Composable
private fun LiquidGlassTabButton(
    icon: ImageVector,
    contentDescription: String,
    isSelected: Boolean,
    testTag: String,
    accentColor: Color,
    slotWidth: androidx.compose.ui.unit.Dp,
    thumbSize: androidx.compose.ui.unit.Dp,
    onPressStateChange: (Boolean) -> Unit,
    onClick: () -> Unit
) {
    val iconColor by animateColorAsState(
        targetValue = if (isSelected) accentColor else Color(0xFFCBD5E1).copy(alpha = 0.85f),
        animationSpec = tween(200),
        label = "tabIconColor"
    )

    Box(
        modifier = Modifier
            .width(slotWidth)
            .height(thumbSize)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                onClick()
            }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = iconColor,
            modifier = Modifier.size(26.dp)
        )
    }
}
